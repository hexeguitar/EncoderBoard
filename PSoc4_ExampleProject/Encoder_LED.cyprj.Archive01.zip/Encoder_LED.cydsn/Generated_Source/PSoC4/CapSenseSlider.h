/*******************************************************************************
* File Name: CapSenseSlider.h
* Version 2.40
*
* Description:
*  This file provides constants and parameter values for the CapSense CSD
*  component.
*
* Note:
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CSD_CapSenseSlider_H)
#define CY_CAPSENSE_CSD_CapSenseSlider_H

#include "cytypes.h"
#include "cyfitter.h"
#include "core_cm0_psoc4.h"
#include "CyLib.h"

#include "CapSenseSlider_IP.h"
#include "CapSenseSlider_SenseClk.h"
#include "CapSenseSlider_SampleClk.h"

/* Constants set by Customizer */
#define CapSenseSlider_TOTAL_SENSOR_COUNT            (5u)
#define CapSenseSlider_TOTAL_SCANSLOT_COUNT          (5u)
#define CapSenseSlider_INDEX_TABLE_SIZE              (0u)

/* Define Sensors */
#define CapSenseSlider_SENSOR_LINEARSLIDER_E0__LS    (0u)
#define CapSenseSlider_SENSOR_LINEARSLIDER_E1__LS    (1u)
#define CapSenseSlider_SENSOR_LINEARSLIDER_E2__LS    (2u)
#define CapSenseSlider_SENSOR_LINEARSLIDER_E3__LS    (3u)
#define CapSenseSlider_SENSOR_LINEARSLIDER_E4__LS    (4u)

#define CapSenseSlider_TOTAL_SENSOR_MASK (((CapSenseSlider_TOTAL_SENSOR_COUNT - 1u) / 8u) + 1u)

/* Interrupt handler */
CY_ISR_PROTO(CapSenseSlider_ISR);

/* ISR Number and Priority to work with CyLib functions */
#define CapSenseSlider_ISR_NUMBER        (CapSenseSlider_ISR__INTC_NUMBER)
#define CapSenseSlider_ISR_PRIORITY      (CapSenseSlider_ISR__INTC_PRIOR_NUM)

/***************************************
*   Condition compilation parameters
***************************************/

#define CapSenseSlider_CONNECT_INACTIVE_SNS       (0u)
#define CapSenseSlider_IS_COMPLEX_SCANSLOTS       (0u)
#define CapSenseSlider_COMPLEX_SCANSLOTS_NUM      (0u)
#define CapSenseSlider_DEDICATED_SENSORS_NUM      (0u)
#define CapSenseSlider_PORT_PIN_CONFIG_TBL_ZISE   (5u)

#define CapSenseSlider_IDAC_CNT                   (2u)
#define CapSenseSlider_IDAC1_POLARITY             (0u)
#define CapSenseSlider_IDAC1_RANGE_VALUE          (0u)
#define CapSenseSlider_IDAC2_RANGE_VALUE          (0u)

#define CapSenseSlider_MULTIPLE_FREQUENCY_SET     (1u)
#define CapSenseSlider_FILTER_ENABLE              (0u)
#define CapSenseSlider_PRS_OPTIONS                (0u)

#define CapSenseSlider_WATER_PROOF                (0u)

#define CapSenseSlider_TUNING_METHOD              (2u)
#define CapSenseSlider_TUNER_API_GENERATE         (0u)

#define CapSenseSlider_CSHL_API_GENERATE          (1u)

#define CapSenseSlider_CMOD_PREGARGE_OPTION       (1u)
#define CapSenseSlider_CSH_TANK_PREGARGE_OPTION   (1u)
#define CapSenseSlider_IS_SHIELD_ENABLE           (0u)
#define CapSenseSlider_CSH_TANK_ENABLE            (0u)

#define CapSenseSlider_SHIELD_DELAY               (0u)
#define CapSenseSlider_AUTOCALIBRATION_ENABLE     (0u)

#define CapSenseSlider_IS_OVERSAMPLING_EN         (1u)

#define CapSenseSlider_CSD_4B_PWM_MODE            (0u)
#define CapSenseSlider_CSD_4B_PWM_COUNT           (0u)

/**************************************
*    Enumerated Types and Parameters
**************************************/

/* Current source definitions */
#define CapSenseSlider__IDAC_SOURCE 0
#define CapSenseSlider__IDAC_SINK 1

#define CapSenseSlider__IDAC_4X 0
#define CapSenseSlider__IDAC_8X 1

#define CapSenseSlider__PRS_NONE 0
#define CapSenseSlider__PRS_8BITS 1
#define CapSenseSlider__PRS_12BITS 2
#define CapSenseSlider__PRS_AUTO 3

/* Connection of inactive sensors definitions */
#define CapSenseSlider__GROUND 0
#define CapSenseSlider__HIZ_ANALOG 1
#define CapSenseSlider__SHIELD 2

/* Precharge options definitions */
#define CapSenseSlider__CAPPRIOBUF 0
#define CapSenseSlider__CAPPRVREF 1

/* Method of tuning */
#define CapSenseSlider__TUNING_NONE 0
#define CapSenseSlider__TUNING_MANUAL 1
#define CapSenseSlider__TUNING_AUTO 2

/* Dead band PWM modulator options */
#define CapSenseSlider__PWM_OFF 0
#define CapSenseSlider__PWM_HIGH 2
#define CapSenseSlider__PWM_LOW 3


#define CapSenseSlider_DELAY_EXTRACYCLES_NUM          (9u)
#define CapSenseSlider_GLITCH_ELIMINATION_TIMEOUT     (0u)
#define CapSenseSlider_GLITCH_ELIMINATION_CYCLES_CALC (CapSenseSlider_GLITCH_ELIMINATION_TIMEOUT * CYDEV_BCLK__SYSCLK__MHZ)

#if(CapSenseSlider_GLITCH_ELIMINATION_CYCLES_CALC >= CapSenseSlider_DELAY_EXTRACYCLES_NUM)
    #define CapSenseSlider_GLITCH_ELIMINATION_CYCLES (CapSenseSlider_GLITCH_ELIMINATION_CYCLES_CALC -\
                                                        CapSenseSlider_DELAY_EXTRACYCLES_NUM)
#else
    #define CapSenseSlider_GLITCH_ELIMINATION_CYCLES (CapSenseSlider_GLITCH_ELIMINATION_CYCLES_CALC)
#endif /* (CapSenseSlider_GLITCH_ELIMINATION_CYCLES_CALC >= CapSenseSlider_DELAY_EXTRACYCLES_NUM) */

#define CapSenseSlider_INITIAL_CLK_DIVIDER            (CYDEV_BCLK__HFCLK__KHZ / CYDEV_BCLK__SYSCLK__KHZ)


/* Structure to save registers before going to sleep */
typedef struct
{
    uint8 enableState;
} CapSenseSlider_BACKUP_STRUCT;


/***************************************
*        Function Prototypes
***************************************/
void CapSenseSlider_Init(void);
void CapSenseSlider_CsdHwBlockInit(void);
void CapSenseSlider_Enable(void);
void CapSenseSlider_Start(void);
void CapSenseSlider_Stop(void);
void CapSenseSlider_SaveConfig(void);
void CapSenseSlider_Sleep(void);
void CapSenseSlider_RestoreConfig(void);
void CapSenseSlider_Wakeup(void);
uint32 CapSenseSlider_IsBusy(void);
void CapSenseSlider_ScanSensor(uint32 sensor);
void CapSenseSlider_ScanWidget(uint32 widget);
void CapSenseSlider_ScanEnabledWidgets(void);
uint16 CapSenseSlider_ReadSensorRaw(uint32 sensor);
void CapSenseSlider_WriteSensorRaw(uint32 sensor, uint16 value);
void CapSenseSlider_ClearSensors(void);
void CapSenseSlider_SetShieldDelay(uint32 delay);
uint32 CapSenseSlider_ReadCurrentScanningSensor(void);

uint32 CapSenseSlider_GetScanResolution(uint32 widget);
uint32 CapSenseSlider_GetSenseClkDivider(uint32 sensor);
uint32 CapSenseSlider_GetModulatorClkDivider(uint32 sensor);
uint32 CapSenseSlider_GetModulationIDAC(uint32 sensor);
uint32 CapSenseSlider_GetCompensationIDAC(uint32 sensor);
uint32 CapSenseSlider_GetIDACRange(void);

#if (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE)
    void CapSenseSlider_SetScanResolution(uint32 widget, uint32 resolution);
    void CapSenseSlider_SetSenseClkDivider(uint32 sensor, uint32 senseClk);
    void CapSenseSlider_SetModulatorClkDivider(uint32 sensor, uint32 modulatorClk);
    void CapSenseSlider_SetModulationIDAC(uint32 sensor, uint32 modIdacValue);
    void CapSenseSlider_SetCompensationIDAC(uint32 sensor, uint32 compIdacValue);
    void CapSenseSlider_SetIDACRange(uint32 iDacRange);
#endif /* (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) */


void CapSenseSlider_SetDriveModeAllPins(uint32 driveMode);
void CapSenseSlider_RestoreDriveModeAllPins(void);
void CapSenseSlider_SetUnscannedSensorState(uint32 sensor, uint32 sensorState);
void CapSenseSlider_NormalizeWidgets(uint32 widgetsNum, uint8 dataPtr[]);

/***************************************
*           API Constants
***************************************/

/* PWM Resolution */
#define CapSenseSlider_CNT_MSB_RESOLUTION_8_BITS  (0x00u)
#define CapSenseSlider_CNT_MSB_RESOLUTION_9_BITS  (0x01u)
#define CapSenseSlider_CNT_MSB_RESOLUTION_10_BITS (0x03u)
#define CapSenseSlider_CNT_MSB_RESOLUTION_11_BITS (0x07u)
#define CapSenseSlider_CNT_MSB_RESOLUTION_12_BITS (0x0Fu)
#define CapSenseSlider_CNT_MSB_RESOLUTION_13_BITS (0x1Fu)
#define CapSenseSlider_CNT_MSB_RESOLUTION_14_BITS (0x3Fu)
#define CapSenseSlider_CNT_MSB_RESOLUTION_15_BITS (0x7Fu)
#define CapSenseSlider_CNT_MSB_RESOLUTION_16_BITS (0xFFu)

#define CapSenseSlider_ONE_CYCLE                  (0x00010000Lu)

#define CapSenseSlider_WINDOW_APPEND              (0xFFFF0000Lu)
#define CapSenseSlider_RESOLUTION_6_BITS          (0x003F0000Lu)
#define CapSenseSlider_RESOLUTION_7_BITS          (0x007F0000Lu)
#define CapSenseSlider_RESOLUTION_8_BITS          (0x00FF0000Lu)
#define CapSenseSlider_RESOLUTION_9_BITS          (0x01FF0000Lu)
#define CapSenseSlider_RESOLUTION_10_BITS         (0x03FF0000Lu)
#define CapSenseSlider_RESOLUTION_11_BITS         (0x07FF0000Lu)
#define CapSenseSlider_RESOLUTION_12_BITS         (0x0FFF0000Lu)
#define CapSenseSlider_RESOLUTION_13_BITS         (0x1FFF0000Lu)
#define CapSenseSlider_RESOLUTION_14_BITS         (0x3FFF0000Lu)
#define CapSenseSlider_RESOLUTION_15_BITS         (0x7FFF0000Lu)
#define CapSenseSlider_RESOLUTION_16_BITS         (0xFFFF0000Lu)

#define CapSenseSlider_RESOLUTION_OFFSET          (16u)
#define CapSenseSlider_MSB_RESOLUTION_OFFSET      (22u)
#define CapSenseSlider_RESOLUTIONS_TBL_SIZE       (1u)

/* Software Status Register Bit Masks */
#define CapSenseSlider_SW_STS_BUSY                (0x01u)
/* Software Control Register Bit Masks */
#define CapSenseSlider_SW_CTRL_SINGLE_SCAN        (0x80u)

/* Software Control Register Bit Masks for scanning one widget */
#define CapSenseSlider_SW_CTRL_WIDGET_SCAN        (0x40u)

/* Flag for complex scan slot */
#define CapSenseSlider_COMPLEX_SS_FLAG            (0x80u)

/* Flag for scanning is complete */
#define CapSenseSlider_NOT_SENSOR                 (0xFFFFFFFFLu)

/* Number of bits for each pin in PC register. */
#define CapSenseSlider_PC_PIN_CFG_SIZE            (0x03u)

/* Number of bits for each pin in HSIOM register. */
#define CapSenseSlider_HSIOM_PIN_CFG_SIZE         (0x04u)

#define CapSenseSlider_CFG_REG_TBL_SIZE           (5u)

/***************************************
*             Registers
***************************************/

#define CapSenseSlider_CSD_ID_REG             (*(reg32 *)  CapSenseSlider_CSD_FFB__CSD_ID)
#define CapSenseSlider_CSD_ID_PTR             ( (reg32 *)  CapSenseSlider_CSD_FFB__CSD_ID)

#define CapSenseSlider_CSD_CFG_REG            (*(reg32 *)  CapSenseSlider_CSD_FFB__CSD_CONFIG)
#define CapSenseSlider_CSD_CFG_PTR            ( (reg32 *)  CapSenseSlider_CSD_FFB__CSD_CONFIG)

#define CapSenseSlider_CSD_IDAC_REG           (*(reg32 *)  CapSenseSlider_IDAC1_cy_psoc4_idac__CSD_IDAC)
#define CapSenseSlider_CSD_IDAC_PTR           ( (reg32 *)  CapSenseSlider_IDAC1_cy_psoc4_idac__CSD_IDAC)

#define CapSenseSlider_CSD_CNT_REG            (*(reg32 *) CapSenseSlider_CSD_FFB__CSD_COUNTER)
#define CapSenseSlider_CSD_CNT_PTR            ( (reg32 *) CapSenseSlider_CSD_FFB__CSD_COUNTER)

#define CapSenseSlider_CSD_STAT_REG           (*(reg32 *) CapSenseSlider_CSD_FFB__CSD_STATUS)
#define CapSenseSlider_CSD_STAT_PTR           ( (reg32 *) CapSenseSlider_CSD_FFB__CSD_STATUS)

#define CapSenseSlider_CSD_INTR_REG           (*(reg32 *) CapSenseSlider_CSD_FFB__CSD_INTR)
#define CapSenseSlider_CSD_INTR_PTR           ( (reg32 *) CapSenseSlider_CSD_FFB__CSD_INTR)

#define CapSenseSlider_CSD_INTR_SET_REG       (*(reg32 *) CapSenseSlider_CSD_FFB__CSD_INTR_SET)
#define CapSenseSlider_CSD_INTR_SET_PTR       ( (reg32 *) CapSenseSlider_CSD_FFB__CSD_INTR_SET)

#define CapSenseSlider_CSD_4B_PWM_REG         (*(reg32 *) CapSenseSlider_CSD_FFB__CSD_PWM)
#define CapSenseSlider_CSD_4B_PWM_PTR         ( (reg32 *) CapSenseSlider_CSD_FFB__CSD_PWM)

#define CapSenseSlider_CSD_TRIM1_REG          (*(reg32 *) CapSenseSlider_IDAC1_cy_psoc4_idac__CSD_TRIM1)
#define CapSenseSlider_CSD_TRIM1_PTR          ( (reg32 *) CapSenseSlider_IDAC1_cy_psoc4_idac__CSD_TRIM1)

#define CapSenseSlider_CSD_TRIM2_REG          (*(reg32 *) CapSenseSlider_IDAC1_cy_psoc4_idac__CSD_TRIM2)
#define CapSenseSlider_CSD_TRIM2_PTR          ( (reg32 *) CapSenseSlider_IDAC1_cy_psoc4_idac__CSD_TRIM2)

#if (2u == CapSenseSlider_M0S8CSD_BLOCK_CNT)
    #if (CapSenseSlider_CSD_FFB__CSD_NUMBER != 1u)
        #define CapSenseSlider_SFLASH_CSD_TRIM1_REG   (*(reg8 *) CYREG_SFLASH_CSD_TRIM1_CSD)
        #define CapSenseSlider_SFLASH_CSD_TRIM1_PTR   ( (reg8 *) CYREG_SFLASH_CSD_TRIM1_CSD)

        #define CapSenseSlider_SFLASH_CSD_TRIM2_REG   (*(reg8 *) CYREG_SFLASH_CSD_TRIM2_CSD)
        #define CapSenseSlider_SFLASH_CSD_TRIM2_PTR   ( (reg8 *) CYREG_SFLASH_CSD_TRIM2_CSD)
    #else
        #define CapSenseSlider_SFLASH_CSD_TRIM1_REG   (*(reg8 *) CYREG_SFLASH_CSD1_TRIM1_CSD)
        #define CapSenseSlider_SFLASH_CSD_TRIM1_PTR   ( (reg8 *) CYREG_SFLASH_CSD1_TRIM1_CSD)

        #define CapSenseSlider_SFLASH_CSD_TRIM2_REG   (*(reg8 *) CYREG_SFLASH_CSD1_TRIM2_CSD)
        #define CapSenseSlider_SFLASH_CSD_TRIM2_PTR   ( (reg8 *) CYREG_SFLASH_CSD1_TRIM2_CSD)
    #endif /* (CapSenseSlider_CSD_FFB__CSD_NUMBER != 1u) */
#else
    #define CapSenseSlider_SFLASH_CSD_TRIM1_REG   (*(reg8 *) CYREG_SFLASH_CSD_TRIM1_CSD)
    #define CapSenseSlider_SFLASH_CSD_TRIM1_PTR   ( (reg8 *) CYREG_SFLASH_CSD_TRIM1_CSD)

    #define CapSenseSlider_SFLASH_CSD_TRIM2_REG   (*(reg8 *) CYREG_SFLASH_CSD_TRIM2_CSD)
    #define CapSenseSlider_SFLASH_CSD_TRIM2_PTR   ( (reg8 *) CYREG_SFLASH_CSD_TRIM2_CSD)
#endif /* (2u == CapSenseSlider_M0S8CSD_BLOCK_CNT) */

/* Port function select */
#define CapSenseSlider_PORT_SEL0_REG          (*(reg32 *) CYREG_HSIOM_PORT_SEL0 )
#define CapSenseSlider_PORT_SEL0_PTR          (*(reg32 *) CYREG_HSIOM_PORT_SEL0 )

#define CapSenseSlider_PORT_SEL1_REG          (*(reg32 *) CYREG_HSIOM_PORT_SEL1 )
#define CapSenseSlider_PORT_SEL1_PTR          (*(reg32 *) CYREG_HSIOM_PORT_SEL1 )

#define CapSenseSlider_PORT_SEL2_REG          (*(reg32 *) CYREG_HSIOM_PORT_SEL2 )
#define CapSenseSlider_PORT_SEL2_PTR          (*(reg32 *) CYREG_HSIOM_PORT_SEL2 )

#define CapSenseSlider_PORT_SEL3_REG          (*(reg32 *) CYREG_HSIOM_PORT_SEL3 )
#define CapSenseSlider_PORT_SEL3_PTR          (*(reg32 *) CYREG_HSIOM_PORT_SEL3 )

#define CapSenseSlider_PORT_SEL4_REG          (*(reg32 *) CYREG_HSIOM_PORT_SEL4 )
#define CapSenseSlider_PORT_SEL4_PTR          (*(reg32 *) CYREG_HSIOM_PORT_SEL4 )


#define CapSenseSlider_PORT0_PC_REG          (*(reg32 *) CYREG_PRT0_PC )
#define CapSenseSlider_PORT0_PC_PTR          (*(reg32 *) CYREG_PRT0_PC )

#define CapSenseSlider_PORT1_PC_REG          (*(reg32 *) CYREG_PRT1_PC )
#define CapSenseSlider_PORT1_PC_PTR          (*(reg32 *) CYREG_PRT1_PC )

#define CapSenseSlider_PORT2_PC_REG          (*(reg32 *) CYREG_PRT2_PC )
#define CapSenseSlider_PORT2_PC_PTR          (*(reg32 *) CYREG_PRT2_PC )

#define CapSenseSlider_PORT3_PC_REG          (*(reg32 *) CYREG_PRT3_PC )
#define CapSenseSlider_PORT3_PC_PTR          (*(reg32 *) CYREG_PRT3_PC )

#define CapSenseSlider_PORT4_PC_REG          (*(reg32 *) CYREG_PRT4_PC )
#define CapSenseSlider_PORT4_PC_PTR          (*(reg32 *) CYREG_PRT4_PC )


#define CapSenseSlider_PORT0_DR_REG          (*(reg32 *) CYREG_PRT0_DR )
#define CapSenseSlider_PORT0_DR_PTR          (*(reg32 *) CYREG_PRT0_DR )

#define CapSenseSlider_PORT1_DR_REG          (*(reg32 *) CYREG_PRT1_DR )
#define CapSenseSlider_PORT1_DR_PTR          (*(reg32 *) CYREG_PRT1_DR )

#define CapSenseSlider_PORT2_DR_REG          (*(reg32 *) CYREG_PRT2_DR )
#define CapSenseSlider_PORT2_DR_PTR          (*(reg32 *) CYREG_PRT2_DR )

#define CapSenseSlider_PORT3_DR_REG          (*(reg32 *) CYREG_PRT3_DR )
#define CapSenseSlider_PORT3_DR_PTR          (*(reg32 *) CYREG_PRT3_DR )

#define CapSenseSlider_PORT4_DR_REG          (*(reg32 *) CYREG_PRT4_DR )
#define CapSenseSlider_PORT4_DR_PTR          (*(reg32 *) CYREG_PRT4_DR )



#define CapSenseSlider_CMOD_CONNECTION_REG        (*(reg32 *) CapSenseSlider_Cmod__0__HSIOM)
#define CapSenseSlider_CMOD_PORT_PC_REG           (*(reg32 *) CapSenseSlider_Cmod__0__PC)
#define CapSenseSlider_CMOD_PORT_DR_REG           (*(reg32 *) CapSenseSlider_Cmod__0__DR)

#define CapSenseSlider_CTANK_CONNECTION_REG       (*(reg32 *) CapSenseSlider_Csh_tank__0__HSIOM)
#define CapSenseSlider_CTANK_PORT_PC_REG          (*(reg32 *) CapSenseSlider_Csh_tank__0__PC)
#define CapSenseSlider_CTANK_PORT_DR_REG          (*(reg32 *) CapSenseSlider_Csh_tank__0__DR)

/***************************************
*       Register Constants
***************************************/

/* Port configuration defines */
#define CapSenseSlider_CSD_HSIOM_MASK                 (0x0000000FLu)

#define CapSenseSlider_CSD_SENSE_PORT_MODE            (0x00000004Lu)
#define CapSenseSlider_CSD_SHIELD_PORT_MODE           (0x00000005Lu)

#define CapSenseSlider_AMUXA_CONNECTION_MODE          (0x00000006Lu)
#define CapSenseSlider_AMUXB_CONNECTION_MODE          (0x00000007Lu)

#define CapSenseSlider_CSD_PIN_MODE_MASK              (0x00000007Lu)
#define CapSenseSlider_CSD_PIN_DRIVE_MASK             (0x00000001Lu)

#define CapSenseSlider_CSD_PIN_DM_STRONG              (0x00000006Lu)
#define CapSenseSlider_CSD_PIN_DM_HIGH_Z              (0x00000000Lu)

#define CapSenseSlider_CSD_CMOD_CONNECTION_MASK   (uint32)(CapSenseSlider_Cmod__0__HSIOM_MASK)
#define CapSenseSlider_CSD_CMOD_TO_AMUXBUS_A      (uint32)(CapSenseSlider_AMUXA_CONNECTION_MODE << CapSenseSlider_Cmod__0__HSIOM_SHIFT)
#define CapSenseSlider_CSD_CMOD_TO_AMUXBUS_B      (uint32)(CapSenseSlider_AMUXB_CONNECTION_MODE << CapSenseSlider_Cmod__0__HSIOM_SHIFT)

#if(0u != CapSenseSlider_CSH_TANK_ENABLE)
    #define CapSenseSlider_CSD_CTANK_CONNECTION_MASK  (uint32)(CapSenseSlider_Csh_tank__0__HSIOM_MASK)
    #define CapSenseSlider_CSD_CTANK_TO_AMUXBUS_A     (uint32)(CapSenseSlider_AMUXA_CONNECTION_MODE << CapSenseSlider_Csh_tank__0__HSIOM_SHIFT)
    #define CapSenseSlider_CSD_CTANK_TO_AMUXBUS_B     (uint32)(CapSenseSlider_AMUXB_CONNECTION_MODE << CapSenseSlider_Csh_tank__0__HSIOM_SHIFT)
#endif /* (0u != CapSenseSlider_CSH_TANK_ENABLE) */

#define  CapSenseSlider_CSD_CMOD_PC_MASK          (uint32)(CapSenseSlider_CSD_PIN_MODE_MASK <<\
                                                            ((uint32)CapSenseSlider_Cmod__0__SHIFT * CapSenseSlider_PC_PIN_CFG_SIZE))
#define  CapSenseSlider_CMOD_PC_STRONG_MODE       (uint32)(CapSenseSlider_CSD_PIN_DM_STRONG <<\
                                                            ((uint32)CapSenseSlider_Cmod__0__SHIFT * CapSenseSlider_PC_PIN_CFG_SIZE))
#define  CapSenseSlider_CMOD_PC_HIGH_Z_MODE       (uint32)(CapSenseSlider_CSD_PIN_DM_HIGH_Z <<\
                                                            ((uint32)CapSenseSlider_Cmod__0__SHIFT * CapSenseSlider_PC_PIN_CFG_SIZE))

#if(0u != CapSenseSlider_CSH_TANK_ENABLE)
    #define  CapSenseSlider_CSD_CTANK_PC_MASK         (uint32)(CapSenseSlider_CSD_PIN_MODE_MASK <<\
                                                                ((uint32)CapSenseSlider_Csh_tank__0__SHIFT * CapSenseSlider_PC_PIN_CFG_SIZE))
    #define  CapSenseSlider_CTANK_PC_STRONG_MODE      (uint32)(CapSenseSlider_CSD_PIN_DM_STRONG <<\
                                                                ((uint32)CapSenseSlider_Csh_tank__0__SHIFT * CapSenseSlider_PC_PIN_CFG_SIZE))
    #define  CapSenseSlider_CTANK_PC_HIGH_Z_MODE      (uint32)(CapSenseSlider_CSD_PIN_DM_HIGH_Z <<\
                                                                ((uint32)CapSenseSlider_Csh_tank__0__SHIFT * CapSenseSlider_PC_PIN_CFG_SIZE))
#endif /* (0u != CapSenseSlider_CSH_TANK_ENABLE) */

#define  CapSenseSlider_CMOD_DR_VSSIO             (uint32)(CapSenseSlider_Cmod__0__MASK)
#define  CapSenseSlider_CMOD_DR_VDDIO             (0x00000000Lu)
#define  CapSenseSlider_CMOD_DR_MASK              (uint32)(CapSenseSlider_Cmod__0__MASK)

#if(0u != CapSenseSlider_CSH_TANK_ENABLE)
    #define  CapSenseSlider_CTANK_DR_VSSIO            (uint32)(CapSenseSlider_Csh_tank__0__MASK)
    #define  CapSenseSlider_CTANK_DR_VDDIO            (0x00000000Lu)
    #define  CapSenseSlider_CTANK_DR_MASK             (uint32)(CapSenseSlider_Csh_tank__0__MASK)
#endif /* (0u != CapSenseSlider_CSH_TANK_ENABLE) */

#define  CapSenseSlider_CMOD_PIN_NUMBER               (CapSenseSlider_Cmod__0__SHIFT)
#define  CapSenseSlider_CMOD_PRT_NUMBER               (CapSenseSlider_Cmod__0__PORT)

#if(0u != CapSenseSlider_CSH_TANK_ENABLE)
    #define  CapSenseSlider_CTANK_PIN_NUMBER          (CapSenseSlider_Csh_tank__0__SHIFT)
    #define  CapSenseSlider_CTANK_PRT_NUMBER          (CapSenseSlider_Csh_tank__0__PORT)
#endif /* (0u != CapSenseSlider_CSH_TANK_ENABLE) */

/* ID register fields position */
#define CapSenseSlider_CSD_ID_ID__POS                 (0x00u)
#define CapSenseSlider_CSD_ID_REV__POS                (0x10u)

#define CapSenseSlider_CSD_ID_ID                      (0xFFLu << CapSenseSlider_CSD_ID_ID__POS)
#define CapSenseSlider_CSD_ID_REV                     (0xFFLu << CapSenseSlider_CSD_ID_REV__POS)

/* CSD_CONFIG register fields position */
#define CapSenseSlider_CSD_CFG_DSI_SAMPLE_EN_POS      (0x00u)
#define CapSenseSlider_CSD_CFG_SAMPLE_SYNC_POS        (0x01u)
#define CapSenseSlider_CSD_CFG_FILTER_EN_POS          (0x03u)
#define CapSenseSlider_CSD_CFG_PRS_CLEAR_POS          (0x05u)
#define CapSenseSlider_CSD_CFG_PRS_SELECT_POS         (0x06u)
#define CapSenseSlider_CSD_CFG_PRS_12_8_POS           (0x07u)
#define CapSenseSlider_CSD_CFG_DSI_SENSE_EN_POS       (0x08u)
#define CapSenseSlider_CSD_CFG_SHIELD_DELAY_POS       (0x09u)
#define CapSenseSlider_CSD_CFG_SENSE_COMP_BW_POS      (0x0Bu)
#define CapSenseSlider_CSD_CFG_SENSE_EN_POS           (0x0Cu)
#define CapSenseSlider_CSD_CFG_REFBUF_EN_POS          (0x0Du)
#define CapSenseSlider_CSD_CFG_CHARGE_IO_POS          (0x0Eu)
#define CapSenseSlider_CSD_CFG_COMP_PIN_POS           (0x0Fu)
#define CapSenseSlider_CSD_CFG_POLARITY_POS           (0x10u)
#define CapSenseSlider_CSD_CFG_MUTUAL_CAP_POS         (0x12u)
#define CapSenseSlider_CSD_CFG_SENSE_COMP_EN_POS      (0x13u)
#define CapSenseSlider_CSD_CFG_REFBUF_OUTSEL_POS      (0x15u)
#define CapSenseSlider_CSD_CFG_SENSE_INSEL_POS        (0x16u)
#define CapSenseSlider_CSD_REFBUF_DRV_POS             (0x17u)
#define CapSenseSlider_CSD_CFG_DDFTSEL_POS            (0x1Au)
#define CapSenseSlider_CSD_CFG_ADFTEN_POS             (0x1Du)
#define CapSenseSlider_CSD_CFG_DDFTCOMP_POS           (0x1Eu)
#define CapSenseSlider_CSD_CFG_ENABLE_POS             (0x1Fu)

/* CSD_STATUS register fields position */
#define CapSenseSlider_CSD_STAT_CSD_CHARGE_POS        (0x00u)
#define CapSenseSlider_CSD_STAT_CSD_SENSE_POS         (0x01u)
#define CapSenseSlider_CSD_STAT_COMP_OUT_POS          (0x02u)
#define CapSenseSlider_CSD_STAT_SAMPLE_POS            (0x03u)

/* CSD_IDAC control register fields position */
#define CapSenseSlider_CSD_IDAC1_MODE_MASK_POS        (0x08u)
#define CapSenseSlider_CSD_IDAC1_MODE_FIXED_POS       (0x08u)
#define CapSenseSlider_CSD_IDAC1_MODE_VARIABLE_POS    (0x08u)
#define CapSenseSlider_CSD_IDAC1_MODE_DSI_POS         (0x08u)
#define CapSenseSlider_CSD_IDAC1_RANGE_8X_POS         (0x0Au)
#define CapSenseSlider_CSD_IDAC1_DATA_MASK_POS        (0x00u)

#define CapSenseSlider_CSD_IDAC2_MODE_MASK_POS        (0x18u)
#define CapSenseSlider_CSD_IDAC2_MODE_FIXED_POS       (0x18u)
#define CapSenseSlider_CSD_IDAC2_MODE_VARIABLE_POS    (0x18u)
#define CapSenseSlider_CSD_IDAC2_MODE_DSI_POS         (0x18u)
#define CapSenseSlider_CSD_IDAC2_RANGE_8X_POS         (0x1Au)
#define CapSenseSlider_CSD_IDAC2_DATA_MASK_POS        (0x10u)

/* CSD_COUNTER register fields position */
#define CapSenseSlider_CSD_CNT_COUNTER_POS            (0x00u)
#define CapSenseSlider_CSD_CNT_PERIOD_POS             (0x10u)

/* CSD_CONFIRG register definitions */
#define CapSenseSlider_CSD_CFG_DSI_SAMPLE_EN          (0x01Lu << CapSenseSlider_CSD_CFG_DSI_SAMPLE_EN_POS)
#define CapSenseSlider_CSD_CFG_SAMPLE_SYNC            (0x01Lu << CapSenseSlider_CSD_CFG_SAMPLE_SYNC_POS)
#define CapSenseSlider_CSD_CFG_FILTER_EN              (0x01Lu << CapSenseSlider_CSD_CFG_FILTER_EN_POS)
#define CapSenseSlider_CSD_CFG_PRS_CLEAR              (0x01Lu << CapSenseSlider_CSD_CFG_PRS_CLEAR_POS)
#define CapSenseSlider_CSD_CFG_PRS_SELECT             (0x01Lu << CapSenseSlider_CSD_CFG_PRS_SELECT_POS)
#define CapSenseSlider_CSD_CFG_PRS_12_8               (0x01Lu << CapSenseSlider_CSD_CFG_PRS_12_8_POS)
#define CapSenseSlider_CSD_CFG_DSI_SENSE_EN           (0x01Lu << CapSenseSlider_CSD_CFG_DSI_SENSE_EN_POS)
#define CapSenseSlider_CSD_CFG_SHIELD_DELAY_MASK      (0x03Lu << CapSenseSlider_CSD_CFG_SHIELD_DELAY_POS)
#define CapSenseSlider_CSD_CFG_SENSE_COMP_BW          (0x01Lu << CapSenseSlider_CSD_CFG_SENSE_COMP_BW_POS)
#define CapSenseSlider_CSD_CFG_SENSE_EN               (0x01Lu << CapSenseSlider_CSD_CFG_SENSE_EN_POS)
#define CapSenseSlider_CSD_CFG_REFBUF_EN              (0x01Lu << CapSenseSlider_CSD_CFG_REFBUF_EN_POS)
#define CapSenseSlider_CSD_CFG_CHARGE_IO              (0x01Lu << CapSenseSlider_CSD_CFG_CHARGE_IO_POS)
#define CapSenseSlider_CSD_CFG_COMP_PIN_CH2           (0x01Lu << CapSenseSlider_CSD_CFG_COMP_PIN_POS)
#define CapSenseSlider_CSD_CFG_POLARITY_VDDIO         (0x01Lu << CapSenseSlider_CSD_CFG_POLARITY_POS)
#define CapSenseSlider_CSD_CFG_MUTUAL_CAP             (0x01Lu << CapSenseSlider_CSD_CFG_MUTUAL_CAP_POS)
#define CapSenseSlider_CSD_CFG_SENSE_COMP_EN          (0x01Lu << CapSenseSlider_CSD_CFG_SENSE_COMP_EN_POS)
#define CapSenseSlider_CSD_CFG_REFBUF_OUTSEL          (0x01Lu << CapSenseSlider_CSD_CFG_REFBUF_OUTSEL_POS)
#define CapSenseSlider_CSD_CFG_SENSE_INSEL            (0x01Lu << CapSenseSlider_CSD_CFG_SENSE_INSEL_POS)
#define CapSenseSlider_CSD_REFBUF_DRV_MASK            (0x03Lu << CapSenseSlider_CSD_REFBUF_DRV_POS)
#define CapSenseSlider_CSD_REFBUF_DRV_LOW             (0x01Lu << CapSenseSlider_CSD_REFBUF_DRV_POS)
#define CapSenseSlider_CSD_REFBUF_DRV_MEDIUM          (0x02Lu << CapSenseSlider_CSD_REFBUF_DRV_POS)
#define CapSenseSlider_CSD_REFBUF_DRV_HIGH            (0x03Lu << CapSenseSlider_CSD_REFBUF_DRV_POS)
#define CapSenseSlider_CSD_CFG_DDFTSEL_MASK           (0x07Lu << CapSenseSlider_CSD_CFG_DDFTSEL_POS)
#define CapSenseSlider_CSD_CFG_ADFTEN                 (0x01Lu << CapSenseSlider_CSD_CFG_ADFTEN_POS)
#define CapSenseSlider_CSD_CFG_DDFTCOMP_MASK          (0x03Lu << CapSenseSlider_CSD_CFG_DDFTCOMP_POS)
#define CapSenseSlider_CSD_CFG_DDFTCOMP_REFCOMP       (0x01Lu << CapSenseSlider_CSD_CFG_DDFTCOMP_POS)
#define CapSenseSlider_CSD_CFG_DDFTCOMP_SENSECOMP     (0x02Lu << CapSenseSlider_CSD_CFG_DDFTCOMP_POS)
#define CapSenseSlider_CSD_CFG_ENABLE                 (0x01Lu << CapSenseSlider_CSD_CFG_ENABLE_POS)

/* CSD_STATUS register definitions */
#define CapSenseSlider_CSD_STAT_CSD_CHARGE            (0x01Lu << CapSenseSlider_CSD_STAT_CSD_CHARGE_POS)
#define CapSenseSlider_CSD_STAT_CSD_SENSE             (0x01Lu << CapSenseSlider_CSD_STAT_CSD_SENSE_POS)
#define CapSenseSlider_CSD_STAT_COMP_OUT              (0x01Lu << CapSenseSlider_CSD_STAT_COMP_OUT_POS)
#define CapSenseSlider_CSD_STAT_SAMPLE                (0x01Lu << CapSenseSlider_CSD_STAT_SAMPLE_POS)

/* CSD_IDAC control register definitions */
#define CapSenseSlider_CSD_IDAC1_MODE_MASK            (0x03Lu << CapSenseSlider_CSD_IDAC1_MODE_MASK_POS)
#define CapSenseSlider_CSD_IDAC1_MODE_FIXED           (0x01Lu << CapSenseSlider_CSD_IDAC1_MODE_FIXED_POS)
#define CapSenseSlider_CSD_IDAC1_MODE_VARIABLE        (0x02Lu << CapSenseSlider_CSD_IDAC1_MODE_VARIABLE_POS)
#define CapSenseSlider_CSD_IDAC1_MODE_DSI             (0x03Lu << CapSenseSlider_CSD_IDAC1_MODE_DSI_POS)
#define CapSenseSlider_CSD_IDAC1_RANGE_8X             (0x01Lu << CapSenseSlider_CSD_IDAC1_RANGE_8X_POS)
#define CapSenseSlider_CSD_IDAC1_DATA_MASK            (0xFFLu << CapSenseSlider_CSD_IDAC1_DATA_MASK_POS)

#define CapSenseSlider_CSD_IDAC2_MODE_MASK            (0x03Lu << CapSenseSlider_CSD_IDAC2_MODE_MASK_POS)
#define CapSenseSlider_CSD_IDAC2_MODE_FIXED           (0x01Lu << CapSenseSlider_CSD_IDAC2_MODE_FIXED_POS)
#define CapSenseSlider_CSD_IDAC2_MODE_VARIABLE        (0x02Lu << CapSenseSlider_CSD_IDAC2_MODE_VARIABLE_POS)
#define CapSenseSlider_CSD_IDAC2_MODE_DSI             (0x03Lu << CapSenseSlider_CSD_IDAC2_MODE_DSI_POS)
#define CapSenseSlider_CSD_IDAC2_RANGE_8X             (0x01Lu << CapSenseSlider_CSD_IDAC2_RANGE_8X_POS)
#define CapSenseSlider_CSD_IDAC2_DATA_MASK            (0x7FLu << CapSenseSlider_CSD_IDAC2_DATA_MASK_POS)

#define CapSenseSlider_CSD_IDAC2_DATA_OFFSET          (16u)

#define CapSenseSlider_CSD_IDAC1_TRIM_MASK            (0xFFFFFFF0u)
#define CapSenseSlider_CSD_IDAC2_TRIM_MASK            (0xFFFFFF0Fu)

#define CapSenseSlider_CSFLASH_TRIM_IDAC1_MASK        (0x0Fu)
#define CapSenseSlider_CSFLASH_TRIM_IDAC2_MASK        (0xF0)

#define CapSenseSlider_CSD_4B_PWM_MODE_OFFSET         (4u)
#define CapSenseSlider_CSD_4B_PWM_MODE_DEFAULT        (CapSenseSlider_CSD_4B_PWM_MODE << CapSenseSlider_CSD_4B_PWM_MODE_OFFSET)

#define CapSenseSlider_CSD_4B_PWM_COUNT_MASK          (0x0000000Fu)
#define CapSenseSlider_CSD_4B_PWM_MODE_MASK           (0x00000030u)

#define CapSenseSlider_CSD_IDAC_PRECHARGE_CONFIG      (CapSenseSlider_CSD_IDAC1_MODE_FIXED |\
                                                        CapSenseSlider_PRECHARGE_IDAC1_VAL)

/* CSD_COUNTER register definitions */
#define CapSenseSlider_CSD_CNT_COUNTER                (0xFFLu << CapSenseSlider_CSD_CNT_COUNTER_POS )
#define CapSenseSlider_CSD_CNT_PERIOD                 (0xFFLu << CapSenseSlider_CSD_CNT_PERIOD_POS)

#define CapSenseSlider_CSD_PRS_8_BIT                  (0x00000000u)
#define CapSenseSlider_CSD_PRS_12_BIT                 (CapSenseSlider_CSD_CFG_PRS_12_8)
#define CapSenseSlider_PRS_MODE_MASK                  (CapSenseSlider_CSD_CFG_PRS_12_8)

/***************************************
*    Initial Parameter Constants
***************************************/

#if (0u != CapSenseSlider_FILTER_ENABLE)
    #define CapSenseSlider_DEFAULT_FILTER_STATE       (CapSenseSlider_CSD_CFG_FILTER_EN)

#else
    #define CapSenseSlider_DEFAULT_FILTER_STATE       (0u)

#endif /* (CapSenseSlider_PRS_OPTIONS == CapSenseSlider_PRS_8BITS) */

#define CapSenseSlider_DEFAULT_CSD_4B_PWM_CONFIG      (CapSenseSlider_CSD_4B_PWM_MODE_DEFAULT | CapSenseSlider_CSD_4B_PWM_COUNT)

/* Set PRS */
#if (CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_8BITS)
    #define CapSenseSlider_DEFAULT_MODULATION_MODE    CapSenseSlider_CSD_CFG_PRS_SELECT

#elif (CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_12BITS)
    #define CapSenseSlider_DEFAULT_MODULATION_MODE    (CapSenseSlider_CSD_CFG_PRS_12_8 |\
                                                        CapSenseSlider_CSD_CFG_PRS_SELECT)
#else
    #define CapSenseSlider_DEFAULT_MODULATION_MODE    (0u)
#endif /* (CapSenseSlider_PRS_OPTIONS == CapSenseSlider_PRS_8BITS) */

/* Set IDAC ranges */
#if (CapSenseSlider_IDAC1_RANGE_VALUE == CapSenseSlider__IDAC_8X)
    #define CapSenseSlider_DEFAULT_IDAC1_RANGE        CapSenseSlider_CSD_IDAC1_RANGE_8X
    #define CapSenseSlider_DEFAULT_IDAC2_RANGE        CapSenseSlider_CSD_IDAC2_RANGE_8X
#else
    #define CapSenseSlider_DEFAULT_IDAC1_RANGE        (0u)
    #define CapSenseSlider_DEFAULT_IDAC2_RANGE        (0u)
#endif /* (CapSenseSlider_IDAC1_RANGE_VALUE == CapSenseSlider_IDAC_RANGE_8X) */

/* Set IDAC polarity */
#if(CapSenseSlider_IDAC1_POLARITY == CapSenseSlider__IDAC_SINK)

    #define CapSenseSlider_DEFAULT_IDAC_POLARITY      CapSenseSlider_CSD_CFG_POLARITY_VDDIO
    #define CapSenseSlider_CMOD_DR_CONFIG             CapSenseSlider_CMOD_DR_VDDIO
    #define CapSenseSlider_CTANK_DR_CONFIG            CapSenseSlider_CTANK_DR_VDDIO
#else

    #define CapSenseSlider_DEFAULT_IDAC_POLARITY      (0u)
    #define CapSenseSlider_CMOD_DR_CONFIG             CapSenseSlider_CMOD_DR_VSSIO
    #define CapSenseSlider_CTANK_DR_CONFIG            CapSenseSlider_CTANK_DR_VSSIO
#endif /* (CapSenseSlider_IDAC_OPTIONS == CapSenseSlider_IDAC_SINK) */

#define CapSenseSlider_SNS_GROUND_CONNECT             (6u)
#define CapSenseSlider_SNS_HIZANALOG_CONNECT          (0u)

/* Inactive sensors connection configuration */
#if (CapSenseSlider_CONNECT_INACTIVE_SNS == CapSenseSlider__GROUND)
    #define CapSenseSlider_CSD_INACTIVE_CONNECT       (CapSenseSlider_SNS_GROUND_CONNECT)
#else
    #define CapSenseSlider_CSD_INACTIVE_CONNECT       (CapSenseSlider_SNS_HIZANALOG_CONNECT)
#endif /* CapSenseSlider_CONNECT_INACTIVE_SNS == CapSenseSlider__GROUND */

#if(CapSenseSlider_IS_SHIELD_ENABLE)
    #define CapSenseSlider_SHIELD_PORT_NUMBER CapSenseSlider_Shield__PORT
    #define CapSenseSlider_SHIELD_PIN_NUMBER  CapSenseSlider_Shield__SHIFT
#endif /* (CapSenseSlider_IS_SHIELD_ENABLE) */

/* Defining default CSD configuration according to settings in customizer. */
#define CapSenseSlider_DEFAULT_CSD_CONFIG             (CapSenseSlider_DEFAULT_FILTER_STATE |\
                                                         CapSenseSlider_DEFAULT_MODULATION_MODE |\
                                                         CapSenseSlider_CSD_CFG_SENSE_COMP_BW |\
                                                         CapSenseSlider_DEFAULT_IDAC_POLARITY |\
                                                         CapSenseSlider_CSD_CFG_REFBUF_OUTSEL |\
                                                         CapSenseSlider_CSD_REFBUF_DRV_HIGH)

#define CapSenseSlider_CSD_CONFIG_MASK                (CapSenseSlider_CSD_CFG_FILTER_EN |\
                                                         CapSenseSlider_CSD_CFG_PRS_SELECT |\
                                                         CapSenseSlider_CSD_CFG_PRS_12_8 |\
                                                         CapSenseSlider_CSD_CFG_SENSE_COMP_BW |\
                                                         CapSenseSlider_CSD_CFG_REFBUF_EN |\
                                                         CapSenseSlider_CSD_CFG_REFBUF_OUTSEL |\
                                                         CapSenseSlider_CSD_CFG_POLARITY_VDDIO |\
                                                         CapSenseSlider_CSD_CFG_REFBUF_OUTSEL  |\
                                                         CapSenseSlider_CSD_REFBUF_DRV_MASK)


/* Defining the default IDACs configuration according to settings in customizer. */
#if (CapSenseSlider_IDAC_CNT == 1u)
    #define CapSenseSlider_DEFAULT_CSD_IDAC_CONFIG    (CapSenseSlider_CSD_IDAC1_MODE_VARIABLE |\
                                                             CapSenseSlider_DEFAULT_IDAC1_RANGE)
#else
    #define CapSenseSlider_DEFAULT_CSD_IDAC_CONFIG    (CapSenseSlider_CSD_IDAC1_MODE_VARIABLE |\
                                                             CapSenseSlider_CSD_IDAC2_MODE_FIXED |\
                                                             CapSenseSlider_DEFAULT_IDAC1_RANGE |\
                                                             CapSenseSlider_DEFAULT_IDAC2_RANGE)
#endif /* (CapSenseSlider_IDAC_CNT == 1u) */

/* Defining mask intended for clearing bits related to pre-charging options. */
#define CapSenseSlider_PRECHARGE_CONFIG_MASK          (CapSenseSlider_CSD_CFG_REFBUF_EN |\
                                                         CapSenseSlider_CSD_CFG_CHARGE_IO |\
                                                         CapSenseSlider_CSD_CFG_COMP_PIN_CH2  |\
                                                         CapSenseSlider_CSD_CFG_REFBUF_OUTSEL)

/* Cmod the precharge mode configuration */
#if(CapSenseSlider_CMOD_PREGARGE_OPTION == CapSenseSlider__CAPPRVREF)

    #define CapSenseSlider_CMOD_PRECHARGE_CONFIG      (CapSenseSlider_CSD_CFG_REFBUF_EN |\
                                                         CapSenseSlider_CSD_CFG_COMP_PIN_CH2)

#else

    #define CapSenseSlider_CMOD_PRECHARGE_CONFIG      (CapSenseSlider_CSD_CFG_REFBUF_OUTSEL |\
                                                         CapSenseSlider_CSD_CFG_REFBUF_EN |\
                                                         CapSenseSlider_CSD_CFG_CHARGE_IO)

#endif /* (CapSenseSlider_CMOD_PREGARGE_OPTION == CapSenseSlider__CAPPRVREF) */

/* Ctank the precharge mode configuration */
#if(CapSenseSlider_CSH_TANK_PREGARGE_OPTION == CapSenseSlider__CAPPRVREF)

    #if(0u != CapSenseSlider_IS_SHIELD_ENABLE)
        #define  CapSenseSlider_CTANK_PRECHARGE_CONFIG    (CapSenseSlider_CSD_CFG_REFBUF_EN |\
                                                             CapSenseSlider_CSD_CFG_PRS_CLEAR |\
                                                             CapSenseSlider_CSD_CFG_REFBUF_OUTSEL)
    #else
        #define  CapSenseSlider_CTANK_PRECHARGE_CONFIG    (CapSenseSlider_CSD_CFG_REFBUF_OUTSEL |\
                                                             CapSenseSlider_CSD_CFG_PRS_CLEAR)
    #endif /* (0u != CapSenseSlider_IS_SHIELD_ENABLE) */

#else

    #define  CapSenseSlider_CTANK_PRECHARGE_CONFIG    (CapSenseSlider_CSD_CFG_REFBUF_OUTSEL |\
                                                         CapSenseSlider_CSD_CFG_REFBUF_EN |\
                                                         CapSenseSlider_CSD_CFG_CHARGE_IO |\
                                                         CapSenseSlider_CSD_CFG_PRS_CLEAR |\
                                                         CapSenseSlider_CSD_CFG_COMP_PIN_CH2)
#endif /* (CapSenseSlider_CSH_TANK_PREGARGE_OPTION == CapSenseSlider__CAPPRIOBUF) */

#define CapSenseSlider_MAX_UINT_8                     (0xFFu)
#define CapSenseSlider_MAX_UINT_16                    (0xFFFFu)
#define CapSenseSlider_MAX_UINT_32                    (0xFFFFFFFFLu)

/***************************************
*     Vars with External Linkage
***************************************/
/* SmartSense functions */
#if (CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO)
    extern uint8 CapSenseSlider_lowLevelTuningDone;
    extern uint8 CapSenseSlider_scanSpeedTbl[((CapSenseSlider_TOTAL_SENSOR_COUNT - 1u) / 8u) + 1u];
    extern void CapSenseSlider_AutoTune(void);
#endif /* (CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) */

#if(CapSenseSlider_PRS_OPTIONS != CapSenseSlider__PRS_NONE)
    extern uint8 CapSenseSlider_prescalersTuningDone;
#endif /* (CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_NONE) */

/* Global software variables */
extern volatile uint8 CapSenseSlider_csdStatusVar;
extern volatile uint8 CapSenseSlider_sensorIndex;
extern uint16 CapSenseSlider_sensorRaw[CapSenseSlider_TOTAL_SENSOR_COUNT];
extern uint8 CapSenseSlider_unscannedSnsDriveMode[CapSenseSlider_PORT_PIN_CONFIG_TBL_ZISE];
extern uint8 CapSenseSlider_sensorEnableMaskBackup[CapSenseSlider_TOTAL_SENSOR_MASK];
extern uint8 CapSenseSlider_sensorEnableMask[CapSenseSlider_TOTAL_SENSOR_MASK];

#if ((CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) || (0u != CapSenseSlider_AUTOCALIBRATION_ENABLE))
    extern uint8 CapSenseSlider_modulationIDAC[CapSenseSlider_TOTAL_SENSOR_COUNT];
    extern uint8 CapSenseSlider_compensationIDAC[CapSenseSlider_TOTAL_SENSOR_COUNT];
#else
    extern const uint8 CapSenseSlider_modulationIDAC[CapSenseSlider_TOTAL_SENSOR_COUNT];
    extern const uint8 CapSenseSlider_compensationIDAC[CapSenseSlider_TOTAL_SENSOR_COUNT];
#endif /* ((CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) || (0u != CapSenseSlider_AUTOCALIBRATION_ENABLE)) */

#if (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE)
    extern uint32 CapSenseSlider_widgetResolution[CapSenseSlider_RESOLUTIONS_TBL_SIZE];
    #if (0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET)
        extern uint8 CapSenseSlider_senseClkDividerVal[CapSenseSlider_TOTAL_SCANSLOT_COUNT];
        extern uint8 CapSenseSlider_sampleClkDividerVal[CapSenseSlider_TOTAL_SCANSLOT_COUNT];
    #else
        extern uint8 CapSenseSlider_senseClkDividerVal;
        extern uint8 CapSenseSlider_sampleClkDividerVal;
    #endif /* (0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET) */
#else
    extern const uint32 CapSenseSlider_widgetResolution[CapSenseSlider_RESOLUTIONS_TBL_SIZE];
    #if (0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET)
        extern const uint8 CapSenseSlider_senseClkDividerVal[CapSenseSlider_TOTAL_SCANSLOT_COUNT];
        extern const uint8 CapSenseSlider_sampleClkDividerVal[CapSenseSlider_TOTAL_SCANSLOT_COUNT];
    #else
        extern const uint8 CapSenseSlider_senseClkDividerVal;
        extern const uint8 CapSenseSlider_sampleClkDividerVal;
    #endif /* (0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET) */
#endif /* (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE)  */

extern const uint8 CapSenseSlider_widgetNumber[CapSenseSlider_TOTAL_SENSOR_COUNT];

extern reg32* const CapSenseSlider_prtSelTbl[CapSenseSlider_CFG_REG_TBL_SIZE];
extern reg32* const CapSenseSlider_prtCfgTbl[CapSenseSlider_CFG_REG_TBL_SIZE];
extern reg32* const CapSenseSlider_prtDRTbl[CapSenseSlider_CFG_REG_TBL_SIZE];
extern reg32 * CapSenseSlider_pcTable[CapSenseSlider_PORT_PIN_CONFIG_TBL_ZISE];

extern const uint8  CapSenseSlider_portTable[CapSenseSlider_PORT_PIN_CONFIG_TBL_ZISE];
extern const uint32 CapSenseSlider_maskTable[CapSenseSlider_PORT_PIN_CONFIG_TBL_ZISE];
extern const uint8  CapSenseSlider_pinShiftTbl[CapSenseSlider_PORT_PIN_CONFIG_TBL_ZISE];

#if (0u != CapSenseSlider_INDEX_TABLE_SIZE)
extern const uint8 CYCODE CapSenseSlider_indexTable[CapSenseSlider_INDEX_TABLE_SIZE];
#endif /* (0u != CapSenseSlider_INDEX_TABLE_SIZE)) */

/***************************************************
*    Obsolete Names (will be removed in future)
***************************************************/
#define  CapSenseSlider_PrescalersTuningDone         CapSenseSlider_prescalersTuningDone
#define  CapSenseSlider_SensorRaw                    CapSenseSlider_sensorRaw
#define  CapSenseSlider_PRSResolutionTbl             CapSenseSlider_prsResolutionTbl
#define  CapSenseSlider_SensorEnableMask             CapSenseSlider_sensorEnableMask
#define  CapSenseSlider_Clk1DividerVal               CapSenseSlider_senseClkDividerVal
#define  CapSenseSlider_Clk2DividerVal               CapSenseSlider_sampleClkDividerVal
#define  CapSenseSlider_PrtSelTbl                    CapSenseSlider_prtSelTbl
#define  CapSenseSlider_PrtCfgTbl                    CapSenseSlider_prtCfgTbl
#define  CapSenseSlider_PrtDRTbl                     CapSenseSlider_prtDRTbl
#define  CapSenseSlider_idac1Settings                CapSenseSlider_modulationIDAC
#define  CapSenseSlider_idac2Settings                CapSenseSlider_compensationIDAC

#endif /* CY_CAPSENSE_CSD_CapSenseSlider_H */


 /* [] END OF FILE */
