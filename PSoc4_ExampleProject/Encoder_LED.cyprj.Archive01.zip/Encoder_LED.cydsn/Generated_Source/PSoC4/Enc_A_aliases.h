/*******************************************************************************
* File Name: Enc_A.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Enc_A_ALIASES_H) /* Pins Enc_A_ALIASES_H */
#define CY_PINS_Enc_A_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Enc_A_0			(Enc_A__0__PC)
#define Enc_A_0_PS		(Enc_A__0__PS)
#define Enc_A_0_PC		(Enc_A__0__PC)
#define Enc_A_0_DR		(Enc_A__0__DR)
#define Enc_A_0_SHIFT	(Enc_A__0__SHIFT)
#define Enc_A_0_INTR	((uint16)((uint16)0x0003u << (Enc_A__0__SHIFT*2u)))

#define Enc_A_INTR_ALL	 ((uint16)(Enc_A_0_INTR))


#endif /* End Pins Enc_A_ALIASES_H */


/* [] END OF FILE */
