/*******************************************************************************
* File Name: Encoder.h
* Version 2.10
*
* Description:
*  This file provides constants and parameter values for the Encoder
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_TCPWM_Encoder_H)
#define CY_TCPWM_Encoder_H


#include "CyLib.h"
#include "cytypes.h"
#include "cyfitter.h"


/*******************************************************************************
* Internal Type defines
*******************************************************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} Encoder_BACKUP_STRUCT;


/*******************************************************************************
* Variables
*******************************************************************************/
extern uint8  Encoder_initVar;


/***************************************
*   Conditional Compilation Parameters
****************************************/

#define Encoder_CY_TCPWM_V2                    (CYIPBLOCK_m0s8tcpwm_VERSION == 2u)
#define Encoder_CY_TCPWM_4000                  (CY_PSOC4_4000)

/* TCPWM Configuration */
#define Encoder_CONFIG                         (3lu)

/* Quad Mode */
/* Parameters */
#define Encoder_QUAD_ENCODING_MODES            (1lu)
#define Encoder_QUAD_AUTO_START                (1lu)

/* Signal modes */
#define Encoder_QUAD_INDEX_SIGNAL_MODE         (0lu)
#define Encoder_QUAD_PHIA_SIGNAL_MODE          (3lu)
#define Encoder_QUAD_PHIB_SIGNAL_MODE          (3lu)
#define Encoder_QUAD_STOP_SIGNAL_MODE          (0lu)

/* Signal present */
#define Encoder_QUAD_INDEX_SIGNAL_PRESENT      (0lu)
#define Encoder_QUAD_STOP_SIGNAL_PRESENT       (0lu)

/* Interrupt Mask */
#define Encoder_QUAD_INTERRUPT_MASK            (1lu)

/* Timer/Counter Mode */
/* Parameters */
#define Encoder_TC_RUN_MODE                    (0lu)
#define Encoder_TC_COUNTER_MODE                (0lu)
#define Encoder_TC_COMP_CAP_MODE               (2lu)
#define Encoder_TC_PRESCALER                   (0lu)

/* Signal modes */
#define Encoder_TC_RELOAD_SIGNAL_MODE          (0lu)
#define Encoder_TC_COUNT_SIGNAL_MODE           (3lu)
#define Encoder_TC_START_SIGNAL_MODE           (0lu)
#define Encoder_TC_STOP_SIGNAL_MODE            (0lu)
#define Encoder_TC_CAPTURE_SIGNAL_MODE         (0lu)

/* Signal present */
#define Encoder_TC_RELOAD_SIGNAL_PRESENT       (0lu)
#define Encoder_TC_COUNT_SIGNAL_PRESENT        (0lu)
#define Encoder_TC_START_SIGNAL_PRESENT        (0lu)
#define Encoder_TC_STOP_SIGNAL_PRESENT         (0lu)
#define Encoder_TC_CAPTURE_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define Encoder_TC_INTERRUPT_MASK              (1lu)

/* PWM Mode */
/* Parameters */
#define Encoder_PWM_KILL_EVENT                 (0lu)
#define Encoder_PWM_STOP_EVENT                 (0lu)
#define Encoder_PWM_MODE                       (4lu)
#define Encoder_PWM_OUT_N_INVERT               (0lu)
#define Encoder_PWM_OUT_INVERT                 (0lu)
#define Encoder_PWM_ALIGN                      (0lu)
#define Encoder_PWM_RUN_MODE                   (0lu)
#define Encoder_PWM_DEAD_TIME_CYCLE            (0lu)
#define Encoder_PWM_PRESCALER                  (0lu)

/* Signal modes */
#define Encoder_PWM_RELOAD_SIGNAL_MODE         (0lu)
#define Encoder_PWM_COUNT_SIGNAL_MODE          (3lu)
#define Encoder_PWM_START_SIGNAL_MODE          (0lu)
#define Encoder_PWM_STOP_SIGNAL_MODE           (0lu)
#define Encoder_PWM_SWITCH_SIGNAL_MODE         (0lu)

/* Signal present */
#define Encoder_PWM_RELOAD_SIGNAL_PRESENT      (0lu)
#define Encoder_PWM_COUNT_SIGNAL_PRESENT       (0lu)
#define Encoder_PWM_START_SIGNAL_PRESENT       (0lu)
#define Encoder_PWM_STOP_SIGNAL_PRESENT        (0lu)
#define Encoder_PWM_SWITCH_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define Encoder_PWM_INTERRUPT_MASK             (1lu)


/***************************************
*    Initial Parameter Constants
***************************************/

/* Timer/Counter Mode */
#define Encoder_TC_PERIOD_VALUE                (65535lu)
#define Encoder_TC_COMPARE_VALUE               (65535lu)
#define Encoder_TC_COMPARE_BUF_VALUE           (65535lu)
#define Encoder_TC_COMPARE_SWAP                (0lu)

/* PWM Mode */
#define Encoder_PWM_PERIOD_VALUE               (65535lu)
#define Encoder_PWM_PERIOD_BUF_VALUE           (65535lu)
#define Encoder_PWM_PERIOD_SWAP                (0lu)
#define Encoder_PWM_COMPARE_VALUE              (65535lu)
#define Encoder_PWM_COMPARE_BUF_VALUE          (65535lu)
#define Encoder_PWM_COMPARE_SWAP               (0lu)


/***************************************
*    Enumerated Types and Parameters
***************************************/

#define Encoder__LEFT 0
#define Encoder__RIGHT 1
#define Encoder__CENTER 2
#define Encoder__ASYMMETRIC 3

#define Encoder__X1 0
#define Encoder__X2 1
#define Encoder__X4 2

#define Encoder__PWM 4
#define Encoder__PWM_DT 5
#define Encoder__PWM_PR 6

#define Encoder__INVERSE 1
#define Encoder__DIRECT 0

#define Encoder__CAPTURE 2
#define Encoder__COMPARE 0

#define Encoder__TRIG_LEVEL 3
#define Encoder__TRIG_RISING 0
#define Encoder__TRIG_FALLING 1
#define Encoder__TRIG_BOTH 2

#define Encoder__INTR_MASK_TC 1
#define Encoder__INTR_MASK_CC_MATCH 2
#define Encoder__INTR_MASK_NONE 0
#define Encoder__INTR_MASK_TC_CC 3

#define Encoder__UNCONFIG 8
#define Encoder__TIMER 1
#define Encoder__QUAD 3
#define Encoder__PWM_SEL 7

#define Encoder__COUNT_UP 0
#define Encoder__COUNT_DOWN 1
#define Encoder__COUNT_UPDOWN0 2
#define Encoder__COUNT_UPDOWN1 3


/* Prescaler */
#define Encoder_PRESCALE_DIVBY1                ((uint32)(0u << Encoder_PRESCALER_SHIFT))
#define Encoder_PRESCALE_DIVBY2                ((uint32)(1u << Encoder_PRESCALER_SHIFT))
#define Encoder_PRESCALE_DIVBY4                ((uint32)(2u << Encoder_PRESCALER_SHIFT))
#define Encoder_PRESCALE_DIVBY8                ((uint32)(3u << Encoder_PRESCALER_SHIFT))
#define Encoder_PRESCALE_DIVBY16               ((uint32)(4u << Encoder_PRESCALER_SHIFT))
#define Encoder_PRESCALE_DIVBY32               ((uint32)(5u << Encoder_PRESCALER_SHIFT))
#define Encoder_PRESCALE_DIVBY64               ((uint32)(6u << Encoder_PRESCALER_SHIFT))
#define Encoder_PRESCALE_DIVBY128              ((uint32)(7u << Encoder_PRESCALER_SHIFT))

/* TCPWM set modes */
#define Encoder_MODE_TIMER_COMPARE             ((uint32)(Encoder__COMPARE         <<  \
                                                                  Encoder_MODE_SHIFT))
#define Encoder_MODE_TIMER_CAPTURE             ((uint32)(Encoder__CAPTURE         <<  \
                                                                  Encoder_MODE_SHIFT))
#define Encoder_MODE_QUAD                      ((uint32)(Encoder__QUAD            <<  \
                                                                  Encoder_MODE_SHIFT))
#define Encoder_MODE_PWM                       ((uint32)(Encoder__PWM             <<  \
                                                                  Encoder_MODE_SHIFT))
#define Encoder_MODE_PWM_DT                    ((uint32)(Encoder__PWM_DT          <<  \
                                                                  Encoder_MODE_SHIFT))
#define Encoder_MODE_PWM_PR                    ((uint32)(Encoder__PWM_PR          <<  \
                                                                  Encoder_MODE_SHIFT))

/* Quad Modes */
#define Encoder_MODE_X1                        ((uint32)(Encoder__X1              <<  \
                                                                  Encoder_QUAD_MODE_SHIFT))
#define Encoder_MODE_X2                        ((uint32)(Encoder__X2              <<  \
                                                                  Encoder_QUAD_MODE_SHIFT))
#define Encoder_MODE_X4                        ((uint32)(Encoder__X4              <<  \
                                                                  Encoder_QUAD_MODE_SHIFT))

/* Counter modes */
#define Encoder_COUNT_UP                       ((uint32)(Encoder__COUNT_UP        <<  \
                                                                  Encoder_UPDOWN_SHIFT))
#define Encoder_COUNT_DOWN                     ((uint32)(Encoder__COUNT_DOWN      <<  \
                                                                  Encoder_UPDOWN_SHIFT))
#define Encoder_COUNT_UPDOWN0                  ((uint32)(Encoder__COUNT_UPDOWN0   <<  \
                                                                  Encoder_UPDOWN_SHIFT))
#define Encoder_COUNT_UPDOWN1                  ((uint32)(Encoder__COUNT_UPDOWN1   <<  \
                                                                  Encoder_UPDOWN_SHIFT))

/* PWM output invert */
#define Encoder_INVERT_LINE                    ((uint32)(Encoder__INVERSE         <<  \
                                                                  Encoder_INV_OUT_SHIFT))
#define Encoder_INVERT_LINE_N                  ((uint32)(Encoder__INVERSE         <<  \
                                                                  Encoder_INV_COMPL_OUT_SHIFT))

/* Trigger modes */
#define Encoder_TRIG_RISING                    ((uint32)Encoder__TRIG_RISING)
#define Encoder_TRIG_FALLING                   ((uint32)Encoder__TRIG_FALLING)
#define Encoder_TRIG_BOTH                      ((uint32)Encoder__TRIG_BOTH)
#define Encoder_TRIG_LEVEL                     ((uint32)Encoder__TRIG_LEVEL)

/* Interrupt mask */
#define Encoder_INTR_MASK_TC                   ((uint32)Encoder__INTR_MASK_TC)
#define Encoder_INTR_MASK_CC_MATCH             ((uint32)Encoder__INTR_MASK_CC_MATCH)

/* PWM Output Controls */
#define Encoder_CC_MATCH_SET                   (0x00u)
#define Encoder_CC_MATCH_CLEAR                 (0x01u)
#define Encoder_CC_MATCH_INVERT                (0x02u)
#define Encoder_CC_MATCH_NO_CHANGE             (0x03u)
#define Encoder_OVERLOW_SET                    (0x00u)
#define Encoder_OVERLOW_CLEAR                  (0x04u)
#define Encoder_OVERLOW_INVERT                 (0x08u)
#define Encoder_OVERLOW_NO_CHANGE              (0x0Cu)
#define Encoder_UNDERFLOW_SET                  (0x00u)
#define Encoder_UNDERFLOW_CLEAR                (0x10u)
#define Encoder_UNDERFLOW_INVERT               (0x20u)
#define Encoder_UNDERFLOW_NO_CHANGE            (0x30u)

/* PWM Align */
#define Encoder_PWM_MODE_LEFT                  (Encoder_CC_MATCH_CLEAR        |   \
                                                         Encoder_OVERLOW_SET           |   \
                                                         Encoder_UNDERFLOW_NO_CHANGE)
#define Encoder_PWM_MODE_RIGHT                 (Encoder_CC_MATCH_SET          |   \
                                                         Encoder_OVERLOW_NO_CHANGE     |   \
                                                         Encoder_UNDERFLOW_CLEAR)
#define Encoder_PWM_MODE_ASYM                  (Encoder_CC_MATCH_INVERT       |   \
                                                         Encoder_OVERLOW_SET           |   \
                                                         Encoder_UNDERFLOW_CLEAR)

#if (Encoder_CY_TCPWM_V2)
    #if(Encoder_CY_TCPWM_4000)
        #define Encoder_PWM_MODE_CENTER                (Encoder_CC_MATCH_INVERT       |   \
                                                                 Encoder_OVERLOW_NO_CHANGE     |   \
                                                                 Encoder_UNDERFLOW_CLEAR)
    #else
        #define Encoder_PWM_MODE_CENTER                (Encoder_CC_MATCH_INVERT       |   \
                                                                 Encoder_OVERLOW_SET           |   \
                                                                 Encoder_UNDERFLOW_CLEAR)
    #endif /* (Encoder_CY_TCPWM_4000) */
#else
    #define Encoder_PWM_MODE_CENTER                (Encoder_CC_MATCH_INVERT       |   \
                                                             Encoder_OVERLOW_NO_CHANGE     |   \
                                                             Encoder_UNDERFLOW_CLEAR)
#endif /* (Encoder_CY_TCPWM_NEW) */

/* Command operations without condition */
#define Encoder_CMD_CAPTURE                    (0u)
#define Encoder_CMD_RELOAD                     (8u)
#define Encoder_CMD_STOP                       (16u)
#define Encoder_CMD_START                      (24u)

/* Status */
#define Encoder_STATUS_DOWN                    (1u)
#define Encoder_STATUS_RUNNING                 (2u)


/***************************************
*        Function Prototypes
****************************************/

void   Encoder_Init(void);
void   Encoder_Enable(void);
void   Encoder_Start(void);
void   Encoder_Stop(void);

void   Encoder_SetMode(uint32 mode);
void   Encoder_SetCounterMode(uint32 counterMode);
void   Encoder_SetPWMMode(uint32 modeMask);
void   Encoder_SetQDMode(uint32 qdMode);

void   Encoder_SetPrescaler(uint32 prescaler);
void   Encoder_TriggerCommand(uint32 mask, uint32 command);
void   Encoder_SetOneShot(uint32 oneShotEnable);
uint32 Encoder_ReadStatus(void);

void   Encoder_SetPWMSyncKill(uint32 syncKillEnable);
void   Encoder_SetPWMStopOnKill(uint32 stopOnKillEnable);
void   Encoder_SetPWMDeadTime(uint32 deadTime);
void   Encoder_SetPWMInvert(uint32 mask);

void   Encoder_SetInterruptMode(uint32 interruptMask);
uint32 Encoder_GetInterruptSourceMasked(void);
uint32 Encoder_GetInterruptSource(void);
void   Encoder_ClearInterrupt(uint32 interruptMask);
void   Encoder_SetInterrupt(uint32 interruptMask);

void   Encoder_WriteCounter(uint32 count);
uint32 Encoder_ReadCounter(void);

uint32 Encoder_ReadCapture(void);
uint32 Encoder_ReadCaptureBuf(void);

void   Encoder_WritePeriod(uint32 period);
uint32 Encoder_ReadPeriod(void);
void   Encoder_WritePeriodBuf(uint32 periodBuf);
uint32 Encoder_ReadPeriodBuf(void);

void   Encoder_WriteCompare(uint32 compare);
uint32 Encoder_ReadCompare(void);
void   Encoder_WriteCompareBuf(uint32 compareBuf);
uint32 Encoder_ReadCompareBuf(void);

void   Encoder_SetPeriodSwap(uint32 swapEnable);
void   Encoder_SetCompareSwap(uint32 swapEnable);

void   Encoder_SetCaptureMode(uint32 triggerMode);
void   Encoder_SetReloadMode(uint32 triggerMode);
void   Encoder_SetStartMode(uint32 triggerMode);
void   Encoder_SetStopMode(uint32 triggerMode);
void   Encoder_SetCountMode(uint32 triggerMode);

void   Encoder_SaveConfig(void);
void   Encoder_RestoreConfig(void);
void   Encoder_Sleep(void);
void   Encoder_Wakeup(void);


/***************************************
*             Registers
***************************************/

#define Encoder_BLOCK_CONTROL_REG              (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define Encoder_BLOCK_CONTROL_PTR              ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define Encoder_COMMAND_REG                    (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define Encoder_COMMAND_PTR                    ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define Encoder_INTRRUPT_CAUSE_REG             (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define Encoder_INTRRUPT_CAUSE_PTR             ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define Encoder_CONTROL_REG                    (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__CTRL )
#define Encoder_CONTROL_PTR                    ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__CTRL )
#define Encoder_STATUS_REG                     (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__STATUS )
#define Encoder_STATUS_PTR                     ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__STATUS )
#define Encoder_COUNTER_REG                    (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__COUNTER )
#define Encoder_COUNTER_PTR                    ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__COUNTER )
#define Encoder_COMP_CAP_REG                   (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__CC )
#define Encoder_COMP_CAP_PTR                   ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__CC )
#define Encoder_COMP_CAP_BUF_REG               (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__CC_BUFF )
#define Encoder_COMP_CAP_BUF_PTR               ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__CC_BUFF )
#define Encoder_PERIOD_REG                     (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__PERIOD )
#define Encoder_PERIOD_PTR                     ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__PERIOD )
#define Encoder_PERIOD_BUF_REG                 (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define Encoder_PERIOD_BUF_PTR                 ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define Encoder_TRIG_CONTROL0_REG              (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define Encoder_TRIG_CONTROL0_PTR              ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define Encoder_TRIG_CONTROL1_REG              (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define Encoder_TRIG_CONTROL1_PTR              ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define Encoder_TRIG_CONTROL2_REG              (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define Encoder_TRIG_CONTROL2_PTR              ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define Encoder_INTERRUPT_REQ_REG              (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__INTR )
#define Encoder_INTERRUPT_REQ_PTR              ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__INTR )
#define Encoder_INTERRUPT_SET_REG              (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__INTR_SET )
#define Encoder_INTERRUPT_SET_PTR              ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__INTR_SET )
#define Encoder_INTERRUPT_MASK_REG             (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__INTR_MASK )
#define Encoder_INTERRUPT_MASK_PTR             ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__INTR_MASK )
#define Encoder_INTERRUPT_MASKED_REG           (*(reg32 *) Encoder_cy_m0s8_tcpwm_1__INTR_MASKED )
#define Encoder_INTERRUPT_MASKED_PTR           ( (reg32 *) Encoder_cy_m0s8_tcpwm_1__INTR_MASKED )


/***************************************
*       Registers Constants
***************************************/

/* Mask */
#define Encoder_MASK                           ((uint32)Encoder_cy_m0s8_tcpwm_1__TCPWM_CTRL_MASK)

/* Shift constants for control register */
#define Encoder_RELOAD_CC_SHIFT                (0u)
#define Encoder_RELOAD_PERIOD_SHIFT            (1u)
#define Encoder_PWM_SYNC_KILL_SHIFT            (2u)
#define Encoder_PWM_STOP_KILL_SHIFT            (3u)
#define Encoder_PRESCALER_SHIFT                (8u)
#define Encoder_UPDOWN_SHIFT                   (16u)
#define Encoder_ONESHOT_SHIFT                  (18u)
#define Encoder_QUAD_MODE_SHIFT                (20u)
#define Encoder_INV_OUT_SHIFT                  (20u)
#define Encoder_INV_COMPL_OUT_SHIFT            (21u)
#define Encoder_MODE_SHIFT                     (24u)

/* Mask constants for control register */
#define Encoder_RELOAD_CC_MASK                 ((uint32)(Encoder_1BIT_MASK        <<  \
                                                                            Encoder_RELOAD_CC_SHIFT))
#define Encoder_RELOAD_PERIOD_MASK             ((uint32)(Encoder_1BIT_MASK        <<  \
                                                                            Encoder_RELOAD_PERIOD_SHIFT))
#define Encoder_PWM_SYNC_KILL_MASK             ((uint32)(Encoder_1BIT_MASK        <<  \
                                                                            Encoder_PWM_SYNC_KILL_SHIFT))
#define Encoder_PWM_STOP_KILL_MASK             ((uint32)(Encoder_1BIT_MASK        <<  \
                                                                            Encoder_PWM_STOP_KILL_SHIFT))
#define Encoder_PRESCALER_MASK                 ((uint32)(Encoder_8BIT_MASK        <<  \
                                                                            Encoder_PRESCALER_SHIFT))
#define Encoder_UPDOWN_MASK                    ((uint32)(Encoder_2BIT_MASK        <<  \
                                                                            Encoder_UPDOWN_SHIFT))
#define Encoder_ONESHOT_MASK                   ((uint32)(Encoder_1BIT_MASK        <<  \
                                                                            Encoder_ONESHOT_SHIFT))
#define Encoder_QUAD_MODE_MASK                 ((uint32)(Encoder_3BIT_MASK        <<  \
                                                                            Encoder_QUAD_MODE_SHIFT))
#define Encoder_INV_OUT_MASK                   ((uint32)(Encoder_2BIT_MASK        <<  \
                                                                            Encoder_INV_OUT_SHIFT))
#define Encoder_MODE_MASK                      ((uint32)(Encoder_3BIT_MASK        <<  \
                                                                            Encoder_MODE_SHIFT))

/* Shift constants for trigger control register 1 */
#define Encoder_CAPTURE_SHIFT                  (0u)
#define Encoder_COUNT_SHIFT                    (2u)
#define Encoder_RELOAD_SHIFT                   (4u)
#define Encoder_STOP_SHIFT                     (6u)
#define Encoder_START_SHIFT                    (8u)

/* Mask constants for trigger control register 1 */
#define Encoder_CAPTURE_MASK                   ((uint32)(Encoder_2BIT_MASK        <<  \
                                                                  Encoder_CAPTURE_SHIFT))
#define Encoder_COUNT_MASK                     ((uint32)(Encoder_2BIT_MASK        <<  \
                                                                  Encoder_COUNT_SHIFT))
#define Encoder_RELOAD_MASK                    ((uint32)(Encoder_2BIT_MASK        <<  \
                                                                  Encoder_RELOAD_SHIFT))
#define Encoder_STOP_MASK                      ((uint32)(Encoder_2BIT_MASK        <<  \
                                                                  Encoder_STOP_SHIFT))
#define Encoder_START_MASK                     ((uint32)(Encoder_2BIT_MASK        <<  \
                                                                  Encoder_START_SHIFT))

/* MASK */
#define Encoder_1BIT_MASK                      ((uint32)0x01u)
#define Encoder_2BIT_MASK                      ((uint32)0x03u)
#define Encoder_3BIT_MASK                      ((uint32)0x07u)
#define Encoder_6BIT_MASK                      ((uint32)0x3Fu)
#define Encoder_8BIT_MASK                      ((uint32)0xFFu)
#define Encoder_16BIT_MASK                     ((uint32)0xFFFFu)

/* Shift constant for status register */
#define Encoder_RUNNING_STATUS_SHIFT           (30u)


/***************************************
*    Initial Constants
***************************************/

#define Encoder_CTRL_QUAD_BASE_CONFIG                                                          \
        (((uint32)(Encoder_QUAD_ENCODING_MODES     << Encoder_QUAD_MODE_SHIFT))       |\
         ((uint32)(Encoder_CONFIG                  << Encoder_MODE_SHIFT)))

#define Encoder_CTRL_PWM_BASE_CONFIG                                                           \
        (((uint32)(Encoder_PWM_STOP_EVENT          << Encoder_PWM_STOP_KILL_SHIFT))   |\
         ((uint32)(Encoder_PWM_OUT_INVERT          << Encoder_INV_OUT_SHIFT))         |\
         ((uint32)(Encoder_PWM_OUT_N_INVERT        << Encoder_INV_COMPL_OUT_SHIFT))   |\
         ((uint32)(Encoder_PWM_MODE                << Encoder_MODE_SHIFT)))

#define Encoder_CTRL_PWM_RUN_MODE                                                              \
            ((uint32)(Encoder_PWM_RUN_MODE         << Encoder_ONESHOT_SHIFT))
            
#define Encoder_CTRL_PWM_ALIGN                                                                 \
            ((uint32)(Encoder_PWM_ALIGN            << Encoder_UPDOWN_SHIFT))

#define Encoder_CTRL_PWM_KILL_EVENT                                                            \
             ((uint32)(Encoder_PWM_KILL_EVENT      << Encoder_PWM_SYNC_KILL_SHIFT))

#define Encoder_CTRL_PWM_DEAD_TIME_CYCLE                                                       \
            ((uint32)(Encoder_PWM_DEAD_TIME_CYCLE  << Encoder_PRESCALER_SHIFT))

#define Encoder_CTRL_PWM_PRESCALER                                                             \
            ((uint32)(Encoder_PWM_PRESCALER        << Encoder_PRESCALER_SHIFT))

#define Encoder_CTRL_TIMER_BASE_CONFIG                                                         \
        (((uint32)(Encoder_TC_PRESCALER            << Encoder_PRESCALER_SHIFT))       |\
         ((uint32)(Encoder_TC_COUNTER_MODE         << Encoder_UPDOWN_SHIFT))          |\
         ((uint32)(Encoder_TC_RUN_MODE             << Encoder_ONESHOT_SHIFT))         |\
         ((uint32)(Encoder_TC_COMP_CAP_MODE        << Encoder_MODE_SHIFT)))
        
#define Encoder_QUAD_SIGNALS_MODES                                                             \
        (((uint32)(Encoder_QUAD_PHIA_SIGNAL_MODE   << Encoder_COUNT_SHIFT))           |\
         ((uint32)(Encoder_QUAD_INDEX_SIGNAL_MODE  << Encoder_RELOAD_SHIFT))          |\
         ((uint32)(Encoder_QUAD_STOP_SIGNAL_MODE   << Encoder_STOP_SHIFT))            |\
         ((uint32)(Encoder_QUAD_PHIB_SIGNAL_MODE   << Encoder_START_SHIFT)))

#define Encoder_PWM_SIGNALS_MODES                                                              \
        (((uint32)(Encoder_PWM_SWITCH_SIGNAL_MODE  << Encoder_CAPTURE_SHIFT))         |\
         ((uint32)(Encoder_PWM_COUNT_SIGNAL_MODE   << Encoder_COUNT_SHIFT))           |\
         ((uint32)(Encoder_PWM_RELOAD_SIGNAL_MODE  << Encoder_RELOAD_SHIFT))          |\
         ((uint32)(Encoder_PWM_STOP_SIGNAL_MODE    << Encoder_STOP_SHIFT))            |\
         ((uint32)(Encoder_PWM_START_SIGNAL_MODE   << Encoder_START_SHIFT)))

#define Encoder_TIMER_SIGNALS_MODES                                                            \
        (((uint32)(Encoder_TC_CAPTURE_SIGNAL_MODE  << Encoder_CAPTURE_SHIFT))         |\
         ((uint32)(Encoder_TC_COUNT_SIGNAL_MODE    << Encoder_COUNT_SHIFT))           |\
         ((uint32)(Encoder_TC_RELOAD_SIGNAL_MODE   << Encoder_RELOAD_SHIFT))          |\
         ((uint32)(Encoder_TC_STOP_SIGNAL_MODE     << Encoder_STOP_SHIFT))            |\
         ((uint32)(Encoder_TC_START_SIGNAL_MODE    << Encoder_START_SHIFT)))
        
#define Encoder_TIMER_UPDOWN_CNT_USED                                                          \
                ((Encoder__COUNT_UPDOWN0 == Encoder_TC_COUNTER_MODE)                  ||\
                 (Encoder__COUNT_UPDOWN1 == Encoder_TC_COUNTER_MODE))

#define Encoder_PWM_UPDOWN_CNT_USED                                                            \
                ((Encoder__CENTER == Encoder_PWM_ALIGN)                               ||\
                 (Encoder__ASYMMETRIC == Encoder_PWM_ALIGN))               
        
#define Encoder_PWM_PR_INIT_VALUE              (1u)
#define Encoder_QUAD_PERIOD_INIT_VALUE         (0x8000u)



#endif /* End CY_TCPWM_Encoder_H */

/* [] END OF FILE */
