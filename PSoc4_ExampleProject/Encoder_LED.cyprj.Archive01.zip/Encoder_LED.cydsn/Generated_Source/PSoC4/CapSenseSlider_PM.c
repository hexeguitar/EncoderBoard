/*******************************************************************************
* File Name: CapSenseSlider_PM.c
* Version 2.40
*
* Description:
*  This file provides Sleep APIs for CapSense CSD Component.
*
* Note:
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CapSenseSlider.h"

static CapSenseSlider_BACKUP_STRUCT CapSenseSlider_backup =
{
    0x00u, /* enableState; */
};


/*******************************************************************************
* Function Name: CapSenseSlider_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the customer configuration of CapSense.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_backup - used to save the component state before entering the  sleep
*  mode and none-retention registers.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_SaveConfig(void)
{
    if ((CapSenseSlider_CSD_CFG_REG & CapSenseSlider_CSD_CFG_ENABLE) != 0u)
    {
        CapSenseSlider_backup.enableState = 1u;
    }
}


/*******************************************************************************
* Function Name: CapSenseSlider_Sleep
********************************************************************************
*
* Summary:
*  Disables the Active mode power.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_backup - used to save the component state before entering the sleep
*  mode.
*
*******************************************************************************/
void CapSenseSlider_Sleep(void)
{
    CapSenseSlider_SaveConfig();

    /* Disable interrupt */
    CyIntDisable(CapSenseSlider_ISR_NUMBER);

    CapSenseSlider_CSD_CFG_REG &= ~(CapSenseSlider_CSD_CFG_SENSE_COMP_EN | CapSenseSlider_CSD_CFG_SENSE_EN);

    #if(CapSenseSlider_IDAC_CNT == 2u)
        CapSenseSlider_CSD_CFG_REG &= ~(CapSenseSlider_CSD_CFG_ENABLE);
    #endif /* (CapSenseSlider_IDAC_CNT == 2u) */

    /* Disable Clocks */
    CapSenseSlider_SenseClk_Stop();
    CapSenseSlider_SampleClk_Stop();
}


/*******************************************************************************
* Function Name: CapSenseSlider_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the CapSense configuration.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  Must be called only after CapSenseSlider_SaveConfig() routine. Otherwise
*  the component configuration will be overwritten with its initial setting.
*
* Global Variables:
*  CapSenseSlider_backup - used to save the component state before entering the sleep
*  mode and none-retention registers.
*
*******************************************************************************/
void CapSenseSlider_RestoreConfig(void)
{

}


/*******************************************************************************
* Function Name: CapSenseSlider_Wakeup
********************************************************************************
*
* Summary:
*  Restores the CapSense configuration and non-retention register values.
*  Restores the enabled state of the component by setting the Active mode power template
*  bits for a number of components used within CapSense.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_backup - used to save the component state before entering the sleep
*  mode and none-retention registers.
*
*******************************************************************************/
void CapSenseSlider_Wakeup(void)
{
    /* Enable the Clocks */
    CapSenseSlider_SenseClk_Start();
    CapSenseSlider_SampleClk_Start();

    /* Restore CapSense Enable state */
    if (CapSenseSlider_backup.enableState != 0u)
    {
        CapSenseSlider_Enable();
    }
}


/* [] END OF FILE */
