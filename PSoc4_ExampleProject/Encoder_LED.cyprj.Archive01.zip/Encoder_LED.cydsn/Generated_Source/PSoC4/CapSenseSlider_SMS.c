/*******************************************************************************
* File Name: CapSenseSlider_SMS.c
* Version 2.40
*
* Description:
*  This file provides the source code of wrapper between CapSense CSD component
*  and Auto Tuning library.
*
* Note:
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CapSenseSlider_SMS.h"
#include "CapSenseSlider_PVT.h"

#include "cytypes.h"

#if (CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO)


/*  Real Charge Divider values */
#if ((0u != CapSenseSlider_IS_M0S8PERI_BLOCK) && (0u == CY_PSOC4_4000))
    /*  Dividers are not chained */
    #if (CYDEV_BCLK__HFCLK__MHZ > 24u)
        const uint8 CapSenseSlider_prescalerTable[CapSenseSlider_PRESCALERS_TBL_SIZE] = {
            4u,     4u,     4u,    8u,    8u,    8u,    8u,    16u,    16u,    16u,    16u,    16u,    16u,    16u,    16u,    16u
        };
    #elif (CYDEV_BCLK__HFCLK__MHZ >12u)
        const uint8 CapSenseSlider_prescalerTable[CapSenseSlider_PRESCALERS_TBL_SIZE] = {
            2u,     2u,     2u,    4u,    4u,    4u,    4u,    8u,    8u,    8u,    8u,    8u,    8u,    8u,    8u,    8u
        };
    #else   /* (CYDEV_BCLK__HFCLK__MHZ > 12u) */
        const uint8 CapSenseSlider_prescalerTable[CapSenseSlider_PRESCALERS_TBL_SIZE] = {
            1u,     1u,     1u,    2u,    2u,    2u,    2u,    4u,    4u,    4u,    4u,    4u,    4u,    4u,    4u,    4u
        };
    #endif /* (CYDEV_BCLK__HFCLK__MHZ > 24u) */

#elif (0u != CapSenseSlider_IS_M0S8PERI_BLOCK)
    /*  Dividers are not chained (PSoC 4000) */
    #if (CYDEV_BCLK__HFCLK__MHZ >= 12u)
        const uint8 CapSenseSlider_prescalerTable[CapSenseSlider_PRESCALERS_TBL_SIZE] = {
            1u,     1u,     1u,    2u,    2u,    2u,    2u,    4u,    4u,    4u,    4u,    4u,    4u,    4u,    4u,    4u
        };

    #elif (CYDEV_BCLK__HFCLK__MHZ >= 6u)
        const uint8 CapSenseSlider_prescalerTable[CapSenseSlider_PRESCALERS_TBL_SIZE] = {
            1u,     1u,     1u,    1u,    1u,    1u,    1u,    2u,    2u,    2u,    2u,    2u,    2u,    2u,    2u,    2u
        };
    #else
        const uint8 CapSenseSlider_prescalerTable[CapSenseSlider_PRESCALERS_TBL_SIZE] = {
            1u,     1u,     1u,    1u,    1u,    1u,    1u,    1u,    1u,    1u,    1u,    1u,    1u,    1u,    1u,    1u
        };
    #endif /* (CYDEV_BCLK__HFCLK__MHZ > 12u) */

#else
    /*  Dividers are chained (PSoC 4100, PSoC 4200) */
    #if (CYDEV_BCLK__HFCLK__MHZ > 24u)
        const uint8 CapSenseSlider_prescalerTable[CapSenseSlider_PRESCALERS_TBL_SIZE] = {
            2u,     2u,     2u,    4u,    4u,    4u,    4u,    8u,    8u,    8u,    8u,    8u,    8u,    8u,    8u,    8u
        };

    #elif (CYDEV_BCLK__HFCLK__MHZ >12u)
        const uint8 CapSenseSlider_prescalerTable[CapSenseSlider_PRESCALERS_TBL_SIZE] = {
            1u,     1u,     1u,    2u,    2u,    2u,    2u,    4u,    4u,    4u,    4u,    4u,    4u,    4u,    4u,    4u
        };
    #else   /* (CYDEV_BCLK__HFCLK__MHZ > 12u) */
        const uint8 CapSenseSlider_prescalerTable[CapSenseSlider_PRESCALERS_TBL_SIZE] = {
            1u,     1u,     1u,    1u,    1u,    1u,    1u,    2u,    2u,    2u,    2u,    2u,    2u,    2u,    2u,    2u
        };
    #endif /* (CYDEV_BCLK__HFCLK__MHZ > 24u) */
#endif /* ((0u != CapSenseSlider_IS_M0S8PERI_BLOCK) && (0u == CY_PSOC4_4000)) */


uint8 CapSenseSlider_noiseEnvelopeTbl[CapSenseSlider_TOTAL_SENSOR_COUNT];
uint8 CapSenseSlider_runningDifferenceTbl[CapSenseSlider_TOTAL_SENSOR_COUNT];
uint8 CapSenseSlider_signRegisterTbl[CapSenseSlider_TOTAL_SENSOR_COUNT];
uint16 CapSenseSlider_sampleMinTbl[CapSenseSlider_TOTAL_SENSOR_COUNT];
uint16 CapSenseSlider_sampleMaxTbl[CapSenseSlider_TOTAL_SENSOR_COUNT];
uint16 CapSenseSlider_previousSampleTbl[CapSenseSlider_TOTAL_SENSOR_COUNT];
uint8 CapSenseSlider_kValueTbl[CapSenseSlider_TOTAL_SENSOR_COUNT];

uint8 CapSenseSlider_sensorSensitivity[] = {
    2u, 2u, 2u, 2u, 2u, 
};

CapSenseSlider_CONFIG_TYPE_P4_v2_40 CapSenseSlider_config;
CapSenseSlider_CONFIG_TYPE_POINTERS_P4_v2_40 const CapSenseSlider_configPointers = {
    CapSenseSlider_modulationIDAC,
    CapSenseSlider_compensationIDAC,
    CapSenseSlider_sensorSensitivity,
    CapSenseSlider_senseClkDividerVal,
    CapSenseSlider_sampleClkDividerVal,
    CapSenseSlider_widgetNumber,
    CapSenseSlider_widgetResolution,
    CapSenseSlider_noiseEnvelopeTbl,
    CapSenseSlider_runningDifferenceTbl,
    CapSenseSlider_signRegisterTbl,
    CapSenseSlider_sampleMinTbl,
    CapSenseSlider_sampleMaxTbl,
    CapSenseSlider_previousSampleTbl,
    CapSenseSlider_kValueTbl,
    CapSenseSlider_scanSpeedTbl,
    CapSenseSlider_prescalerTable,
    (const uint8  *)CapSenseSlider_rawDataIndex,
    (const uint8  *)CapSenseSlider_numberOfSensors,
    &CapSenseSlider_GetSensorRaw,
    &CapSenseSlider_PreScan,
    &CapSenseSlider_ReadSensorRaw,
    &CapSenseSlider_GetBitValue,
    &CapSenseSlider_SetBitValue
};


/*******************************************************************************
* Function Name: CapSenseSlider_AutoTune
********************************************************************************
*
* Summary:
*  Provides the tuning procedure for all sensors.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*   CapSenseSlider_config: the structure which contains configuration parameters
*   CapSenseSlider_senseClkDividerVal[]: used to store the Analog Switch
*   dividers for each sensor.
*   CapSenseSlider_senseClkDividerVal[]: used to store the
*    Analog Switch divider for all sensors.
*   CapSenseSlider_prescalersTuningDone - used to notify the Tuner GUI that
*   the pre-scalers tuning  is done.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_AutoTune(void)
{
    uint32 curSensor;
    uint32 widget;

    CapSenseSlider_config.totalScanslotsNum = CapSenseSlider_TOTAL_SCANSLOT_COUNT;
    CapSenseSlider_config.totalWidgetsNum = CapSenseSlider_END_OF_WIDGETS_INDEX;
    CapSenseSlider_config.totalSensorsNum = CapSenseSlider_TOTAL_SENSOR_COUNT;

    CapSenseSlider_config.hfclkFreq_MHz = CYDEV_BCLK__HFCLK__MHZ;
    CapSenseSlider_config.sensetivitySeed = CapSenseSlider_SENSETIVITY_FACTOR;

    CapSenseSlider_config.pointers = &CapSenseSlider_configPointers;

    CapSenseSlider_SetAnalogSwitchesSrcDirect();

    for(widget = 0u; widget < CapSenseSlider_config.totalWidgetsNum; widget++)
    {
        CapSenseSlider_widgetResolution[widget] = CapSenseSlider_CALIBRATION_RESOLUTION;
    }


    for(curSensor = 0u; curSensor < CapSenseSlider_TOTAL_SCANSLOT_COUNT; curSensor++)
    {
        CapSenseSlider_senseClkDividerVal[curSensor] = CapSenseSlider_CALIBRATION_ASD;
        CapSenseSlider_sampleClkDividerVal[curSensor] = CapSenseSlider_CALIBRATION_MD;
    }

    CapSenseSlider_DisableBaselineIDAC();

    CalibrateSensors_P4_v2_40(&CapSenseSlider_config, CapSenseSlider_CAL_RAW_COUNT);

    #if(0u != CapSenseSlider_TOTAL_CENTROIDS_COUNT)
        CapSenseSlider_NormalizeWidgets(CapSenseSlider_END_OF_WIDGETS_INDEX, CapSenseSlider_modulationIDAC);
    #endif /* (0u != CapSenseSlider_TOTAL_CENTROIDS_COUNT)  */

    TunePrescalers_P4_v2_40(&CapSenseSlider_config);

    #if(CapSenseSlider_PRS_OPTIONS != CapSenseSlider__PRS_NONE)
        CapSenseSlider_prescalersTuningDone = 1u;
    #endif /* (CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_NONE) */

    CalibrateSensors_P4_v2_40(&CapSenseSlider_config, CapSenseSlider_CAL_RAW_COUNT);
    #if(0u != CapSenseSlider_TOTAL_CENTROIDS_COUNT)
        CapSenseSlider_NormalizeWidgets(CapSenseSlider_END_OF_WIDGETS_INDEX, CapSenseSlider_modulationIDAC);
    #endif /* (0u != CapSenseSlider_TOTAL_CENTROIDS_COUNT)  */
    TuneSensitivity_P4_v2_40(&CapSenseSlider_config);

    CapSenseSlider_EnableBaselineIDAC(&CapSenseSlider_config);

    for(curSensor = 0u; curSensor < CapSenseSlider_TOTAL_SCANSLOT_COUNT; curSensor++)
    {
        CapSenseSlider_UpdateThresholds(curSensor);
    }
}


/*******************************************************************************
* Function Name: CapSenseSlider_UpdateThresholds
********************************************************************************
*
* Summary:
*  The API updates the Finger Threshold, Hysteresis, Noise Threshold, and
*  Negative Noise Threshold in the AutoTuning (Smartsense) Mode.
*
* Parameters:
*  sensor: sensor number.
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_widgetNumber[] - contains widget Number for given sensor.
*  0 through 7 (sensor 0 is bit 0, sensor 1 is bit 1).
*  For other sensors the array element equals to 255.
*  CapSenseSlider_numberOfSensors[widget] - Number of sensors in the widget.
*   CapSenseSlider_fingerThreshold[] - contains the level of signal for each sensor
*   that determines if a finger present on the sensor.
*   CapSenseSlider_negativeNoiseThreshold[] - negative Noise Threshold
*   CapSenseSlider_hysteresis[] - the array with hysteresis values.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_UpdateThresholds(uint32 sensor)
{
    uint8 fingerThreshold;
    uint32 widget;

    widget = CapSenseSlider_widgetNumber[sensor];

    #if(0u != CapSenseSlider_FLEXIBLE_THRESHOLDS_EN)
        fingerThreshold = CapSenseSlider_fingerThreshold[widget];
        /* Update Threshold manually (flexible) */
        CapSenseSlider_noiseThreshold[widget] = (uint8)(fingerThreshold >> 1u);
        CapSenseSlider_negativeNoiseThreshold[widget] = (uint8)(fingerThreshold >> 1u);
        CapSenseSlider_hysteresis[widget] = (uint8)(fingerThreshold >> 3u);
    #else
        /* Calculate Finger Threshold and Noise Threshold with Smartsense (automatic) */
        CalculateThresholds_P4_v2_40(&CapSenseSlider_config, (uint8)sensor, (uint8)widget, CapSenseSlider_fingerThreshold, CapSenseSlider_noiseThreshold);

        fingerThreshold = CapSenseSlider_fingerThreshold[widget];

        /* Update Threshold based on calculated with Smartsense (automatic) */
        CapSenseSlider_negativeNoiseThreshold[widget] = CapSenseSlider_noiseThreshold[widget];

        if(fingerThreshold < CapSenseSlider_THRESHOLD_1)
        {
            CapSenseSlider_hysteresis[widget] = (uint8)(fingerThreshold >> 3u);
        }
        else if(fingerThreshold <  CapSenseSlider_THRESHOLD_2)
        {
            CapSenseSlider_hysteresis[widget] = (uint8)(fingerThreshold >> 4u);
        }
        else if(fingerThreshold <  CapSenseSlider_THRESHOLD_3)
        {
            CapSenseSlider_hysteresis[widget] = (uint8)(fingerThreshold >> 5u);
        }
        else if(fingerThreshold <  CapSenseSlider_THRESHOLD_4)
        {
            CapSenseSlider_hysteresis[widget] = (uint8)(fingerThreshold >> 6u);
        }
        else
        {
            CapSenseSlider_hysteresis[widget] = 0u;
        }
    #endif /* (0u != CapSenseSlider_FLEXIBLE_THRESHOLDS_EN)  */
}

/*******************************************************************************
* Function Name: CapSenseSlider_SetAnalogSwitchesSrcDirect
********************************************************************************
*
* Summary:
*  This API switches the charge clock source to prescaler.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  None
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_SetAnalogSwitchesSrcDirect(void)
{
    CapSenseSlider_CSD_CFG_REG &= ~(CapSenseSlider_CSD_CFG_PRS_SELECT);
}


/*******************************************************************************
* Function Name: CapSenseSlider_DisableBaselineIDAC
********************************************************************************
*
* Summary:
*  The API disables the Compensation IDAC.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  None
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_DisableBaselineIDAC(void)
{
    uint32 newRegValue;

    newRegValue = CapSenseSlider_CSD_IDAC_REG;

    newRegValue &= ~(CapSenseSlider_CSD_IDAC1_MODE_MASK | CapSenseSlider_CSD_IDAC2_MODE_MASK);
    newRegValue |= CapSenseSlider_CSD_IDAC1_MODE_VARIABLE;

    CapSenseSlider_CSD_IDAC_REG = newRegValue;
}


/*******************************************************************************
* Function Name: CapSenseSlider_EnableBaselineIDAC
********************************************************************************
*
* Summary:
*  The API enables the Compensation IDAC.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_compensationIDAC[] - used to store a 7-bit idac value for all the sensors.
*
* Side Effects:
*  None
*
*******************************************************************************/
void  CapSenseSlider_EnableBaselineIDAC(const CapSenseSlider_CONFIG_TYPE_P4_v2_40 *config)
{
    uint32 curSensor;
    uint32 newRegValue;

    for(curSensor = 0u; curSensor < config->totalScanslotsNum; curSensor++)
    {
        CapSenseSlider_compensationIDAC[curSensor] = CapSenseSlider_modulationIDAC[curSensor] / 2u;
        CapSenseSlider_modulationIDAC[curSensor] = (CapSenseSlider_modulationIDAC[curSensor] + 1u) / 2u;
    }

    CyIntDisable(CapSenseSlider_ISR_NUMBER);

    newRegValue = CapSenseSlider_CSD_IDAC_REG;
    newRegValue &= ~(CapSenseSlider_CSD_IDAC1_MODE_MASK | CapSenseSlider_CSD_IDAC2_MODE_MASK);
    newRegValue |= (CapSenseSlider_CSD_IDAC1_MODE_VARIABLE | CapSenseSlider_CSD_IDAC2_MODE_FIXED);
    CapSenseSlider_CSD_IDAC_REG = newRegValue;

    CyIntEnable(CapSenseSlider_ISR_NUMBER);
}


/*******************************************************************************
* Function Name: CapSenseSlider_SetSensitivity
********************************************************************************
*
* Summary:
*  This API sets the sensitivity value for the sensor. The sensitivity
*  value is used during the auto-tuning algorithm executed as part of the CapSense_Start API.
*  This API is called by the application layer prior to calling the CapSense_Start API.
*  Calling this API after execution of CapSense_Start API has no effect.
*
* Parameters:
*  sensor  Sensor index
*  data    Sensitivity of the sensor. Possible values are below
*  1 - 0.1pf sensitivity
*  2 - 0.2pf sensitivity
*  3 - 0.3pf sensitivity
*  4 - 0.4pf sensitivity
*  5 - 0.5pf sensitivity
*  6 - 0.6pf sensitivity
*  7 - 0.7pf sensitivity
*  8 - 0.8pf sensitivity
*  9 - 0.9pf sensitivity
*  10 - 1.0pf sensitivity
*  All other values, set sensitivity to 1.0pf
*
*  Return Value:
*   None
*
* Global Variables:
* CapSenseSlider_sensorSensitivity[] - This 8-bits array contains Sensitivity in the LSB nibble
*                                and Noise Reset Counter value in the MSB nibble.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_SetSensitivity(uint32 sensor, uint32 value)
{
    if(value > 10u)
    {
        value = 10u;
    }

    /* Clear SensorSensitivity value in LSB nibble */
    CapSenseSlider_sensorSensitivity[sensor] &= (uint8)~CapSenseSlider_SENSITIVITY_MASK;
    /* Set SensorSensitivity value in LSB nibble */
    CapSenseSlider_sensorSensitivity[sensor] |= (uint8)value;
}


/*******************************************************************************
* Function Name: CapSenseSlider_GetSensitivityCoefficient
********************************************************************************
*
* Summary:
*  This API returns the K coefficient for the appropriate sensor.
*
* Parameters:
*  sensor:  Sensor index
*
*  Return Value:
*   K - value for the appropriate sensor.
*
* Global Variables:
*  CapSenseSlider_kValueTbl[] - This 8-bits array contains the K value for each sensor.
*
* Side Effects:
*  None
*
*******************************************************************************/
uint8 CapSenseSlider_GetSensitivityCoefficient(uint32 sensor)
{
    return (CapSenseSlider_kValueTbl[sensor]);
}


/*******************************************************************************
* Function Name: CapSenseSlider_GetNoiseEnvelope
********************************************************************************
*
* Summary:
*  This function returns the noise value of a
*  component.
*
* Parameters:
*  sensor - Sensor number.
*
* Return:
*  The noise envelope value of the sensor
*  indicated by argument.
*
* Global Variables:
*  CapSenseSlider_noiseEnvelopeTbl[] - array with Noise Envelope.
*
* Side Effects:
*  None
*
*******************************************************************************/
uint16 CapSenseSlider_GetNoiseEnvelope(uint32 sensor)
{
    return((uint16)((uint16)CapSenseSlider_noiseEnvelopeTbl[sensor] << 1u) + 1u);
}


/*******************************************************************************
* Function Name: CapSenseSlider_GetNormalizedDiffCountData
********************************************************************************
*
* Summary:
*  This API returns normalized difference count data.
*
* Parameters:
*  sensor:  Sensor number.
*
* Return:
*  This API returns a normalized count value of the sensor indicated by the
*  argument.
*
* Global Variables:
*  CapSenseSlider_sensorSignal[] - array with difference counts for sensors
*
* Side Effects:
*  None
*
*******************************************************************************/
uint16 CapSenseSlider_GetNormalizedDiffCountData(uint32 sensor)
{
    return (uint16)(((uint32)CapSenseSlider_sensorSignal[sensor] << 7u) / CapSenseSlider_kValueTbl[sensor]);
}

#endif /* (CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) */

/* [] END OF FILE */
