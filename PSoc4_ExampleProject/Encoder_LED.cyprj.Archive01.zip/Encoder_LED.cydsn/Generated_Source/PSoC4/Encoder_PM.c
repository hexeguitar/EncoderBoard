/*******************************************************************************
* File Name: Encoder_PM.c
* Version 2.10
*
* Description:
*  This file contains the setup, control, and status commands to support
*  the component operations in the low power mode.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Encoder.h"

static Encoder_BACKUP_STRUCT Encoder_backup;


/*******************************************************************************
* Function Name: Encoder_SaveConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to save here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Encoder_SaveConfig(void)
{

}


/*******************************************************************************
* Function Name: Encoder_Sleep
********************************************************************************
*
* Summary:
*  Stops the component operation and saves the user configuration.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Encoder_Sleep(void)
{
    if(0u != (Encoder_BLOCK_CONTROL_REG & Encoder_MASK))
    {
        Encoder_backup.enableState = 1u;
    }
    else
    {
        Encoder_backup.enableState = 0u;
    }

    Encoder_Stop();
    Encoder_SaveConfig();
}


/*******************************************************************************
* Function Name: Encoder_RestoreConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to restore here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Encoder_RestoreConfig(void)
{

}


/*******************************************************************************
* Function Name: Encoder_Wakeup
********************************************************************************
*
* Summary:
*  Restores the user configuration and restores the enable state.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Encoder_Wakeup(void)
{
    Encoder_RestoreConfig();

    if(0u != Encoder_backup.enableState)
    {
        Encoder_Enable();
    }
}


/* [] END OF FILE */
