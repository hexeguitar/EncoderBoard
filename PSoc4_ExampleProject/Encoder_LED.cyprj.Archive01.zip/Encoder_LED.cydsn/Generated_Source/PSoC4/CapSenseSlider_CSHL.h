/*******************************************************************************
* File Name: CapSenseSlider_CSHL.h
* Version 2.40
*
* Description:
*  This file provides constants and parameter values for the High Level APIs
*  for CapSense CSD component.
*
* Note:
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CSD_CSHL_CapSenseSlider_H)
#define CY_CAPSENSE_CSD_CSHL_CapSenseSlider_H

#include "CapSenseSlider.h"


/***************************************
*   Condition compilation parameters
***************************************/

#define CapSenseSlider_SIGNAL_SIZE                    (8u)
#define CapSenseSlider_AUTO_RESET                     (0u)
#define CapSenseSlider_RAW_FILTER_MASK                (8u)

/* Signal size definition */
#define CapSenseSlider_SIGNAL_SIZE_UINT8              (8u)
#define CapSenseSlider_SIGNAL_SIZE_UINT16             (16u)

/* Auto reset definition */
#define CapSenseSlider_AUTO_RESET_DISABLE             (0u)
#define CapSenseSlider_AUTO_RESET_ENABLE              (1u)

/* Mask for RAW and POS filters */
#define CapSenseSlider_MEDIAN_FILTER                  (0x01u)
#define CapSenseSlider_AVERAGING_FILTER               (0x02u)
#define CapSenseSlider_IIR2_FILTER                    (0x04u)
#define CapSenseSlider_IIR4_FILTER                    (0x08u)
#define CapSenseSlider_JITTER_FILTER                  (0x10u)
#define CapSenseSlider_IIR8_FILTER                    (0x20u)
#define CapSenseSlider_IIR16_FILTER                   (0x40u)
#define CapSenseSlider_RAW_FILTERS_ENABLED            (0x01u)
#define CapSenseSlider_RAW_FILTERS_DISABLED           (0x00u)

/***************************************
*           API Constants
***************************************/

/* Widgets constants definition */
#define CapSenseSlider_LINEARSLIDER__LS        (0u)

#define CapSenseSlider_TOTAL_DIPLEXED_SLIDERS_COUNT        (0u)
#define CapSenseSlider_TOTAL_LINEAR_SLIDERS_COUNT          (1u)
#define CapSenseSlider_TOTAL_RADIAL_SLIDERS_COUNT          (0u)
#define CapSenseSlider_TOTAL_TOUCH_PADS_COUNT              (0u)
#define CapSenseSlider_TOTAL_TOUCH_PADS_BASIC_COUNT        (0u)
#define CapSenseSlider_TOTAL_TRACKPAD_GESTURES_COUNT       (0u)
#define CapSenseSlider_TOTAL_BUTTONS_COUNT                 (0u)
#define CapSenseSlider_TOTAL_MATRIX_BUTTONS_COUNT          (0u)
#define CapSenseSlider_TOTAL_GENERICS_COUNT                (0u)

#define CapSenseSlider_POS_FILTERS_MASK                    (0x8u)
#define CapSenseSlider_LINEAR_SLIDERS_POS_FILTERS_MASK     (0x8u)
#define CapSenseSlider_RADIAL_SLIDERS_POS_FILTERS_MASK     (0x0u)
#define CapSenseSlider_TOUCH_PADS_POS_FILTERS_MASK         (0x0u)
#define CapSenseSlider_TRACKPAD_GEST_POS_FILTERS_MASK      (0x0u)

#define CapSenseSlider_UNUSED_DEBOUNCE_COUNTER_INDEX       (0u)

#define CapSenseSlider_TOTAL_PROX_SENSORS_COUNT            (0u)

#define CapSenseSlider_END_OF_SLIDERS_INDEX                (0u)
#define CapSenseSlider_END_OF_TOUCH_PAD_INDEX              (0u)
#define CapSenseSlider_END_OF_BUTTONS_INDEX                (0u)
#define CapSenseSlider_END_OF_MATRIX_BUTTONS_INDEX         (0u)
#define CapSenseSlider_END_OF_WIDGETS_INDEX                (1u)



#define CapSenseSlider_TOTAL_SLIDERS_COUNT            ( CapSenseSlider_TOTAL_LINEAR_SLIDERS_COUNT + \
                                                          CapSenseSlider_TOTAL_RADIAL_SLIDERS_COUNT )

#define CapSenseSlider_TOTAL_CENTROIDS_COUNT          ( CapSenseSlider_TOTAL_SLIDERS_COUNT + \
                                                         (CapSenseSlider_TOTAL_TOUCH_PADS_BASIC_COUNT * 2u) +\
                                                         (CapSenseSlider_TOTAL_TRACKPAD_GESTURES_COUNT * 4u))

#define CapSenseSlider_TOTAL_CENTROIDS_BASIC_COUNT    ( CapSenseSlider_TOTAL_SLIDERS_COUNT + \
                                                         (CapSenseSlider_TOTAL_TOUCH_PADS_BASIC_COUNT * 2u))

#define CapSenseSlider_TOTAL_CENTROID_AXES_COUNT      ( CapSenseSlider_TOTAL_SLIDERS_COUNT + \
                                                         (CapSenseSlider_TOTAL_TOUCH_PADS_BASIC_COUNT * 2u) +\
                                                         (CapSenseSlider_TOTAL_TRACKPAD_GESTURES_COUNT * 2u))

#define CapSenseSlider_TOTAL_WIDGET_COUNT             ( CapSenseSlider_TOTAL_LINEAR_SLIDERS_COUNT + \
                                                          CapSenseSlider_TOTAL_RADIAL_SLIDERS_COUNT + \
                                                          CapSenseSlider_TOTAL_TOUCH_PADS_COUNT + \
                                                          CapSenseSlider_TOTAL_BUTTONS_COUNT + \
                                                          CapSenseSlider_TOTAL_MATRIX_BUTTONS_COUNT )

#define CapSenseSlider_ANY_POS_FILTER                 ( CapSenseSlider_MEDIAN_FILTER | \
                                                          CapSenseSlider_AVERAGING_FILTER | \
                                                          CapSenseSlider_IIR2_FILTER | \
                                                          CapSenseSlider_IIR4_FILTER | \
                                                          CapSenseSlider_JITTER_FILTER )

#define CapSenseSlider_IS_DIPLEX_SLIDER               ( CapSenseSlider_TOTAL_DIPLEXED_SLIDERS_COUNT > 0u)

#define CapSenseSlider_IS_NON_DIPLEX_SLIDER           ( (CapSenseSlider_TOTAL_LINEAR_SLIDERS_COUNT - \
                                                           CapSenseSlider_TOTAL_DIPLEXED_SLIDERS_COUNT) > 0u)
#define CapSenseSlider_ADD_SLIDER_TYPE                ((CapSenseSlider_TOTAL_RADIAL_SLIDERS_COUNT > 0u) ? \
                                                        ((CapSenseSlider_TOTAL_TOUCH_PADS_COUNT > 0u) || \
                                                         (CapSenseSlider_TOTAL_LINEAR_SLIDERS_COUNT > 0u)) : 0u)

#define CapSenseSlider_TOTAL_PROX_SENSOR_COUNT        (CapSenseSlider_TOTAL_PROX_SENSORS_COUNT)

#define CapSenseSlider_WIDGETS_TBL_SIZE               ( CapSenseSlider_TOTAL_WIDGET_COUNT + \
                                                          CapSenseSlider_TOTAL_GENERICS_COUNT)

#define CapSenseSlider_WIDGET_PARAM_TBL_SIZE          (CapSenseSlider_TOTAL_BUTTONS_COUNT + \
                                                         CapSenseSlider_TOTAL_SLIDERS_COUNT +\
                                                         CapSenseSlider_TOTAL_TOUCH_PADS_BASIC_COUNT * 2u + \
                                                         CapSenseSlider_TOTAL_TRACKPAD_GESTURES_COUNT * 2u +\
                                                         CapSenseSlider_TOTAL_MATRIX_BUTTONS_COUNT * 2u)

#define CapSenseSlider_THRESHOLD_TBL_SIZE         (CapSenseSlider_WIDGET_PARAM_TBL_SIZE)
#define CapSenseSlider_DEBOUNCE_CNT_TBL_SIZE      (CapSenseSlider_WIDGET_PARAM_TBL_SIZE)
#define CapSenseSlider_RAW_DATA_INDEX_TBL_SIZE    (CapSenseSlider_WIDGET_PARAM_TBL_SIZE +\
                                                     CapSenseSlider_TOTAL_GENERICS_COUNT)

#define CapSenseSlider_RES_MULT                   (256u)


#define CapSenseSlider_NOT_WIDGET                     (0xFFFFFFFFu)

/*Types of centroids */
#define CapSenseSlider_TYPE_RADIAL_SLIDER             (0x01u)
#define CapSenseSlider_TYPE_LINEAR_SLIDER             (0x02u)
#define CapSenseSlider_TYPE_GENERIC                   (0xFFu)

/* Defines if sensors or widgets are active */
#define CapSenseSlider_SENSOR_IS_ACTIVE               (0x01u)
#define CapSenseSlider_SENSOR_1_IS_ACTIVE             (0x01u)
#define CapSenseSlider_SENSOR_2_IS_ACTIVE             (0x02u)
#define CapSenseSlider_WIDGET_IS_ACTIVE               (0x01u)

/* Defines diplex type of Slider */
#define CapSenseSlider_IS_DIPLEX                      (0x80u)

/* Defines fingers positions on Slider  */
#define CapSenseSlider_POS_PREV                       (0u)
#define CapSenseSlider_POS                            (1u)
#define CapSenseSlider_POS_NEXT                       (2u)
#define CapSenseSlider_CENTROID_ROUND_VALUE           (0x7F00u)
#define CapSenseSlider_MAXIMUM_CENTROID               (0xFFu)

#define CapSenseSlider_NEGATIVE_NOISE_THRESHOLD       (20u)
#define CapSenseSlider_LOW_BASELINE_RESET             (5u)


/***************************************
*        Function Prototypes
***************************************/

void CapSenseSlider_InitializeSensorBaseline(uint32 sensor);
void CapSenseSlider_InitializeAllBaselines(void);
void CapSenseSlider_InitializeEnabledBaselines(void);
void CapSenseSlider_UpdateSensorBaseline(uint32 sensor);
void CapSenseSlider_UpdateBaselineNoThreshold(uint32 sensor);
void CapSenseSlider_UpdateEnabledBaselines(void);
void CapSenseSlider_UpdateWidgetBaseline(uint32 widget);
uint16 CapSenseSlider_GetBaselineData(uint32 sensor);
void CapSenseSlider_SetBaselineData(uint32 sensor, uint16 data);
void CapSenseSlider_BaseInit(uint32 sensor);

#if (CapSenseSlider_IS_DIPLEX_SLIDER)
    uint8 CapSenseSlider_FindMaximum(uint8 offset, uint8 count, uint8 fingerThreshold, const uint8 *diplex);
#else
    uint8 CapSenseSlider_FindMaximum(uint8 offset, uint8 count, uint8 fingerThreshold);
#endif /* (CapSenseSlider_IS_DIPLEX_SLIDER) */

#if (CapSenseSlider_TOTAL_TRACKPAD_GESTURES_COUNT > 0u)
    uint8 CapSenseSlider_CalcCentroid(uint8 maximum, uint8 offset, \
                                    uint8 count, uint32 resolution, uint8 noiseThreshold);
#else
    uint8 CapSenseSlider_CalcCentroid(uint8 maximum, uint8 offset, \
                                    uint8 count, uint16 resolution, uint8 noiseThreshold);
#endif /* (CapSenseSlider_TOTAL_TRACKPAD_GESTURES_COUNT > 0u) */


uint8 CapSenseSlider_GetFingerThreshold(uint32 widget);
uint8 CapSenseSlider_GetNoiseThreshold(uint32 widget);
uint8 CapSenseSlider_GetFingerHysteresis(uint32 widget);
uint8 CapSenseSlider_GetNegativeNoiseThreshold(uint32 widget);

#if(CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE)
    void CapSenseSlider_SetFingerThreshold(uint32 widget, uint8 value);
    void CapSenseSlider_SetNoiseThreshold(uint32 widget, uint8 value);
    void CapSenseSlider_SetFingerHysteresis(uint32 widget, uint8 value);
    void CapSenseSlider_SetNegativeNoiseThreshold(uint32 widget, uint8 value);
    void CapSenseSlider_SetDebounce(uint32 widget, uint8 value);
    void CapSenseSlider_SetLowBaselineReset(uint32 sensor, uint8 value);
#endif /* (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) */

uint8 CapSenseSlider_GetDiffCountData(uint32 sensor);
void CapSenseSlider_SetDiffCountData(uint32 sensor, uint8 value);

uint32 CapSenseSlider_CheckIsSensorActive(uint32 sensor);
uint32 CapSenseSlider_CheckIsWidgetActive(uint32 widget);
uint32 CapSenseSlider_CheckIsAnyWidgetActive(void);
void CapSenseSlider_EnableWidget(uint32 widget);
void CapSenseSlider_DisableWidget(uint32 widget);
void CapSenseSlider_EnableRawDataFilters(void);
void CapSenseSlider_DisableRawDataFilters(void);

#if (CapSenseSlider_TOTAL_MATRIX_BUTTONS_COUNT)
    uint32 CapSenseSlider_GetMatrixButtonPos(uint32 widget, uint8* pos);
#endif /* (CapSenseSlider_TOTAL_MATRIX_BUTTONS_COUNT) */

#if((CapSenseSlider_TOTAL_RADIAL_SLIDERS_COUNT > 0u) || (CapSenseSlider_TOTAL_LINEAR_SLIDERS_COUNT > 0u))
    uint16 CapSenseSlider_GetCentroidPos(uint32 widget);
#endif /* ((CapSenseSlider_TOTAL_RADIAL_SLIDERS_COUNT > 0u) || (CapSenseSlider_TOTAL_LINEAR_SLIDERS_COUNT > 0u)) */
#if((CapSenseSlider_TOTAL_RADIAL_SLIDERS_COUNT > 0u) || (CapSenseSlider_TOTAL_LINEAR_SLIDERS_COUNT > 0u))
    uint16 CapSenseSlider_GetRadialCentroidPos(uint32 widget);
#endif /* #if((CapSenseSlider_TOTAL_RADIAL_SLIDERS_COUNT > 0u) || (CapSenseSlider_TOTAL_LINEAR_SLIDERS_COUNT > 0u)) */
#if (CapSenseSlider_TOTAL_TOUCH_PADS_COUNT)
    uint32 CapSenseSlider_GetTouchCentroidPos(uint32 widget, uint16* pos);
#endif /* (CapSenseSlider_TOTAL_TOUCH_PADS_COUNT) */

uint32 CapSenseSlider_GetWidgetNumber(uint32 sensor);
uint8 CapSenseSlider_GetLowBaselineReset(uint32 sensor);
uint8 CapSenseSlider_GetDebounce(uint32 widget);

/* Filter function prototypes for High level APIs */

/* Median filter function prototype */
#if ( (0u != (CapSenseSlider_RAW_FILTER_MASK & CapSenseSlider_MEDIAN_FILTER)) || \
      (0u != (CapSenseSlider_POS_FILTERS_MASK & CapSenseSlider_MEDIAN_FILTER)) || \
      ((CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO)) )
    uint16 CapSenseSlider_MedianFilter(uint16 x1, uint16 x2, uint16 x3);
#endif /* ( (0u != (CapSenseSlider_RAW_FILTER_MASK & CapSenseSlider_MEDIAN_FILTER)) || \
      (0u != (CapSenseSlider_POS_FILTERS_MASK & CapSenseSlider_MEDIAN_FILTER)) || \
      ((CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO)) ) */

/* Averaging filter function prototype */
#if ( (0u != (CapSenseSlider_RAW_FILTER_MASK & CapSenseSlider_AVERAGING_FILTER)) || \
      (0u != (CapSenseSlider_POS_FILTERS_MASK & CapSenseSlider_AVERAGING_FILTER)) )
    uint16 CapSenseSlider_AveragingFilter(uint16 x1, uint16 x2, uint16 x3);
#endif /* CapSenseSlider_RAW_FILTER_MASK && CapSenseSlider_POS_FILTERS_MASK */

/* IIR2Filter(1/2prev + 1/2cur) filter function prototype */
#if ( (0u != (CapSenseSlider_RAW_FILTER_MASK & CapSenseSlider_IIR2_FILTER)) || \
      (0u != (CapSenseSlider_POS_FILTERS_MASK & CapSenseSlider_IIR2_FILTER)) )
    uint16 CapSenseSlider_IIR2Filter(uint16 x1, uint16 x2);
#endif /* CapSenseSlider_RAW_FILTER_MASK && CapSenseSlider_POS_FILTERS_MASK */

/* IIR4Filter(3/4prev + 1/4cur) filter function prototype */
#if ( (0u != (CapSenseSlider_RAW_FILTER_MASK & CapSenseSlider_IIR4_FILTER)) || \
      (0u != (CapSenseSlider_POS_FILTERS_MASK & CapSenseSlider_IIR4_FILTER)) )
    uint16 CapSenseSlider_IIR4Filter(uint16 x1, uint16 x2);
#endif /* CapSenseSlider_RAW_FILTER_MASK && CapSenseSlider_POS_FILTERS_MASK */

/* IIR8Filter(7/8prev + 1/8cur) filter function prototype - RawCounts only */
#if (0u != (CapSenseSlider_RAW_FILTER_MASK & CapSenseSlider_IIR8_FILTER))
    uint16 CapSenseSlider_IIR8Filter(uint16 x1, uint16 x2);
#endif /* CapSenseSlider_RAW_FILTER_MASK */

/* IIR16Filter(15/16prev + 1/16cur) filter function prototype - RawCounts only */
#if (0u != (CapSenseSlider_RAW_FILTER_MASK & CapSenseSlider_IIR16_FILTER))
    uint16 CapSenseSlider_IIR16Filter(uint16 x1, uint16 x2);
#endif /* CapSenseSlider_RAW_FILTER_MASK */

/* JitterFilter filter function prototype */
#if ( (0u != (CapSenseSlider_RAW_FILTER_MASK & CapSenseSlider_JITTER_FILTER)) || \
      (0u != (CapSenseSlider_POS_FILTERS_MASK & CapSenseSlider_JITTER_FILTER)) || \
      (0u != (CapSenseSlider_TRACKPAD_GEST_POS_FILTERS_MASK & CapSenseSlider_JITTER_FILTER)))
    uint16 CapSenseSlider_JitterFilter(uint16 x1, uint16 x2);
#endif /* ( (0u != (CapSenseSlider_RAW_FILTER_MASK & CapSenseSlider_JITTER_FILTER)) || \
       *    (0u != (CapSenseSlider_POS_FILTERS_MASK & CapSenseSlider_JITTER_FILTER)) )
       *    (0u != (CapSenseSlider_TRACKPAD_GEST_POS_FILTERS_MASK & CapSenseSlider_JITTER_FILTER)) )
       */


/***************************************
*     Vars with External Linkage
***************************************/
extern uint16 CapSenseSlider_sensorBaseline[CapSenseSlider_TOTAL_SENSOR_COUNT];
extern uint8  CapSenseSlider_sensorBaselineLow[CapSenseSlider_TOTAL_SENSOR_COUNT];
extern uint8 CapSenseSlider_sensorSignal[CapSenseSlider_TOTAL_SENSOR_COUNT];
extern uint8  CapSenseSlider_sensorOnMask[CapSenseSlider_TOTAL_SENSOR_MASK];

extern uint8 CapSenseSlider_lowBaselineResetCnt[CapSenseSlider_TOTAL_SENSOR_COUNT];
extern uint8 CapSenseSlider_lowBaselineReset[CapSenseSlider_TOTAL_SENSOR_COUNT];

/* Generated by Customizer */
#if (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE)
    extern uint8 CapSenseSlider_fingerThreshold[CapSenseSlider_WIDGET_PARAM_TBL_SIZE];
    extern uint8 CapSenseSlider_noiseThreshold[CapSenseSlider_WIDGET_PARAM_TBL_SIZE];
    extern uint8 CapSenseSlider_negativeNoiseThreshold[CapSenseSlider_WIDGET_PARAM_TBL_SIZE];
    extern uint8 CapSenseSlider_hysteresis[CapSenseSlider_WIDGET_PARAM_TBL_SIZE];
    extern uint8  CapSenseSlider_debounce[CapSenseSlider_WIDGET_PARAM_TBL_SIZE];
#else
    extern const uint8 CapSenseSlider_fingerThreshold[CapSenseSlider_WIDGET_PARAM_TBL_SIZE];
    extern const uint8 CapSenseSlider_noiseThreshold[CapSenseSlider_WIDGET_PARAM_TBL_SIZE];
    extern const uint8 CapSenseSlider_hysteresis[CapSenseSlider_WIDGET_PARAM_TBL_SIZE];
    extern const uint8  CapSenseSlider_debounce[CapSenseSlider_WIDGET_PARAM_TBL_SIZE];
#endif /* (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) */

extern const uint8 CapSenseSlider_rawDataIndex[CapSenseSlider_RAW_DATA_INDEX_TBL_SIZE];
extern const uint8 CapSenseSlider_numberOfSensors[CapSenseSlider_RAW_DATA_INDEX_TBL_SIZE];

#if (0u != CapSenseSlider_TOTAL_TRACKPAD_GESTURES_COUNT)
    #if (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE)
        extern uint8 CapSenseSlider_posFiltersMask[CapSenseSlider_TOTAL_CENTROID_AXES_COUNT];
    #else
        extern const uint8 CapSenseSlider_posFiltersMask[CapSenseSlider_TOTAL_CENTROID_AXES_COUNT];
    #endif /* (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) */

    extern uint32 CapSenseSlider_centroidMult[CapSenseSlider_TOTAL_CENTROID_AXES_COUNT];
#endif /* (0u != CapSenseSlider_TOTAL_TRACKPAD_GESTURES_COUNT) */

/***************************************
*        Obsolete Names
***************************************/
#define CapSenseSlider_SensorRaw              CapSenseSlider_sensorRaw
#define CapSenseSlider_SensorEnableMask       CapSenseSlider_sensorEnableMask
#define CapSenseSlider_SensorBaseline         CapSenseSlider_sensorBaseline
#define CapSenseSlider_SensorBaselineLow      CapSenseSlider_sensorBaselineLow
#define CapSenseSlider_SensorSignal           CapSenseSlider_sensorSignal
#define CapSenseSlider_SensorOnMask           CapSenseSlider_sensorOnMask
#define CapSenseSlider_LowBaselineResetCnt    CapSenseSlider_lowBaselineResetCnt

#endif /* CY_CAPSENSE_CSD_CSHL_CapSenseSlider_H */

/* [] END OF FILE */
