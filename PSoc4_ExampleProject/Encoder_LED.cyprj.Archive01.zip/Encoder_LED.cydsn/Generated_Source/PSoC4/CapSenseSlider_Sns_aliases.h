/*******************************************************************************
* File Name: CapSenseSlider_Sns.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CapSenseSlider_Sns_ALIASES_H) /* Pins CapSenseSlider_Sns_ALIASES_H */
#define CY_PINS_CapSenseSlider_Sns_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define CapSenseSlider_Sns_0			(CapSenseSlider_Sns__0__PC)
#define CapSenseSlider_Sns_0_PS		(CapSenseSlider_Sns__0__PS)
#define CapSenseSlider_Sns_0_PC		(CapSenseSlider_Sns__0__PC)
#define CapSenseSlider_Sns_0_DR		(CapSenseSlider_Sns__0__DR)
#define CapSenseSlider_Sns_0_SHIFT	(CapSenseSlider_Sns__0__SHIFT)
#define CapSenseSlider_Sns_0_INTR	((uint16)((uint16)0x0003u << (CapSenseSlider_Sns__0__SHIFT*2u)))

#define CapSenseSlider_Sns_1			(CapSenseSlider_Sns__1__PC)
#define CapSenseSlider_Sns_1_PS		(CapSenseSlider_Sns__1__PS)
#define CapSenseSlider_Sns_1_PC		(CapSenseSlider_Sns__1__PC)
#define CapSenseSlider_Sns_1_DR		(CapSenseSlider_Sns__1__DR)
#define CapSenseSlider_Sns_1_SHIFT	(CapSenseSlider_Sns__1__SHIFT)
#define CapSenseSlider_Sns_1_INTR	((uint16)((uint16)0x0003u << (CapSenseSlider_Sns__1__SHIFT*2u)))

#define CapSenseSlider_Sns_2			(CapSenseSlider_Sns__2__PC)
#define CapSenseSlider_Sns_2_PS		(CapSenseSlider_Sns__2__PS)
#define CapSenseSlider_Sns_2_PC		(CapSenseSlider_Sns__2__PC)
#define CapSenseSlider_Sns_2_DR		(CapSenseSlider_Sns__2__DR)
#define CapSenseSlider_Sns_2_SHIFT	(CapSenseSlider_Sns__2__SHIFT)
#define CapSenseSlider_Sns_2_INTR	((uint16)((uint16)0x0003u << (CapSenseSlider_Sns__2__SHIFT*2u)))

#define CapSenseSlider_Sns_3			(CapSenseSlider_Sns__3__PC)
#define CapSenseSlider_Sns_3_PS		(CapSenseSlider_Sns__3__PS)
#define CapSenseSlider_Sns_3_PC		(CapSenseSlider_Sns__3__PC)
#define CapSenseSlider_Sns_3_DR		(CapSenseSlider_Sns__3__DR)
#define CapSenseSlider_Sns_3_SHIFT	(CapSenseSlider_Sns__3__SHIFT)
#define CapSenseSlider_Sns_3_INTR	((uint16)((uint16)0x0003u << (CapSenseSlider_Sns__3__SHIFT*2u)))

#define CapSenseSlider_Sns_4			(CapSenseSlider_Sns__4__PC)
#define CapSenseSlider_Sns_4_PS		(CapSenseSlider_Sns__4__PS)
#define CapSenseSlider_Sns_4_PC		(CapSenseSlider_Sns__4__PC)
#define CapSenseSlider_Sns_4_DR		(CapSenseSlider_Sns__4__DR)
#define CapSenseSlider_Sns_4_SHIFT	(CapSenseSlider_Sns__4__SHIFT)
#define CapSenseSlider_Sns_4_INTR	((uint16)((uint16)0x0003u << (CapSenseSlider_Sns__4__SHIFT*2u)))

#define CapSenseSlider_Sns_INTR_ALL	 ((uint16)(CapSenseSlider_Sns_0_INTR| CapSenseSlider_Sns_1_INTR| CapSenseSlider_Sns_2_INTR| CapSenseSlider_Sns_3_INTR| CapSenseSlider_Sns_4_INTR))
#define CapSenseSlider_Sns_LinearSlider_e0__LS			(CapSenseSlider_Sns__LinearSlider_e0__LS__PC)
#define CapSenseSlider_Sns_LinearSlider_e0__LS_PS		(CapSenseSlider_Sns__LinearSlider_e0__LS__PS)
#define CapSenseSlider_Sns_LinearSlider_e0__LS_PC		(CapSenseSlider_Sns__LinearSlider_e0__LS__PC)
#define CapSenseSlider_Sns_LinearSlider_e0__LS_DR		(CapSenseSlider_Sns__LinearSlider_e0__LS__DR)
#define CapSenseSlider_Sns_LinearSlider_e0__LS_SHIFT	(CapSenseSlider_Sns__LinearSlider_e0__LS__SHIFT)
#define CapSenseSlider_Sns_LinearSlider_e0__LS_INTR	((uint16)((uint16)0x0003u << (CapSenseSlider_Sns__0__SHIFT*2u)))

#define CapSenseSlider_Sns_LinearSlider_e1__LS			(CapSenseSlider_Sns__LinearSlider_e1__LS__PC)
#define CapSenseSlider_Sns_LinearSlider_e1__LS_PS		(CapSenseSlider_Sns__LinearSlider_e1__LS__PS)
#define CapSenseSlider_Sns_LinearSlider_e1__LS_PC		(CapSenseSlider_Sns__LinearSlider_e1__LS__PC)
#define CapSenseSlider_Sns_LinearSlider_e1__LS_DR		(CapSenseSlider_Sns__LinearSlider_e1__LS__DR)
#define CapSenseSlider_Sns_LinearSlider_e1__LS_SHIFT	(CapSenseSlider_Sns__LinearSlider_e1__LS__SHIFT)
#define CapSenseSlider_Sns_LinearSlider_e1__LS_INTR	((uint16)((uint16)0x0003u << (CapSenseSlider_Sns__1__SHIFT*2u)))

#define CapSenseSlider_Sns_LinearSlider_e2__LS			(CapSenseSlider_Sns__LinearSlider_e2__LS__PC)
#define CapSenseSlider_Sns_LinearSlider_e2__LS_PS		(CapSenseSlider_Sns__LinearSlider_e2__LS__PS)
#define CapSenseSlider_Sns_LinearSlider_e2__LS_PC		(CapSenseSlider_Sns__LinearSlider_e2__LS__PC)
#define CapSenseSlider_Sns_LinearSlider_e2__LS_DR		(CapSenseSlider_Sns__LinearSlider_e2__LS__DR)
#define CapSenseSlider_Sns_LinearSlider_e2__LS_SHIFT	(CapSenseSlider_Sns__LinearSlider_e2__LS__SHIFT)
#define CapSenseSlider_Sns_LinearSlider_e2__LS_INTR	((uint16)((uint16)0x0003u << (CapSenseSlider_Sns__2__SHIFT*2u)))

#define CapSenseSlider_Sns_LinearSlider_e3__LS			(CapSenseSlider_Sns__LinearSlider_e3__LS__PC)
#define CapSenseSlider_Sns_LinearSlider_e3__LS_PS		(CapSenseSlider_Sns__LinearSlider_e3__LS__PS)
#define CapSenseSlider_Sns_LinearSlider_e3__LS_PC		(CapSenseSlider_Sns__LinearSlider_e3__LS__PC)
#define CapSenseSlider_Sns_LinearSlider_e3__LS_DR		(CapSenseSlider_Sns__LinearSlider_e3__LS__DR)
#define CapSenseSlider_Sns_LinearSlider_e3__LS_SHIFT	(CapSenseSlider_Sns__LinearSlider_e3__LS__SHIFT)
#define CapSenseSlider_Sns_LinearSlider_e3__LS_INTR	((uint16)((uint16)0x0003u << (CapSenseSlider_Sns__3__SHIFT*2u)))

#define CapSenseSlider_Sns_LinearSlider_e4__LS			(CapSenseSlider_Sns__LinearSlider_e4__LS__PC)
#define CapSenseSlider_Sns_LinearSlider_e4__LS_PS		(CapSenseSlider_Sns__LinearSlider_e4__LS__PS)
#define CapSenseSlider_Sns_LinearSlider_e4__LS_PC		(CapSenseSlider_Sns__LinearSlider_e4__LS__PC)
#define CapSenseSlider_Sns_LinearSlider_e4__LS_DR		(CapSenseSlider_Sns__LinearSlider_e4__LS__DR)
#define CapSenseSlider_Sns_LinearSlider_e4__LS_SHIFT	(CapSenseSlider_Sns__LinearSlider_e4__LS__SHIFT)
#define CapSenseSlider_Sns_LinearSlider_e4__LS_INTR	((uint16)((uint16)0x0003u << (CapSenseSlider_Sns__4__SHIFT*2u)))


#endif /* End Pins CapSenseSlider_Sns_ALIASES_H */


/* [] END OF FILE */
