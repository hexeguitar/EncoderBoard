/*******************************************************************************
* File Name: CapSenseSlider_SampleClk.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_CapSenseSlider_SampleClk_H)
#define CY_CLOCK_CapSenseSlider_SampleClk_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void CapSenseSlider_SampleClk_StartEx(uint32 alignClkDiv);
#define CapSenseSlider_SampleClk_Start() \
    CapSenseSlider_SampleClk_StartEx(CapSenseSlider_SampleClk__PA_DIV_ID)

#else

void CapSenseSlider_SampleClk_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void CapSenseSlider_SampleClk_Stop(void);

void CapSenseSlider_SampleClk_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 CapSenseSlider_SampleClk_GetDividerRegister(void);
uint8  CapSenseSlider_SampleClk_GetFractionalDividerRegister(void);

#define CapSenseSlider_SampleClk_Enable()                         CapSenseSlider_SampleClk_Start()
#define CapSenseSlider_SampleClk_Disable()                        CapSenseSlider_SampleClk_Stop()
#define CapSenseSlider_SampleClk_SetDividerRegister(clkDivider, reset)  \
    CapSenseSlider_SampleClk_SetFractionalDividerRegister((clkDivider), 0u)
#define CapSenseSlider_SampleClk_SetDivider(clkDivider)           CapSenseSlider_SampleClk_SetDividerRegister((clkDivider), 1u)
#define CapSenseSlider_SampleClk_SetDividerValue(clkDivider)      CapSenseSlider_SampleClk_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define CapSenseSlider_SampleClk_DIV_ID     CapSenseSlider_SampleClk__DIV_ID

#define CapSenseSlider_SampleClk_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define CapSenseSlider_SampleClk_CTRL_REG   (*(reg32 *)CapSenseSlider_SampleClk__CTRL_REGISTER)
#define CapSenseSlider_SampleClk_DIV_REG    (*(reg32 *)CapSenseSlider_SampleClk__DIV_REGISTER)

#define CapSenseSlider_SampleClk_CMD_DIV_SHIFT          (0u)
#define CapSenseSlider_SampleClk_CMD_PA_DIV_SHIFT       (8u)
#define CapSenseSlider_SampleClk_CMD_DISABLE_SHIFT      (30u)
#define CapSenseSlider_SampleClk_CMD_ENABLE_SHIFT       (31u)

#define CapSenseSlider_SampleClk_CMD_DISABLE_MASK       ((uint32)((uint32)1u << CapSenseSlider_SampleClk_CMD_DISABLE_SHIFT))
#define CapSenseSlider_SampleClk_CMD_ENABLE_MASK        ((uint32)((uint32)1u << CapSenseSlider_SampleClk_CMD_ENABLE_SHIFT))

#define CapSenseSlider_SampleClk_DIV_FRAC_MASK  (0x000000F8u)
#define CapSenseSlider_SampleClk_DIV_FRAC_SHIFT (3u)
#define CapSenseSlider_SampleClk_DIV_INT_MASK   (0xFFFFFF00u)
#define CapSenseSlider_SampleClk_DIV_INT_SHIFT  (8u)

#else 

#define CapSenseSlider_SampleClk_DIV_REG        (*(reg32 *)CapSenseSlider_SampleClk__REGISTER)
#define CapSenseSlider_SampleClk_ENABLE_REG     CapSenseSlider_SampleClk_DIV_REG
#define CapSenseSlider_SampleClk_DIV_FRAC_MASK  CapSenseSlider_SampleClk__FRAC_MASK
#define CapSenseSlider_SampleClk_DIV_FRAC_SHIFT (16u)
#define CapSenseSlider_SampleClk_DIV_INT_MASK   CapSenseSlider_SampleClk__DIVIDER_MASK
#define CapSenseSlider_SampleClk_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_CapSenseSlider_SampleClk_H) */

/* [] END OF FILE */
