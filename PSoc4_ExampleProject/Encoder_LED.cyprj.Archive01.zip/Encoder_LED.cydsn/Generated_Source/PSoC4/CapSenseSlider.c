/*******************************************************************************
* File Name: CapSenseSlider.c
* Version 2.40
*
* Description:
*  This file provides the source code for scanning APIs for the CapSense CSD
*  component.
*
* Note:
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CapSenseSlider.h"
#include "CapSenseSlider_PVT.h"
#include "cypins.h"
#include "cyapicallbacks.h"

#if(0u != CapSenseSlider_CSHL_API_GENERATE)
    #include "CapSenseSlider_CSHL.h"
#endif /* (0u != CapSenseSlider_CSHL_API_GENERATE) */

/* This definition is intended to prevent unexpected linker error.
   For more details please see the IAR Technical Note 49981 */
#if defined(__ICCARM__)
    extern void CapSenseSlider_EnableSensor(uint32 sensor);
    extern void CapSenseSlider_DisableSensor(uint32 sensor);
#endif /* (__ICCARM__) */

/* SmartSense functions */
#if (CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO)
    uint8 CapSenseSlider_lowLevelTuningDone = 0u;
    uint8 CapSenseSlider_scanSpeedTbl[((CapSenseSlider_TOTAL_SENSOR_COUNT - 1u) / 8u) + 1u];
#endif /* (CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) */

#if(CapSenseSlider_PRS_OPTIONS != CapSenseSlider__PRS_NONE)
    uint8 CapSenseSlider_prescalersTuningDone = 0u;
#endif /* (CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_NONE) */

/* Global software variables */
volatile uint8 CapSenseSlider_csdStatusVar = 0u;   /* CapSense CSD status, variable */
volatile uint8 CapSenseSlider_sensorIndex = 0u;    /* Index of scannig sensor */

/* Global array of Raw Counts */
uint16 CapSenseSlider_sensorRaw[CapSenseSlider_TOTAL_SENSOR_COUNT] = {0u};

/* Backup variables for trim registers*/
#if (CapSenseSlider_IDAC1_POLARITY == CapSenseSlider__IDAC_SINK)
    uint8 CapSenseSlider_csdTrim2;
#else
    uint8 CapSenseSlider_csdTrim1;
#endif /* (CapSenseSlider_IDAC1_POLARITY == CapSenseSlider__IDAC_SINK) */

/* Global array of un-scanned sensors state */
uint8 CapSenseSlider_unscannedSnsDriveMode[CapSenseSlider_PORT_PIN_CONFIG_TBL_ZISE];

/* Backup array for CapSenseSlider_sensorEnableMask */
uint8 CapSenseSlider_sensorEnableMaskBackup[(((CapSenseSlider_TOTAL_SENSOR_COUNT - 1u) / 8u) + 1u)];

/* Configured constants and arrays by Customizer */
uint8 CapSenseSlider_sensorEnableMask[(((CapSenseSlider_TOTAL_SENSOR_COUNT - 1u) / 8u) + 1u)] = {
0x1Fu, };

reg32 * CapSenseSlider_pcTable[] = {
    (reg32 *)CapSenseSlider_Sns__LinearSlider_e0__LS__PC, 
    (reg32 *)CapSenseSlider_Sns__LinearSlider_e1__LS__PC, 
    (reg32 *)CapSenseSlider_Sns__LinearSlider_e2__LS__PC, 
    (reg32 *)CapSenseSlider_Sns__LinearSlider_e3__LS__PC, 
    (reg32 *)CapSenseSlider_Sns__LinearSlider_e4__LS__PC, 
};

const uint8 CapSenseSlider_portTable[] = {
    CapSenseSlider_Sns__LinearSlider_e0__LS__PORT, 
    CapSenseSlider_Sns__LinearSlider_e1__LS__PORT, 
    CapSenseSlider_Sns__LinearSlider_e2__LS__PORT, 
    CapSenseSlider_Sns__LinearSlider_e3__LS__PORT, 
    CapSenseSlider_Sns__LinearSlider_e4__LS__PORT, 
};

const uint32 CapSenseSlider_maskTable[] = {
    CapSenseSlider_Sns__LinearSlider_e0__LS__MASK, 
    CapSenseSlider_Sns__LinearSlider_e1__LS__MASK, 
    CapSenseSlider_Sns__LinearSlider_e2__LS__MASK, 
    CapSenseSlider_Sns__LinearSlider_e3__LS__MASK, 
    CapSenseSlider_Sns__LinearSlider_e4__LS__MASK, 
};

const uint8 CapSenseSlider_pinShiftTbl[] = {
    (uint8) CapSenseSlider_Sns__LinearSlider_e0__LS__SHIFT, 
    (uint8) CapSenseSlider_Sns__LinearSlider_e1__LS__SHIFT, 
    (uint8) CapSenseSlider_Sns__LinearSlider_e2__LS__SHIFT, 
    (uint8) CapSenseSlider_Sns__LinearSlider_e3__LS__SHIFT, 
    (uint8) CapSenseSlider_Sns__LinearSlider_e4__LS__SHIFT, 
};

uint8 CapSenseSlider_modulationIDAC[CapSenseSlider_TOTAL_SENSOR_COUNT];
uint8 CapSenseSlider_compensationIDAC[CapSenseSlider_TOTAL_SENSOR_COUNT];

uint32 CapSenseSlider_widgetResolution[CapSenseSlider_RESOLUTIONS_TBL_SIZE] = {
    CapSenseSlider_RESOLUTION_12_BITS,
};

uint8 CapSenseSlider_senseClkDividerVal[CapSenseSlider_TOTAL_SCANSLOT_COUNT];
uint8 CapSenseSlider_sampleClkDividerVal[CapSenseSlider_TOTAL_SCANSLOT_COUNT];

const uint8 CapSenseSlider_widgetNumber[CapSenseSlider_TOTAL_SENSOR_COUNT] = {
    0u, 0u, 0u, 0u, 0u, /* LinearSlider__LS */
};

reg32* const CapSenseSlider_prtSelTbl[CapSenseSlider_CFG_REG_TBL_SIZE] = {
    ((reg32 *) CYREG_HSIOM_PORT_SEL0),
    ((reg32 *) CYREG_HSIOM_PORT_SEL1),
    ((reg32 *) CYREG_HSIOM_PORT_SEL2),
    ((reg32 *) CYREG_HSIOM_PORT_SEL3),
    ((reg32 *) CYREG_HSIOM_PORT_SEL4),
};

reg32* const CapSenseSlider_prtCfgTbl[CapSenseSlider_CFG_REG_TBL_SIZE] = {
    ((reg32 *) CYREG_PRT0_PC),
    ((reg32 *) CYREG_PRT1_PC),
    ((reg32 *) CYREG_PRT2_PC),
    ((reg32 *) CYREG_PRT3_PC),
    ((reg32 *) CYREG_PRT4_PC),
};

reg32* const CapSenseSlider_prtDRTbl[CapSenseSlider_CFG_REG_TBL_SIZE] = {
    ((reg32 *) CYREG_PRT0_DR),
    ((reg32 *) CYREG_PRT1_DR),
    ((reg32 *) CYREG_PRT2_DR),
    ((reg32 *) CYREG_PRT3_DR),
    ((reg32 *) CYREG_PRT4_DR),
};



/*******************************************************************************
* Function Name: CapSenseSlider_Init
********************************************************************************
*
* Summary:
*  API initializes default CapSense configuration provided by the customizer that defines
*  the mode of component operations and resets all the sensors to an inactive state.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_immunityIndex - defines immunity level.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_Init(void)
{
    uint32 curSensor;

    #if(CapSenseSlider_IS_SHIELD_ENABLE)

        #if((CapSenseSlider_CSH_TANK_PREGARGE_OPTION == CapSenseSlider__CAPPRIOBUF) || (0u != CapSenseSlider_CSH_TANK_ENABLE))
            uint32 newRegValue;

            newRegValue = CapSenseSlider_CTANK_CONNECTION_REG;
            newRegValue &= ~(CapSenseSlider_CSD_CTANK_CONNECTION_MASK);
            newRegValue |= CapSenseSlider_CSD_CTANK_TO_AMUXBUS_B;
            CapSenseSlider_CTANK_CONNECTION_REG = newRegValue;

            #if(CapSenseSlider_CSH_TANK_PREGARGE_OPTION == CapSenseSlider__CAPPRIOBUF)
                newRegValue = CapSenseSlider_CTANK_PORT_PC_REG;
                newRegValue &= ~(CapSenseSlider_CSD_CTANK_PC_MASK);
                newRegValue |= CapSenseSlider_CTANK_PC_STRONG_MODE;
                CapSenseSlider_CTANK_PORT_PC_REG = newRegValue;

                newRegValue = CapSenseSlider_CTANK_PORT_DR_REG;
                newRegValue &= ~(CapSenseSlider_CTANK_DR_MASK);
                newRegValue |= CapSenseSlider_CTANK_DR_CONFIG;
                CapSenseSlider_CTANK_PORT_DR_REG = newRegValue;
            #endif /* (CapSenseSlider_CSH_TANK_PREGARGE_OPTION == CapSenseSlider__CAPPRIOBUF) */

        #endif /* ((CapSenseSlider_CSH_TANK_PREGARGE_OPTION == CapSenseSlider__CAPPRIOBUF) || (CapSenseSlider_CSH_TANK_ENABLE)) */

        CapSenseSlider_EnableShieldElectrode((uint32)CapSenseSlider_SHIELD_PIN_NUMBER, (uint32)CapSenseSlider_SHIELD_PORT_NUMBER);

    #endif /* (CapSenseSlider_IS_SHIELD_ENABLE) */

    for(curSensor = 0u; curSensor < CapSenseSlider_TOTAL_SENSOR_COUNT; curSensor++)
    {
        CapSenseSlider_SetUnscannedSensorState(curSensor, CapSenseSlider_CONNECT_INACTIVE_SNS);
    }

    CapSenseSlider_CsdHwBlockInit();
    CapSenseSlider_SetShieldDelay(CapSenseSlider_SHIELD_DELAY );

    /* Clear all sensors */
    CapSenseSlider_ClearSensors();
}

/*******************************************************************************
* Function Name: CapSenseSlider_CsdHwBlockInit
********************************************************************************
*
* Summary:
*  Initialises the hardware parameters of the CSD block
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_csdTrim1 - Contains IDAC trim register value for Sourcing Mode.
*  CapSenseSlider_csdTrim2 - Contains IDAC trim register value for Sinking Mode.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_CsdHwBlockInit(void)
{
    uint32 newRegValue;

        /* Set trim registers for CSD Mode */
    #if (CapSenseSlider_IDAC1_POLARITY == CapSenseSlider__IDAC_SINK)
        /* iDAC1 Sinking Mode */
        CapSenseSlider_csdTrim2 = (uint8)CapSenseSlider_CSD_TRIM2_REG;
        newRegValue = CapSenseSlider_csdTrim2;
        newRegValue &= CapSenseSlider_CSD_IDAC1_TRIM_MASK;
        newRegValue |= (uint32)((uint32)CapSenseSlider_SFLASH_CSD_TRIM2_REG & (uint32)CapSenseSlider_CSFLASH_TRIM_IDAC1_MASK);

        #if (CapSenseSlider_IDAC_CNT == 2u)
            /* iDAC2 Sinking Mode */
            newRegValue &= CapSenseSlider_CSD_IDAC2_TRIM_MASK;
            newRegValue |= (uint32)((uint32)CapSenseSlider_SFLASH_CSD_TRIM2_REG & (uint32)CapSenseSlider_CSFLASH_TRIM_IDAC2_MASK);
        #endif /* (CapSenseSlider_IDAC_CNT == 2u) */
        CapSenseSlider_CSD_TRIM2_REG = newRegValue;
    #else
        /* iDAC1 Sourcing Mode */
        CapSenseSlider_csdTrim1 = (uint8)CapSenseSlider_CSD_TRIM1_REG;
        newRegValue = CapSenseSlider_csdTrim1;
        newRegValue &= CapSenseSlider_CSD_IDAC1_TRIM_MASK;
        newRegValue |= (uint32)((uint32)CapSenseSlider_SFLASH_CSD_TRIM1_REG & (uint32)CapSenseSlider_CSFLASH_TRIM_IDAC1_MASK);
        #if (CapSenseSlider_IDAC_CNT == 2u)
             /* iDAC2 Sourcing Mode */
            newRegValue &= CapSenseSlider_CSD_IDAC2_TRIM_MASK;
            newRegValue |= (uint32)((uint32)CapSenseSlider_SFLASH_CSD_TRIM1_REG & (uint32)CapSenseSlider_CSFLASH_TRIM_IDAC2_MASK);
        #endif
        CapSenseSlider_CSD_TRIM1_REG = newRegValue;
    #endif /* (CapSenseSlider_IDAC1_POLARITY == CapSenseSlider__IDAC_SINK) */

    /* Configure CSD and IDAC */
    #if (CapSenseSlider_IDAC_CNT > 1u)
        CapSenseSlider_CSD_IDAC_REG = CapSenseSlider_DEFAULT_CSD_IDAC_CONFIG;
        CapSenseSlider_CSD_CFG_REG = CapSenseSlider_DEFAULT_CSD_CONFIG;
    #else
        CapSenseSlider_CSD_IDAC_REG &= ~(CapSenseSlider_CSD_IDAC1_MODE_MASK  | CapSenseSlider_CSD_IDAC1_DATA_MASK);
        CapSenseSlider_CSD_IDAC_REG |= CapSenseSlider_DEFAULT_CSD_IDAC_CONFIG;

        CapSenseSlider_CSD_CFG_REG &= ~(CapSenseSlider_CSD_CONFIG_MASK);
        CapSenseSlider_CSD_CFG_REG |= (CapSenseSlider_DEFAULT_CSD_CONFIG);
    #endif /* (CapSenseSlider_IDAC_CNT > 1u) */


    /* Connect Cmod to AMUX bus */
    newRegValue = CapSenseSlider_CMOD_CONNECTION_REG;
    newRegValue &= ~(CapSenseSlider_CSD_CMOD_CONNECTION_MASK);
    newRegValue |= CapSenseSlider_CSD_CMOD_TO_AMUXBUS_A;
    CapSenseSlider_CMOD_CONNECTION_REG = newRegValue;

    /* Configure Dead Band PWM if it is enabled */
    #if(CapSenseSlider_CSD_4B_PWM_MODE != CapSenseSlider__PWM_OFF)
        CapSenseSlider_CSD_4B_PWM_REG = CapSenseSlider_DEFAULT_CSD_4B_PWM_CONFIG;
    #endif /* (CapSenseSlider_CSD_4B_PWM_MODE != CapSenseSlider__PWM_OFF) */

    /* Setup ISR */
    CyIntDisable(CapSenseSlider_ISR_NUMBER);
    #if !defined(CY_EXTERNAL_INTERRUPT_CONFIG)
        (void)CyIntSetVector(CapSenseSlider_ISR_NUMBER, &CapSenseSlider_ISR);
        CyIntSetPriority(CapSenseSlider_ISR_NUMBER, CapSenseSlider_ISR_PRIORITY);
    #endif /* (CY_EXTERNAL_INTERRUPT_CONFIG) */
}


/*******************************************************************************
* Function Name: CapSenseSlider_Enable
********************************************************************************
*
* Summary:
*  Enables the CSD block and related resources to an active mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  None.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_Enable(void)
{
    uint32 newRegValue;

    /* Enable Clocks */
    CapSenseSlider_SenseClk_Stop();
    CapSenseSlider_SampleClk_Stop();

    CapSenseSlider_SampleClk_SetDividerValue((uint16)CapSenseSlider_INITIAL_CLK_DIVIDER);
    CapSenseSlider_SenseClk_SetDividerValue((uint16)CapSenseSlider_INITIAL_CLK_DIVIDER);

    #if (0u == CapSenseSlider_IS_M0S8PERI_BLOCK)
        CapSenseSlider_SenseClk_Start();
        CapSenseSlider_SampleClk_Start();
    #else
        CapSenseSlider_SampleClk_Start();
        CapSenseSlider_SenseClk_StartEx(CapSenseSlider_SampleClk__DIV_ID);
    #endif /* (0u == CapSenseSlider_IS_M0S8PERI_BLOCK) */

    /* Enable the CSD block */
    newRegValue = CapSenseSlider_CSD_CFG_REG;
    newRegValue |= (CapSenseSlider_CSD_CFG_ENABLE | CapSenseSlider_CSD_CFG_SENSE_COMP_EN
                                                   | CapSenseSlider_CSD_CFG_SENSE_EN);
    CapSenseSlider_CSD_CFG_REG = newRegValue;

    /* Enable interrupt */
    CyIntEnable(CapSenseSlider_ISR_NUMBER);
}


/*******************************************************************************
* Function Name: CapSenseSlider_Start
********************************************************************************
*
* Summary:
*  This is the preferred method to begin the component operation. CapSense_Start()
*  calls the CapSense_Init() function, and then calls the CapSense_Enable()
*  function. Initializes the registers and starts the CSD method of the CapSense
*  component. Resets all the sensors to an inactive state. Enables interrupts for
*  sensors scanning. When the SmartSense tuning mode is selected, the tuning procedure
*  is applied for all the sensors. The CapSense_Start() routine must be called before
*  any other API routines.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*   CapSenseSlider_initVar - used to check the initial configuration,
*   modified on the first function call.
*  CapSenseSlider_lowLevelTuningDone - Used to notify the Tuner GUI that
*   tuning of the scanning parameters is done.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_Start(void)
{

    static uint8 CapSenseSlider_initVar = 0u;

    #if((0u != CapSenseSlider_AUTOCALIBRATION_ENABLE) && (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_AUTO))
        uint32 curSensor;
        uint32 rawLevel;
        uint32 widget;
    #endif /* ((0u != CapSenseSlider_AUTOCALIBRATION_ENABLE) && (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_AUTO)) */

    if (CapSenseSlider_initVar == 0u)
    {
        CapSenseSlider_Init();
        CapSenseSlider_initVar = 1u;
    }
    CapSenseSlider_Enable();

    /* AutoTunning start */
    #if(CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO)
        #if(0u != CapSenseSlider_CSHL_API_GENERATE)
            CapSenseSlider_AutoTune();
            CapSenseSlider_lowLevelTuningDone = 1u;
        #endif /* (0u != CapSenseSlider_CSHL_API_GENERATE) */
    #else
        #if(0u != CapSenseSlider_AUTOCALIBRATION_ENABLE)

            #if(CapSenseSlider_IDAC_CNT > 1u)
                CapSenseSlider_CSD_IDAC_REG &= ~(CapSenseSlider_CSD_IDAC2_MODE_MASK);
            #endif /* (CapSenseSlider_IDAC_CNT > 1u) */

            for(curSensor = 0u; curSensor < CapSenseSlider_TOTAL_SCANSLOT_COUNT; curSensor++)
            {
                widget = CapSenseSlider_widgetNumber[curSensor];
                rawLevel = CapSenseSlider_widgetResolution[widget] >> CapSenseSlider_RESOLUTION_OFFSET;

                /* Calibration level should be equal to 85% from scanning resolution */
                rawLevel = (rawLevel * 85u) / 100u;

                CapSenseSlider_CalibrateSensor(curSensor, rawLevel, CapSenseSlider_modulationIDAC);
            }

            #if(0u != CapSenseSlider_TOTAL_CENTROIDS_COUNT)
                CapSenseSlider_NormalizeWidgets(CapSenseSlider_END_OF_WIDGETS_INDEX, CapSenseSlider_modulationIDAC);
            #endif /* (0u != CapSenseSlider_TOTAL_CENTROIDS_COUNT)  */

            #if(CapSenseSlider_IDAC_CNT > 1u)
                for(curSensor = 0u; curSensor < CapSenseSlider_TOTAL_SCANSLOT_COUNT; curSensor++)
                {
                    CapSenseSlider_compensationIDAC[curSensor] = CapSenseSlider_modulationIDAC[curSensor] / 2u;
                    CapSenseSlider_modulationIDAC[curSensor] = (CapSenseSlider_modulationIDAC[curSensor] + 1u) / 2u;
                }
                CapSenseSlider_CSD_IDAC_REG |= CapSenseSlider_CSD_IDAC2_MODE_FIXED;
            #endif /* (CapSenseSlider_IDAC_CNT > 1u) */

        #endif /* (0u != CapSenseSlider_AUTOCALIBRATION_ENABLE) */

    #endif /* ((CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) */

    /* Initialize Advanced Centroid */
    #if(CapSenseSlider_TOTAL_TRACKPAD_GESTURES_COUNT > 0u)
        CapSenseSlider_AdvancedCentroidInit();
    #endif /* (CapSenseSlider_TOTAL_TRACKPAD_GESTURES_COUNT > 0u) */

    /* Connect sense comparator input to AMUXA */
    CapSenseSlider_CSD_CFG_REG |= CapSenseSlider_CSD_CFG_SENSE_INSEL;
}


/*******************************************************************************
* Function Name: CapSenseSlider_Stop
********************************************************************************
*
* Summary:
*  Stops the sensor scanning, disables component interrupts, and resets all the
*  sensors to an inactive state. Disables the Active mode power template bits for
*  the subcomponents used within CapSense.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_csdTrim1 - Contains the IDAC trim register value for the Sourcing Mode.
*  CapSenseSlider_csdTrim2 - Contains the IDAC trim register value for vSinking Mode.
*
* Side Effects:
*  This function should be called after scans are completed.
*
*******************************************************************************/
void CapSenseSlider_Stop(void)
{
    /* Disable interrupt */
    CyIntDisable(CapSenseSlider_ISR_NUMBER);

    CapSenseSlider_CSD_CFG_REG &= ~(CapSenseSlider_CSD_CFG_SENSE_COMP_EN | CapSenseSlider_CSD_CFG_SENSE_EN);

    #if(CapSenseSlider_IDAC_CNT == 2u)
        CapSenseSlider_CSD_CFG_REG &= ~(CapSenseSlider_CSD_CFG_ENABLE);
    #endif /* (CapSenseSlider_IDAC_CNT == 2u) */

    /* Disable the Clocks */
    CapSenseSlider_SenseClk_Stop();
    CapSenseSlider_SampleClk_Stop();
}


/*******************************************************************************
* Function Name: CapSenseSlider_FindNextSensor
********************************************************************************
*
* Summary:
*  Finds the next sensor to scan.
*
* Parameters:
*  snsIndex:  Current index of sensor.
*
* Return:
*  Returns the next sensor index to scan.
*
* Global Variables:
*  CapSenseSlider_sensorEnableMask[] - used to store bit masks of the enabled sensors.
*
* Side Effects:
*  This function affects the  current scanning and should not
*  be used outside the component.
*
*******************************************************************************/
uint8 CapSenseSlider_FindNextSensor(uint8 snsIndex)
{
    uint32 enableFlag;

    /* Check if sensor enabled */
    do
    {
        /* Proceed with next sensor */
        snsIndex++;
        if(snsIndex == CapSenseSlider_TOTAL_SENSOR_COUNT)
        {
            break;
        }
        enableFlag = CapSenseSlider_GetBitValue(CapSenseSlider_sensorEnableMask, (uint32)snsIndex);
    }
    while(enableFlag == 0u);

    return ((uint8)snsIndex);
}


/*******************************************************************************
* Function Name: CapSenseSlider_ScanSensor
********************************************************************************
*
* Summary:
*  Sets the scan settings and starts scanning a sensor. After scanning is complete,
*  the ISR copies the measured sensor raw data to the global raw sensor array.
*  Use of the ISR ensures this function is non-blocking.
*  Each sensor has a unique number within the sensor array.
*  This number is assigned by the CapSense customizer in sequence.
*
* Parameters:
*  sensor:  Sensor number.
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_csdStatusVar - used to provide the status and mode of the scanning process.
*  Sets the busy status(scan in progress) and mode of scan as single scan.
*  CapSenseSlider_sensorIndex - used to store a sensor scanning sensor number.
*  Sets to the provided sensor argument.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_ScanSensor(uint32 sensor)
{
    /* Clears status/control variable and set sensorIndex */
    CapSenseSlider_csdStatusVar = 0u;
    CapSenseSlider_sensorIndex = (uint8)sensor;

    /* Start of sensor scan */
    CapSenseSlider_csdStatusVar = (CapSenseSlider_SW_STS_BUSY | CapSenseSlider_SW_CTRL_SINGLE_SCAN);
    CapSenseSlider_PreScan(sensor);
}


#if(0u != CapSenseSlider_CSHL_API_GENERATE)
/*******************************************************************************
* Function Name: CapSenseSlider_ScanWidget
********************************************************************************
*
* Summary:
*  Sets the scan settings and starts scanning a widget.
*
* Parameters:
*  uint32 widget: Widget number.
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_csdStatusVar - used to provide the status and mode of the scanning process.
*  Sets the busy status(scan in progress) and clears the single scan mode.
*  CapSenseSlider_sensorIndex - used to store a sensor scanning sensor number.
*  Sets to 0xFF and provided to function CapSenseSlider_FindNextSensor or
*  CapSenseSlider_sensorEnableMask[] - used to store bit masks of the enabled sensors.
*  CapSenseSlider_sensorEnableMaskBackup[] - used to backup bit masks of the enabled
*   sensors.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_ScanWidget(uint32 widget)
{
    uint32 sensorsPerWidget;
    uint32 lastSensor;
    uint32 snsIndex;

    /* Get first sensor in widget */
    CapSenseSlider_sensorIndex = CapSenseSlider_rawDataIndex[widget];

    /* Get number of sensors in widget */
    sensorsPerWidget = CapSenseSlider_numberOfSensors[widget];

    /* Check if generic Sensor */
    if(sensorsPerWidget == 0u)
    {
        sensorsPerWidget = 1u;
    }

    /* Get last sensor in widget */
    lastSensor = (CapSenseSlider_rawDataIndex[widget] + sensorsPerWidget) - 1u;

    /* Backup sensorEnableMask array */
    for(snsIndex = 0u; snsIndex < CapSenseSlider_TOTAL_SENSOR_MASK; snsIndex++)
    {
        /* Backup sensorEnableMask array */
        CapSenseSlider_sensorEnableMaskBackup[snsIndex] = CapSenseSlider_sensorEnableMask[snsIndex];
    }

    /* Update sensorEnableMask to scan the sensors that belong to widget */
    for(snsIndex = 0u; snsIndex < CapSenseSlider_TOTAL_SENSOR_COUNT; snsIndex++)
    {
        /* Update sensorEnableMask array bits to scan the widget only */
        if((snsIndex >= CapSenseSlider_sensorIndex) && (snsIndex <= lastSensor))
        {
            /* Set sensor bit to scan */
            CapSenseSlider_SetBitValue(CapSenseSlider_sensorEnableMask, snsIndex, 1u);
        }
        else
        {
            /* Reset sensor bit to do not scan */
            CapSenseSlider_SetBitValue(CapSenseSlider_sensorEnableMask, snsIndex, 0u);
        }
    }

    /* Check end of scan condition */
    if(CapSenseSlider_sensorIndex < CapSenseSlider_TOTAL_SENSOR_COUNT)
    {
        /* Set widget busy bit in status/control variable*/
        CapSenseSlider_csdStatusVar = (CapSenseSlider_SW_STS_BUSY | CapSenseSlider_SW_CTRL_WIDGET_SCAN);
        /* Scan first sensor of widget*/
        CapSenseSlider_PreScan((uint32)CapSenseSlider_sensorIndex);
    }
}
#endif /* (0u != CapSenseSlider_CSHL_API_GENERATE) */


/*******************************************************************************
* Function Name: CapSenseSlider_ScanEnableWidgets
********************************************************************************
*
* Summary:
*  This is the preferred method to scan all of the enabled widgets.
*  The API starts scanning a sensor within the enabled widgets.
*  The ISR continues scanning the sensors until all the enabled widgets are scanned.
*  Use of the ISR ensures this function is non-blocking.
*  All the widgets are enabled by default except proximity widgets.
*  The proximity widgets must be manually enabled as their long scan time
*  is incompatible with a fast response required of other widget types.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_csdStatusVar - used to provide the status and mode of the scanning process.
*  Sets the busy status(scan in progress) and clears the single scan mode.
*  CapSenseSlider_sensorIndex - used to store a sensor scanning sensor number.
*  Sets to 0xFF and provided to function CapSenseSlider_FindNextSensor or
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_ScanEnabledWidgets(void)
{
    /* Clears status/control variable and set sensorIndex */
    CapSenseSlider_csdStatusVar = 0u;
    CapSenseSlider_sensorIndex = 0xFFu;

    /* Find next sensor */
    CapSenseSlider_sensorIndex = (uint8)CapSenseSlider_FindNextSensor(CapSenseSlider_sensorIndex);

    /* Check end of scan condition */
    if(CapSenseSlider_sensorIndex < CapSenseSlider_TOTAL_SENSOR_COUNT)
    {
        CapSenseSlider_csdStatusVar |= CapSenseSlider_SW_STS_BUSY;
        CapSenseSlider_PreScan((uint32)CapSenseSlider_sensorIndex);
    }
}


/*******************************************************************************
* Function Name: CapSenseSlider_IsBusy
********************************************************************************
*
* Summary:
*  Returns the state of the CapSense component. 1 means that scanning in
*  progress and 0 means that scanning is complete.
*
* Parameters:
*  None
*
* Return:
*  Returns the state of scanning. 1 - scanning in progress, 0 - scanning
*  completed.
*
* Global Variables:
*  CapSenseSlider_csdStatusVar - used to provide the status and mode of the scanning process.
*  Checks the busy status.
*
* Side Effects:
*  None
*
*******************************************************************************/
uint32 CapSenseSlider_IsBusy(void)
{
    return ((uint32)((0u != (CapSenseSlider_csdStatusVar & CapSenseSlider_SW_STS_BUSY)) ? 1u : 0u));
}


/*******************************************************************************
* Function Name: CapSenseSlider_ReadSensorRaw
********************************************************************************
*
* Summary:
*  Returns sensor raw data from the global CapSense_sensorRaw[ ] array.
*  Each scan sensor has a unique number within the sensor array.
*  This number is assigned by the CapSense customizer in sequence.
*  Raw data can be used to perform calculations outside of the CapSense
*  provided framework.
*
* Parameters:
*  sensor:  Sensor number.
*
* Return:
*  Returns the current raw data value for a defined sensor number.
*
* Global Variables:
*  CapSenseSlider_sensorRaw[] - used to store sensors raw data.
*
* Side Effects:
*  None
*
*******************************************************************************/
uint16 CapSenseSlider_ReadSensorRaw(uint32 sensor)
{
    return CapSenseSlider_sensorRaw[sensor];
}


/*******************************************************************************
* Function Name: CapSenseSlider_WriteSensorRaw
********************************************************************************
*
* Summary:
*  This API writes the raw count value passed as an argument to the sensor Raw count array.
*
* Parameters:
*  sensor:  Sensor number.
*  value: Raw count value.
*
* Global Variables:
*  CapSenseSlider_sensorRaw[] - used to store sensors raw data.
*
* Return:
*  None
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_WriteSensorRaw(uint32 sensor, uint16 value)
{
    CapSenseSlider_sensorRaw[sensor] = value;
}


#if (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE)
    /*******************************************************************************
    * Function Name: CapSenseSlider_SetScanResolution
    ********************************************************************************
    *
    * Summary:
    *  Sets a value of the sensor scan resolution for a widget.
    *  The MIN resolution can be set 8-bit. The MAX Resolution can be set 16 bit.
    *  This function is not available for the tuning mode "None".
    *
    * Parameters:
    *  widget:     Widget index.
    *  resolution: Represents the resolution value. The following defines which are available in the
    *              CapSenseSlider.h file should be used:
    *              CapSenseSlider_RESOLUTION_6_BITS
    *              CapSenseSlider_RESOLUTION_7_BITS
    *              CapSenseSlider_RESOLUTION_8_BITS
    *              CapSenseSlider_RESOLUTION_9_BITS
    *              CapSenseSlider_RESOLUTION_10_BITS
    *              CapSenseSlider_RESOLUTION_11_BITS
    *              CapSenseSlider_RESOLUTION_12_BITS
    *              CapSenseSlider_RESOLUTION_13_BITS
    *              CapSenseSlider_RESOLUTION_14_BITS
    *              CapSenseSlider_RESOLUTION_15_BITS
    *              CapSenseSlider_RESOLUTION_16_BITS
    *
    * Return:
    *  None
    *
    * Global Variables:
    *  CapSenseSlider_widgetResolution[] - used to store scan resolution of each widget.
    *
    * Side Effects:
    *  None
    *
    *******************************************************************************/
    void CapSenseSlider_SetScanResolution(uint32 widget, uint32 resolution)
    {
        CapSenseSlider_widgetResolution[widget] = resolution;
    }
#endif /* (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) */


/*******************************************************************************
* Function Name: CapSenseSlider_GetScanResolution
********************************************************************************
*
* Summary:
*  Returns the resolution value for the appropriate sensor.
*  This function is not available for tuning mode "None".
*
* Parameters:
*  widget:     Widget index.
*
* Return:
*  resolution: Returns the resolution value for the appropriate sensor.
*              The resolution values are defined in the CapSenseSlider.h file
*              The defines are encountered below:
*              CapSenseSlider_RESOLUTION_6_BITS
*              CapSenseSlider_RESOLUTION_7_BITS
*              CapSenseSlider_RESOLUTION_8_BITS
*              CapSenseSlider_RESOLUTION_9_BITS
*              CapSenseSlider_RESOLUTION_10_BITS
*              CapSenseSlider_RESOLUTION_11_BITS
*              CapSenseSlider_RESOLUTION_12_BITS
*              CapSenseSlider_RESOLUTION_13_BITS
*              CapSenseSlider_RESOLUTION_14_BITS
*              CapSenseSlider_RESOLUTION_15_BITS
*              CapSenseSlider_RESOLUTION_16_BITS
*
* Global Variables:
*  CapSenseSlider_widgetResolution[] - used to store scan resolution of every widget.
*
* Side Effects:
*  None
*
*******************************************************************************/
uint32 CapSenseSlider_GetScanResolution(uint32 widget)
{
    return(CapSenseSlider_widgetResolution[widget]);
}


/*******************************************************************************
* Function Name: CapSenseSlider_ClearSensors
********************************************************************************
*
* Summary:
*  Resets all the sensors to the non-sampling state by sequentially disconnecting
*  all the sensors from Analog MUX Bus and putting them to an inactive state.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  None
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_ClearSensors(void)
{
    uint32 snsIndex;

    for (snsIndex = 0u; snsIndex < CapSenseSlider_TOTAL_SENSOR_COUNT; snsIndex++)
    {
        CapSenseSlider_DisableScanSlot(snsIndex);
    }
}


#if (CapSenseSlider_IS_COMPLEX_SCANSLOTS)
    /*******************************************************************************
    * Function Name: CapSenseSlider_EnableScanSlot
    ********************************************************************************
    *
    * Summary:
    *  Configures the selected slot to measure during the next measurement
    *  cycle. The corresponding pin/pins are set to Analog High-Z mode and
    *  connected to the Analog Mux Bus. This also enables the comparator function.
    *
    * Parameters:
    *  slot:  Slot number.
    *
    * Return:
    *  None
    *
    * Global Constants:
    *  CapSenseSlider_portTable[]  - used to store the port number that pin
    *  belongs to for each sensor.
    *  CapSenseSlider_maskTable[]  - used to store the pin within the port for
    *  each sensor.
    *  CapSenseSlider_indexTable[] - used to store indexes of complex sensors.
    *  The offset and position in this array are stored in a port and mask table for
    *  complex sensors.
    *  Bit 7 (msb) is used to define the sensor type: single or complex.
    *
    * Side Effects:
    *  None
    *
    *******************************************************************************/
    void CapSenseSlider_EnableScanSlot(uint32 slot)
    {
        uint8 j;
        uint8 snsNumber;
        const uint8 *index;
        /* Read sensor type: single or complex */
        uint8 snsType = CapSenseSlider_portTable[slot];

        /* Check if sensor is complex */
        if ((snsType & CapSenseSlider_COMPLEX_SS_FLAG) == 0u)
        {
            /* Enable sensor (single) */
            CapSenseSlider_EnableSensor(slot);
        }
        else
        {
            /* Enable complex sensor */
            snsType &= ~CapSenseSlider_COMPLEX_SS_FLAG;
            index = &CapSenseSlider_indexTable[snsType];
            snsNumber = CapSenseSlider_maskTable[slot];

            for (j = 0u; j < snsNumber; j++)
            {
                CapSenseSlider_EnableSensor(index[j]);
            }
        }
    }


    /*******************************************************************************
    * Function Name: CapSenseSlider_DisableScanSlot
    ********************************************************************************
    *
    * Summary:
    *  Disables the selected slot. The corresponding pin/pins is/are disconnected
    *  from the Analog Mux Bus and connected to GND, High_Z or Shield electrode.
    *
    * Parameters:
    *  slot:  Slot number.
    *
    * Return:
    *  None
    *
    * Global Variables:
    *  CapSenseSlider_portTable[]  - used to store the port number that pin
    *  belongs to for each sensor.
    *  CapSenseSlider_maskTable[]  - used to store the pin within the port for
    *  each sensor.
    *  CapSenseSlider_indexTable[] - used to store indexes of complex sensors.
    *  The offset and position in this array are stored in a port and mask table for
    *  complex sensors.
    *  7bit(msb) is used to define the sensor type: single or complex.
    *
    * Side Effects:
    *  None
    *
    *******************************************************************************/
    void CapSenseSlider_DisableScanSlot(uint32 slot)
    {
        uint8 j;
        uint8 snsNumber;
        const uint8 *index;

        /* Read sensor type: single or complex */
        uint8 snsType = CapSenseSlider_portTable[slot];

        /* Check if sensor is complex */
        if ((snsType & CapSenseSlider_COMPLEX_SS_FLAG) == 0u)
        {
            /* Disable sensor (single) */
            CapSenseSlider_DisableSensor(slot);
        }
        else
        {
            /* Disable complex sensor */
            snsType &= ~CapSenseSlider_COMPLEX_SS_FLAG;
            index = &CapSenseSlider_indexTable[snsType];
            snsNumber = CapSenseSlider_maskTable[slot];

            for (j=0; j < snsNumber; j++)
            {
                CapSenseSlider_DisableSensor(index[j]);
            }
        }
    }
#endif  /* CapSenseSlider_IS_COMPLEX_SCANSLOTS */


/*******************************************************************************
* Function Name: CapSenseSlider_EnableSensor
********************************************************************************
*
* Summary:
*  Configures the selected sensor to measure during the next measurement cycle.
*  The corresponding pins are set to Analog High-Z mode and connected to the
*  Analog Mux Bus. This also enables the comparator function.
*
* Parameters:
*  sensor:  Sensor number.
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_portTable[] - used to store the port number that pin
*  belongs to for each sensor.
*  CapSenseSlider_pinShiftTbl[] - used to store position of pin that
*  configured as sensor in port.
*  CapSenseSlider_prtSelTbl[] - Contains pointers to the HSIOM
*  registers for each port.
*  CapSenseSlider_PrtCfgTb[] - Contains pointers to the port config
*  registers for each port.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_EnableSensor(uint32 sensor)
{
    uint8  pinModeShift;
    uint8  pinHSIOMShift;
    uint8 interruptState;
    uint32 newRegisterValue;
    uint32 port;

    port = (uint32) CapSenseSlider_portTable[sensor];
    pinModeShift = CapSenseSlider_pinShiftTbl[sensor]  * CapSenseSlider_PC_PIN_CFG_SIZE;
    pinHSIOMShift = CapSenseSlider_pinShiftTbl[sensor] * CapSenseSlider_HSIOM_PIN_CFG_SIZE;

    interruptState = CyEnterCriticalSection();

    newRegisterValue = *CapSenseSlider_prtSelTbl[port];
    newRegisterValue &= ~(CapSenseSlider_CSD_HSIOM_MASK << pinHSIOMShift);
    newRegisterValue |= (uint32)((uint32)CapSenseSlider_CSD_SENSE_PORT_MODE << pinHSIOMShift);

    *CapSenseSlider_prtCfgTbl[port] &= (uint32)~((uint32)CapSenseSlider_CSD_PIN_MODE_MASK << pinModeShift);
    *CapSenseSlider_prtSelTbl[port] = newRegisterValue;

    CyExitCriticalSection(interruptState);
}


/*******************************************************************************
* Function Name: CapSenseSlider_DisableSensor
********************************************************************************
*
* Summary:
*  Disables the selected sensor. The corresponding pin is disconnected from the
*  Analog Mux Bus and connected to GND, High_Z or Shield electrode.
*
* Parameters:
*  sensor:  Sensor number
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_portTable[] - used to store the port number that pin
*  belongs to for each sensor.
*  CapSenseSlider_pinShiftTbl[] - used to store position of pin that
*  configured as a sensor in the port.
*  CapSenseSlider_prtSelTbl[] - Contains pointers to the HSIOM
*  registers for each port.
*  CapSenseSlider_PrtCfgTb[] - Contains pointers to the port config
*  registers for each port.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_DisableSensor(uint32 sensor)
{
    uint8 interruptState;
    uint32 newRegisterValue;

    uint32 port = (uint32) CapSenseSlider_portTable[sensor];
    uint8  pinHSIOMShift = CapSenseSlider_pinShiftTbl[sensor] * CapSenseSlider_HSIOM_PIN_CFG_SIZE;
    uint8  pinModeShift = CapSenseSlider_pinShiftTbl[sensor]  * CapSenseSlider_PC_PIN_CFG_SIZE;

    uint32 inactiveConnect = CapSenseSlider_SNS_HIZANALOG_CONNECT;
    uint32 sensorState = CapSenseSlider_unscannedSnsDriveMode[sensor];

    *CapSenseSlider_prtSelTbl[port] &= ~(CapSenseSlider_CSD_HSIOM_MASK << pinHSIOMShift);

    #if(CapSenseSlider_IS_SHIELD_ENABLE != 0)
    if(sensorState != (uint32)CapSenseSlider__SHIELD)
    {
    #else
        /* Connected to Ground if shield is disabled */
        if(sensorState == (uint32)CapSenseSlider__SHIELD)
        {
            sensorState = (uint32)CapSenseSlider__GROUND;
        }
    #endif /* (CapSenseSlider_IS_SHIELD_ENABLE) */
        if(sensorState != (uint32)CapSenseSlider__HIZ_ANALOG)
        {
            /* Connected to Ground */
            inactiveConnect = (uint32)CapSenseSlider_SNS_GROUND_CONNECT;
        }

        interruptState = CyEnterCriticalSection();

        /* Set drive mode */
        newRegisterValue = *CapSenseSlider_prtCfgTbl[port];
        newRegisterValue &= ~(CapSenseSlider_CSD_PIN_MODE_MASK << pinModeShift);
        newRegisterValue |=  (uint32)(inactiveConnect << pinModeShift);
        *CapSenseSlider_prtCfgTbl[port] =  newRegisterValue;

        CyExitCriticalSection(interruptState);

        *CapSenseSlider_prtDRTbl[port]  &=  (uint32)~(uint32)((uint32)1u << CapSenseSlider_pinShiftTbl[sensor]);
    #if(CapSenseSlider_IS_SHIELD_ENABLE != 0)
    }
    else
    {
        /* Connect to Shield */
        *CapSenseSlider_prtSelTbl[port] |= (CapSenseSlider_CSD_SHIELD_PORT_MODE << pinHSIOMShift);
    }
    #endif /* (CapSenseSlider_IS_SHIELD_ENABLE) */
}


/*******************************************************************************
* Function Name: CapSenseSlider_SetDriveModeAllPins
********************************************************************************
*
* Summary:
* This API sets the drive mode of port pins used by the CapSense
* component (sensors, guard, shield, shield tank and Cmod) to drive the
* mode specified by the argument.
*
* Parameters:
*  driveMode:  Drive mode definition.
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_portTable[] - used to store the port number that pin
*  belongs to for each sensor.
*  CapSenseSlider_pinShiftTbl[] - used to store position of pin that
*  configured as a sensor in the port.
*
* Side Effects:
*  This API shall be called only after CapSense component is stopped.
*
*******************************************************************************/
void CapSenseSlider_SetDriveModeAllPins(uint32 driveMode)
{
    uint8 curSensor;
    #if (CapSenseSlider_IS_COMPLEX_SCANSLOTS)
        uint8 snsNumber;
        uint8 snsType;
    #endif  /* CapSenseSlider_IS_COMPLEX_SCANSLOTS */
    uint32 prtNumberTmp;
    uint32 pinNumberTmp;

    for(curSensor = 0u; curSensor < CapSenseSlider_TOTAL_SENSOR_COUNT; curSensor++)
    {
        #if (CapSenseSlider_IS_COMPLEX_SCANSLOTS)
            /* Read sensor type: single or complex */
            snsType = CapSenseSlider_portTable[curSensor];

            /* Check if sensor is complex */
            if ((snsType & CapSenseSlider_COMPLEX_SS_FLAG) == 0u)
            {
                /* The sensor is not complex */
                snsNumber = curSensor;
            }
            else
            {
                /* Get dedicated sensor ID of the complex sensor */
                snsType &= ~CapSenseSlider_COMPLEX_SS_FLAG;
                snsNumber = CapSenseSlider_indexTable[snsType];
            }

            prtNumberTmp = CapSenseSlider_portTable[snsNumber];
            pinNumberTmp = CapSenseSlider_pinShiftTbl[snsNumber];
        #else
            prtNumberTmp = CapSenseSlider_portTable[curSensor];
            pinNumberTmp = CapSenseSlider_pinShiftTbl[curSensor];
        #endif  /* CapSenseSlider_IS_COMPLEX_SCANSLOTS */

        CapSenseSlider_SetPinDriveMode(driveMode, pinNumberTmp, prtNumberTmp);
    }

    CapSenseSlider_SetPinDriveMode(driveMode, (uint32)CapSenseSlider_CMOD_PIN_NUMBER, (uint32)CapSenseSlider_CMOD_PRT_NUMBER);

    #if(0u != CapSenseSlider_CSH_TANK_ENABLE)
        CapSenseSlider_SetPinDriveMode(driveMode, (uint32)CapSenseSlider_CTANK_PIN_NUMBER, (uint32)CapSenseSlider_CTANK_PRT_NUMBER);
    #endif /* (0u != CapSenseSlider_CSH_TANK_ENABLE) */

    #if(0u != CapSenseSlider_IS_SHIELD_ENABLE)
        CapSenseSlider_SetPinDriveMode(driveMode, (uint32)CapSenseSlider_SHIELD_PIN_NUMBER, (uint32)CapSenseSlider_SHIELD_PORT_NUMBER);
    #endif /* (0u != CapSenseSlider_IS_SHIELD_ENABLE) */
}


/*******************************************************************************
* Function Name: CapSenseSlider_RestoreDriveModeAllPins
********************************************************************************
*
* Summary:
*  This API restores the drive for all the CapSense port pins to the original
*  state.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_prtSelTbl[] - Contains pointers to the HSIOM
*  registers for each port.
*
* Side Effects:
*  This API is called only after the CapSense component is stopped.
*
*******************************************************************************/
void CapSenseSlider_RestoreDriveModeAllPins(void)
{
    uint32 newRegisterValue;

    CapSenseSlider_SetDriveModeAllPins(CY_SYS_PINS_DM_ALG_HIZ);

    newRegisterValue = CapSenseSlider_CMOD_CONNECTION_REG;
    newRegisterValue &= ~(CapSenseSlider_CSD_CMOD_CONNECTION_MASK);
    newRegisterValue |= CapSenseSlider_CSD_CMOD_TO_AMUXBUS_A;
    CapSenseSlider_CMOD_CONNECTION_REG = newRegisterValue;

    #if(0u != CapSenseSlider_CSH_TANK_ENABLE)
        newRegisterValue = CapSenseSlider_CTANK_CONNECTION_REG;
        newRegisterValue &= ~(CapSenseSlider_CSD_CTANK_CONNECTION_MASK);
        newRegisterValue |= CapSenseSlider_CSD_CTANK_TO_AMUXBUS_B;
        CapSenseSlider_CTANK_CONNECTION_REG = newRegisterValue;
    #endif/* (0u != CapSenseSlider_CSH_TANK_ENABLE) */

    #if(0u != CapSenseSlider_IS_SHIELD_ENABLE)
        newRegisterValue = *CapSenseSlider_prtSelTbl[CapSenseSlider_SHIELD_PORT_NUMBER];
        newRegisterValue &= ~(CapSenseSlider_CSD_HSIOM_MASK << ((uint32)CapSenseSlider_SHIELD_PIN_NUMBER * CapSenseSlider_HSIOM_PIN_CFG_SIZE));
        newRegisterValue |= (CapSenseSlider_CSD_SHIELD_PORT_MODE << ((uint32)CapSenseSlider_SHIELD_PIN_NUMBER * CapSenseSlider_HSIOM_PIN_CFG_SIZE));
        *CapSenseSlider_prtSelTbl[CapSenseSlider_SHIELD_PORT_NUMBER] = newRegisterValue;
    #endif /* (0u != CapSenseSlider_IS_SHIELD_ENABLE) */
}


/*******************************************************************************
* Function Name: CapSenseSlider_SetPinDriveMode
********************************************************************************
*
* Summary:
* This API sets the drive mode for the appropriate port/pin.
*
* Parameters:
*  driveMode:  Drive mode definition.
*  portNumber: contains port number (0, 1, 2).
*  pinNumber: contains pin number (0, 1, 2, ... , 7).
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_prtSelTbl[] - Contains pointers to the HSIOM
*  registers for each port.
*  CapSenseSlider_prtCfgTb[] - Contains pointers to the port config
*  registers for each port.
*
* Side Effects:
*  This API is called only after CapSense component is stopped.
*
*******************************************************************************/
void CapSenseSlider_SetPinDriveMode(uint32 driveMode, uint32 pinNumber, uint32 portNumber)
{
    uint32  pinModeShift;
    uint32 newRegisterValue;

    pinModeShift  = pinNumber * CapSenseSlider_PC_PIN_CFG_SIZE;

    newRegisterValue = *CapSenseSlider_prtCfgTbl[portNumber];
    newRegisterValue &= ~(CapSenseSlider_CSD_PIN_MODE_MASK << pinModeShift);
    newRegisterValue |=  (uint32)((uint32)driveMode << pinModeShift);
    *CapSenseSlider_prtCfgTbl[portNumber] =  newRegisterValue;
}


/*******************************************************************************
* Function Name: CapSenseSlider_PreScan
********************************************************************************
*
* Summary:
*  Sets required settings, enables a sensor, removes Vref from AMUX and starts the
*  scanning process of the sensor.
*
* Parameters:
*  sensor:  Sensor number.
*
* Return:
*  None
*
* Global Variables:
* CapSenseSlider_widgetNumber[] - This array contains numbers of widgets for each sensor.
* CapSenseSlider_widgetResolution[] - Contains the widget resolution.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_PreScan(uint32 sensor)
{
    uint8 widget;
    uint8 interruptState;
    uint32 newRegValue;
    uint32 counterResolution;

    #if(CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_AUTO)
        uint8 senseClkDivMath;
        uint8 sampleClkDivMath;
    #endif /* (CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_AUTO) */

    #if ((CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) &&\
         (0 != CapSenseSlider_IS_OVERSAMPLING_EN))
        uint32 oversamplingFactor;
    #endif /* ((CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) &&\
               (0 != CapSenseSlider_IS_OVERSAMPLING_EN)) */

    /* Define widget sensor belongs to */
    widget = CapSenseSlider_widgetNumber[sensor];

    /* Recalculate Counter Resolution to MSB 16 bits */
    counterResolution = CapSenseSlider_widgetResolution[widget];

    #if ((CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) &&\
         (0 != CapSenseSlider_IS_OVERSAMPLING_EN))
        oversamplingFactor = CapSenseSlider_GetBitValue(CapSenseSlider_scanSpeedTbl, sensor);

        if(counterResolution < CapSenseSlider_RESOLUTION_16_BITS)
        {
            counterResolution <<= oversamplingFactor;
            counterResolution |= (uint32)(CapSenseSlider_RESOLUTION_8_BITS);
        }
    #endif /* ((CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) &&\
               (0 != CapSenseSlider_IS_OVERSAMPLING_EN)) */

    #if (0u != CapSenseSlider_IS_M0S8PERI_BLOCK)
        CapSenseSlider_SenseClk_Stop();
        CapSenseSlider_SampleClk_Stop();
    #endif /* (0u != CapSenseSlider_IS_M0S8PERI_BLOCK) */

    #if (0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET)
        CapSenseSlider_SampleClk_SetDividerValue((uint16)CapSenseSlider_sampleClkDividerVal[sensor]);
        CapSenseSlider_SenseClk_SetDividerValue((uint16)CapSenseSlider_senseClkDividerVal[sensor]);
    #else
        CapSenseSlider_SampleClk_SetDividerValue((uint16)CapSenseSlider_sampleClkDividerVal);
        CapSenseSlider_SenseClk_SetDividerValue((uint16)CapSenseSlider_senseClkDividerVal);
    #endif /* (0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET) */

    #if (0u != CapSenseSlider_IS_M0S8PERI_BLOCK)
        CapSenseSlider_SampleClk_Start();
        CapSenseSlider_SenseClk_StartEx(CapSenseSlider_SampleClk__DIV_ID);

        #if(CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_NONE)
            CyIntDisable(CapSenseSlider_ISR_NUMBER);
            CapSenseSlider_CSD_CNT_REG = CapSenseSlider_ONE_CYCLE;
            while(0u != (CapSenseSlider_CSD_CNT_REG & CapSenseSlider_RESOLUTION_16_BITS))
            {
            /* Wait until scanning is complete */
            }
            CapSenseSlider_CSD_INTR_REG = 1u;
            CyIntClearPending(CapSenseSlider_ISR_NUMBER);
            CyIntEnable(CapSenseSlider_ISR_NUMBER);
        #endif /* CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_NONE */
    #endif /* (0u != CapSenseSlider_IS_M0S8PERI_BLOCK) */

#if(CapSenseSlider_PRS_OPTIONS != CapSenseSlider__PRS_NONE)

    #if(CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO)
        if(CapSenseSlider_prescalersTuningDone != 0u)
        {
    #endif /* (CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) */

            CyIntDisable(CapSenseSlider_ISR_NUMBER);

            newRegValue = CapSenseSlider_CSD_CFG_REG;
            newRegValue |= CapSenseSlider_CSD_CFG_PRS_SELECT;

            #if(CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_AUTO)

                newRegValue &= ~(CapSenseSlider_PRS_MODE_MASK);

                #if (0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET)
                    senseClkDivMath = CapSenseSlider_senseClkDividerVal[sensor];
                    sampleClkDivMath = CapSenseSlider_sampleClkDividerVal[sensor];
                #else
                    senseClkDivMath = CapSenseSlider_senseClkDividerVal;
                    sampleClkDivMath = CapSenseSlider_sampleClkDividerVal;
                #endif /* ( CapSenseSlider_MULTIPLE_FREQUENCY_SET) */

                #if(0u == CapSenseSlider_IS_M0S8PERI_BLOCK)
                    senseClkDivMath *= sampleClkDivMath;
                #endif /* (0u == CapSenseSlider_IS_M0S8PERI_BLOCK) */

                if((senseClkDivMath * CapSenseSlider_RESOLUTION_12_BITS) <
                   (sampleClkDivMath * CapSenseSlider_widgetResolution[widget]))
                {
                    newRegValue |= CapSenseSlider_CSD_PRS_12_BIT;
                }
            #endif /* (CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_AUTO) */

            CapSenseSlider_CSD_CFG_REG = newRegValue;

            CyIntEnable(CapSenseSlider_ISR_NUMBER);

    #if(CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO)
        }
    #endif /* (CapSenseSlider_PRS_OPTIONS != CapSenseSlider__PRS_NONE) */

#endif /* (CapSenseSlider_PRS_OPTIONS == CapSenseSlider__PRS_NONE) */

    /* Set Idac Value */
    CyIntDisable(CapSenseSlider_ISR_NUMBER);
    newRegValue = CapSenseSlider_CSD_IDAC_REG;

#if (CapSenseSlider_IDAC_CNT == 1u)
    newRegValue &= ~(CapSenseSlider_CSD_IDAC1_DATA_MASK);
    newRegValue |= CapSenseSlider_modulationIDAC[sensor];
#else
    newRegValue &= ~(CapSenseSlider_CSD_IDAC1_DATA_MASK | CapSenseSlider_CSD_IDAC2_DATA_MASK);
    newRegValue |= (CapSenseSlider_modulationIDAC[sensor] |
                            (uint32)((uint32)CapSenseSlider_compensationIDAC[sensor] <<
                            CapSenseSlider_CSD_IDAC2_DATA_OFFSET));
#endif /* (CapSenseSlider_IDAC_CNT == 1u) */

    CapSenseSlider_CSD_IDAC_REG = newRegValue;

#if(CapSenseSlider_CMOD_PREGARGE_OPTION == CapSenseSlider__CAPPRIOBUF)
    newRegValue = CapSenseSlider_CMOD_CONNECTION_REG;
    newRegValue &= ~(CapSenseSlider_CSD_CMOD_CONNECTION_MASK);
    newRegValue |= CapSenseSlider_CSD_CMOD_TO_AMUXBUS_A;
    CapSenseSlider_CMOD_CONNECTION_REG = newRegValue;

    newRegValue = CapSenseSlider_CMOD_PORT_PC_REG;
    newRegValue &= ~(CapSenseSlider_CSD_CMOD_PC_MASK);
    newRegValue |= CapSenseSlider_CMOD_PC_HIGH_Z_MODE;
    CapSenseSlider_CMOD_PORT_PC_REG = newRegValue;
#endif /* (CapSenseSlider_CMOD_PREGARGE_OPTION == CapSenseSlider__CAPPRIOBUF) */

    /* Disconnect Vref Buffer from AMUX */
    newRegValue = CapSenseSlider_CSD_CFG_REG;
    newRegValue &= ~(CapSenseSlider_PRECHARGE_CONFIG_MASK);
    newRegValue |= CapSenseSlider_CTANK_PRECHARGE_CONFIG;

    CyIntEnable(CapSenseSlider_ISR_NUMBER);

    /* Enable Sensor */
    CapSenseSlider_EnableScanSlot(sensor);

    interruptState = CyEnterCriticalSection();
    CapSenseSlider_CSD_CFG_REG = newRegValue;

    /* `#START CapSenseSlider_PreSettlingDelay_Debug` */

    /* `#END` */

#ifdef CapSenseSlider_PRE_SCAN_PRE_SETTLING_DELAY_DEBUG_CALLBACK
    CapSenseSlider_PreScan_Pre_SettlingDelay_Debug_Callback();
#endif /* CapSenseSlider_PRE_SCAN_PRE_SETTLING_DELAY_DEBUG_CALLBACK */

    CyDelayCycles(CapSenseSlider_GLITCH_ELIMINATION_CYCLES);

    /* `#START CapSenseSlider_PreScan_Debug` */

    /* `#END` */

#ifdef CapSenseSlider_PRE_SCAN_DEBUG_CALLBACK
    CapSenseSlider_PreScan_Debug_Callback();
#endif /* CapSenseSlider_PRE_SCAN_DEBUG_CALLBACK */

    CapSenseSlider_CSD_CNT_REG = counterResolution;
    CyExitCriticalSection(interruptState);
}


/*******************************************************************************
* Function Name: CapSenseSlider_PostScan
********************************************************************************
*
* Summary:
*  Stores the results of measurement in the CapSenseSlider_sensorRaw[] array,
*  sets the scanning sensor in the non-sampling state, turns off Idac(Current Source IDAC),
*  disconnects the IDAC(Sink mode), and applies Vref on AMUX.
*
* Parameters:
*  sensor:  Sensor number.
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_sensorRaw[] - used to store sensors raw data.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_PostScan(uint32 sensor)
{
    uint32 newRegValue;
#if ((CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) &&\
     (0 != CapSenseSlider_IS_OVERSAMPLING_EN))
    uint32 oversamplingFactor;
    uint32 widget;
#endif /* ((CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) &&\
           (0 != CapSenseSlider_IS_OVERSAMPLING_EN)) */

    /* `#START CapSenseSlider_PostScan_Debug` */

    /* `#END` */

#ifdef CapSenseSlider_POST_SCAN_DEBUG_CALLBACK
    CapSenseSlider_PostScan_Debug_Callback();
#endif /* CapSenseSlider_POST_SCAN_DEBUG_Callback */

    /* Read SlotResult from Raw Counter */
    CapSenseSlider_sensorRaw[sensor]  = (uint16)CapSenseSlider_CSD_CNT_REG;

#if ((CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) &&\
     (0 != CapSenseSlider_IS_OVERSAMPLING_EN))
    widget = CapSenseSlider_widgetNumber[sensor];
    if(CapSenseSlider_widgetResolution[widget] < CapSenseSlider_RESOLUTION_16_BITS)
    {
        oversamplingFactor = CapSenseSlider_GetBitValue(CapSenseSlider_scanSpeedTbl, sensor);
        CapSenseSlider_sensorRaw[sensor] >>= oversamplingFactor;
    }
#endif /* ((CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO) &&\
           (0 != CapSenseSlider_IS_OVERSAMPLING_EN)) */

    /* Disable Sensor */
    CapSenseSlider_DisableScanSlot(sensor);

    CyIntDisable(CapSenseSlider_ISR_NUMBER);

#if(CapSenseSlider_CMOD_PREGARGE_OPTION == CapSenseSlider__CAPPRIOBUF)
    newRegValue = CapSenseSlider_CMOD_CONNECTION_REG;
    newRegValue &= ~(CapSenseSlider_CSD_CMOD_CONNECTION_MASK);
    newRegValue |= CapSenseSlider_CSD_CMOD_TO_AMUXBUS_B;
    CapSenseSlider_CMOD_CONNECTION_REG = newRegValue;

    newRegValue = CapSenseSlider_CMOD_PORT_PC_REG;
    newRegValue &= ~(CapSenseSlider_CSD_CMOD_PC_MASK);
    newRegValue |= CapSenseSlider_CMOD_PC_STRONG_MODE;
    CapSenseSlider_CMOD_PORT_PC_REG = newRegValue;

    newRegValue = CapSenseSlider_CMOD_PORT_DR_REG;
    newRegValue &= ~(CapSenseSlider_CMOD_DR_MASK);
    newRegValue |= CapSenseSlider_CMOD_DR_CONFIG;
    CapSenseSlider_CMOD_PORT_DR_REG = newRegValue;
#endif /* (CapSenseSlider_CMOD_PREGARGE_OPTION == CapSenseSlider__CAPPRIOBUF) */

    /* Connect Vref Buffer to AMUX bus  */
    newRegValue = CapSenseSlider_CSD_CFG_REG;
    newRegValue &= ~(CapSenseSlider_PRECHARGE_CONFIG_MASK);
    newRegValue |= CapSenseSlider_CMOD_PRECHARGE_CONFIG;
    CapSenseSlider_CSD_CFG_REG = newRegValue;

    /* Set Idac Value = 0 */
#if (CapSenseSlider_IDAC_CNT == 1u)
    CapSenseSlider_CSD_IDAC_REG &= ~(CapSenseSlider_CSD_IDAC1_DATA_MASK);
#else
    CapSenseSlider_CSD_IDAC_REG &= ~(CapSenseSlider_CSD_IDAC1_DATA_MASK | CapSenseSlider_CSD_IDAC2_DATA_MASK);
#endif /* (CapSenseSlider_IDAC_CNT == 1u) */

    CyIntEnable(CapSenseSlider_ISR_NUMBER);
}


/*******************************************************************************
* Function Name: CapSenseSlider_EnableShieldElectrode
********************************************************************************
*
* Summary:
*  This API enables or disables the shield electrode on a specified port pin.
*
* Parameters:
*  portNumber: contains the shield electrode port number (0, 1, 2).
*  pinNumber: contains the shield electrode pin number (0, 1, 2, ... , 7).
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_prtCfgTbl[] - Contains pointers to the port config registers for each port.
*  CapSenseSlider_prtSelTbl[] - Contains pointers to the HSIOM registers for each port.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_EnableShieldElectrode(uint32 pinNumber, uint32 portNumber)
{
    uint32 newRegValue;

    *CapSenseSlider_prtCfgTbl[portNumber] &= ~(CapSenseSlider_CSD_PIN_MODE_MASK << (pinNumber * CapSenseSlider_PC_PIN_CFG_SIZE));
    newRegValue = *CapSenseSlider_prtSelTbl[portNumber];
    newRegValue &= ~(CapSenseSlider_CSD_HSIOM_MASK << (pinNumber * CapSenseSlider_HSIOM_PIN_CFG_SIZE));
    newRegValue |= (CapSenseSlider_CSD_SHIELD_PORT_MODE << (pinNumber * CapSenseSlider_HSIOM_PIN_CFG_SIZE));
    *CapSenseSlider_prtSelTbl[portNumber] = newRegValue;
}


/*******************************************************************************
* Function Name: CapSenseSlider_SetShieldDelay
********************************************************************************
*
* Summary:
*  This API sets a shield delay.
*
* Parameters:
*  delay:  shield delay value:
*                               0 - no delay
*                               1 - 1 cycle delay
*                               2 - 2 cycles delay
*
* Return:
*  None
*
* Global Variables:
*  None
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_SetShieldDelay(uint32 delay)
{
    uint32 newRegValue;

    delay &= 0x03u;

    newRegValue = CapSenseSlider_CSD_CFG_REG;
    newRegValue &= (uint32)(~(uint32)CapSenseSlider_SHIELD_DELAY);
    newRegValue |= (delay << CapSenseSlider_CSD_CFG_SHIELD_DELAY_POS);
    CapSenseSlider_CSD_CFG_REG = newRegValue;
}


/*******************************************************************************
* Function Name: CapSenseSlider_ReadCurrentScanningSensor
********************************************************************************
*
* Summary:
*  This API returns scanning sensor number when sensor scan is in progress.
*  When sensor scan is completed the API returns
*  $INSTANCE_NAME`_NOT_SENSOR (0xFFFFFFFF) (when no sensor is scanned).
*
* Parameters:
*   None.
*
* Return:
*  Returns Sensor number if sensor is being scanned and
*  $INSTANCE_NAME`_NOT_SENSOR (0xFFFFFFFF) if scanning is complete.
*
* Global Variables:
*  CapSenseSlider_sensorIndex - the sensor number is being scanned.
*
* Side Effects:
*  None
*
*******************************************************************************/
uint32 CapSenseSlider_ReadCurrentScanningSensor(void)
{
    return ((uint32)(( 0u != (CapSenseSlider_csdStatusVar & CapSenseSlider_SW_STS_BUSY)) ?
                     CapSenseSlider_sensorIndex : CapSenseSlider_NOT_SENSOR));
}


/*******************************************************************************
* Function Name: CapSenseSlider_GetBitValue
********************************************************************************
*
* Summary:
*  The API returns a bit status of the bit in the table array which contains the masks.
*
* Parameters:
*  table[] - array with bit masks.
*  position - position of bit in the table[] array.
*
* Return:
*  0 - bit is not set; 1 - bit is set.
*
* Global Variables:
*  None
*
* Side Effects:
*  None
*
*******************************************************************************/
uint32 CapSenseSlider_GetBitValue(const uint8 table[], uint32 position)
{
    uint32 offset;
    uint8 enMask;

    /* position is divided by 8 to calculate the element of the
       table[] array that contains the enable bit
       for an appropriate sensor.
    */
    offset = (position >> 3u);

    /* The enMask calculation for the appropriate sensor. Operation (position & 0x07u)
       intends to calculate the enable bit offset for the 8-bit element of the
       table[] array.
    */
    enMask = 0x01u << (position & 0x07u);

    return ((0u !=(table[offset] & enMask)) ? 1Lu : 0Lu);
}


/*******************************************************************************
* Function Name: CapSenseSlider_SetBitValue
********************************************************************************
*
* Summary:
*  The API sets a bit status of the bit in the table array which contains masks.
*
* Parameters:
*  table[] - array with bit masks.
*  position - position of bit in the table[] array.
*  value: 0 - bit is not set; 1 - bit is set.
*
* Return:
*  None
*
* Global Variables:
*  None
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_SetBitValue(uint8 table[], uint32 position, uint32 value)
{
    uint32 offset;
    uint8 enMask;

    /* position is divided by 8 to calculate the element of the
       table[] array that contains the enable bit
       for an appropriate sensor.
    */
    offset = (position >> 3u);

    /* The enMask calculation for the appropriate sensor. Operation (position & 0x07u)
       intends to calculate the enable bit offset for the 8-bit element of the
       table[] array.
    */
    enMask = 0x01u << (position & 0x07u);

    if(0u != value)
    {
        table[offset] |= enMask;
    }
    else
    {
        table[offset] &= (uint8)~(enMask);
    }
}



/*******************************************************************************
* Function Name: CapSenseSlider_GetSenseClkDivider
********************************************************************************
*
* Summary:
*  This API returns a value of the sense clock divider for the  sensor.
*
* Parameters:
*  sensor: sensor index. The index value can be
*  from 0 to (CapSenseSlider_TOTAL_SENSOR_COUNT-1).
*
* Return:
*  This API returns the sense clock divider of the sensor.
*
* Global Variables:
*  CapSenseSlider_senseClkDividerVal[] - stores the sense clock divider values.
*
* Side Effects:
*  None
*
*******************************************************************************/
uint32 CapSenseSlider_GetSenseClkDivider(uint32 sensor)
{
    #if(0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET)
        return((uint32)CapSenseSlider_senseClkDividerVal[sensor]);
    #else
        return((uint32)CapSenseSlider_senseClkDividerVal);
    #endif /* (0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET) */
}

#if (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE)
    /*******************************************************************************
    * Function Name: CapSenseSlider_SetSenseClkDivider
    ********************************************************************************
    *
    * Summary:
    *  This API sets a value of the sense clock divider for the  sensor.
    *
    * Parameters:
    *  sensor:  Sensor index.
    *  senseClk: represents the sense clock value.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  CapSenseSlider_senseClkDividerVal[] - stores the sense clock divider values.
    *
    * Side Effects:
    *  None
    *
    *******************************************************************************/
    void CapSenseSlider_SetSenseClkDivider(uint32 sensor, uint32 senseClk)
    {
        #if(0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET)
            CapSenseSlider_senseClkDividerVal[sensor] = (uint8)senseClk;
        #else
            CapSenseSlider_senseClkDividerVal = (uint8)senseClk;
        #endif /* (0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET) */
    }
#endif /* (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) */


/*******************************************************************************
* Function Name: CapSenseSlider_GetModulatorClkDivider
********************************************************************************
*
* Summary:
*  This API returns a value of the modulator sample clock divider for the  sensor.
*
* Parameters:
*  sensor: sensor index. The value of index can be
*  from 0 to (CapSenseSlider_TOTAL_SENSOR_COUNT-1).
*
* Return:
*  This API returns the modulator sample clock divider for the  sensor.
*
* Global Variables:
*  CapSenseSlider_sampleClkDividerVal[] - stores the modulator sample divider values.
*
* Side Effects:
*  None
*
*******************************************************************************/
uint32 CapSenseSlider_GetModulatorClkDivider(uint32 sensor)
{
    #if(0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET)
        return((uint32)CapSenseSlider_sampleClkDividerVal[sensor]);
    #else
        return((uint32)CapSenseSlider_sampleClkDividerVal);
    #endif /* (0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET) */
}

#if (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE)
    /*******************************************************************************
    * Function Name: CapSenseSlider_SetModulatorClkDivider
    ********************************************************************************
    *
    * Summary:
    *  This API sets a value of the modulator sample clock divider for the  sensor.
    *
    * Parameters:
    *  sensor:  Sensor index.
    *  modulatorClk: represents the modulator sample clock value.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  CapSenseSlider_sampleClkDividerVal[] - stores the modulator sample divider values.
    *
    * Side Effects:
    *  None
    *
    *******************************************************************************/
    void CapSenseSlider_SetModulatorClkDivider(uint32 sensor, uint32 modulatorClk)
    {
        #if(0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET)
            CapSenseSlider_sampleClkDividerVal[sensor] = (uint8)modulatorClk;
        #else
            CapSenseSlider_sampleClkDividerVal = (uint8)modulatorClk;
        #endif /* (0u != CapSenseSlider_MULTIPLE_FREQUENCY_SET) */
    }
#endif /* (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) */

/*******************************************************************************
* Function Name: CapSenseSlider_GetModulationIDAC
********************************************************************************
*
* Summary:
*  This API returns a value of the modulation IDAC for the  sensor.
*
* Parameters:
*  sensor: sensor index. The index value can be
*  from 0 to (CapSenseSlider_TOTAL_SENSOR_COUNT-1).
*
* Return:
*  This API returns the modulation IDAC of the sensor.
*
* Global Variables:
*  CapSenseSlider_modulationIDAC[] - stores modulation IDAC values.
*
* Side Effects:
*  None
*
*******************************************************************************/
uint32 CapSenseSlider_GetModulationIDAC(uint32 sensor)
{
        return((uint32)CapSenseSlider_modulationIDAC[sensor]);
}

#if (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE)
    /*******************************************************************************
    * Function Name: CapSenseSlider_SetModulationIDAC
    ********************************************************************************
    *
    * Summary:
    *  This API sets a value of the modulation IDAC for the  sensor.
    *
    * Parameters:
    *  sensor:  Sensor index.
    *  compIdacValue: represents the modulation IDAC data register value.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  CapSenseSlider_modulationIDAC[] - array with modulation IDAC values
    *
    * Side Effects:
    *  None
    *
    *******************************************************************************/
    void CapSenseSlider_SetModulationIDAC(uint32 sensor, uint32 modIdacValue)
    {
        CapSenseSlider_modulationIDAC[sensor] = (uint8)modIdacValue;
    }
#endif /* (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) */


#if(CapSenseSlider_IDAC_CNT > 1u)
    /*******************************************************************************
    * Function Name: CapSenseSlider_GetCompensationIDAC
    ********************************************************************************
    *
    * Summary:
    *  This API returns a value of the compensation IDAC for the  sensor.
    *
    * Parameters:
    *  sensor: sensor index. The index value can be
    *  from 0 to (CapSenseSlider_TOTAL_SENSOR_COUNT-1).
    *
    * Return:
    *  This API returns the compensation IDAC of the sensor.
    *
    * Global Variables:
    *  CapSenseSlider_compensationIDAC[] - stores the compensation IDAC values.
    *
    * Side Effects:
    *  None
    *
    *******************************************************************************/
    uint32 CapSenseSlider_GetCompensationIDAC(uint32 sensor)
    {
        return((uint32)CapSenseSlider_compensationIDAC[sensor]);
    }
#endif /* (CapSenseSlider_IDAC_CNT > 1u) */


#if((CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) && (CapSenseSlider_IDAC_CNT > 1u))
    /*******************************************************************************
    * Function Name: CapSenseSlider_SetCompensationIDAC
    ********************************************************************************
    *
    * Summary:
    *  This API sets a value of compensation IDAC for the  sensor.
    *
    * Parameters:
    *  sensor:  Sensor index.
    *  compIdacValue: represents the compensation IDAC data register value.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  CapSenseSlider_compensationIDAC[] - an array with compensation IDAC values
    *
    * Side Effects:
    *  None
    *
    *******************************************************************************/
    void CapSenseSlider_SetCompensationIDAC(uint32 sensor, uint32 compIdacValue)
    {
        CapSenseSlider_compensationIDAC[sensor] = (uint8)compIdacValue;
    }
#endif /* ((CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) && (CapSenseSlider_IDAC_CNT > 1u)) */

/*******************************************************************************
* Function Name: CapSenseSlider_GetIDACRange
********************************************************************************
*
* Summary:
*  This API returns a value that indicates the IDAC range used by the
*  component to scan sensors. The IDAC range is common for all the sensors.
*
* Parameters:
*  None
*
* Return:
*  This API Returns a value that indicates the IDAC range:
*      0 - IDAC range set to 4x
*      1 - IDAC range set to 8x
*
* Global Variables:
*  None
*
* Side Effects:
*  None
*
*******************************************************************************/
uint32 CapSenseSlider_GetIDACRange(void)
{
    return((0u != (CapSenseSlider_CSD_IDAC_REG & CapSenseSlider_CSD_IDAC1_RANGE_8X)) ? 1uL : 0uL);
}

#if (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE)
    /*******************************************************************************
    * Function Name: CapSenseSlider_SetIDACRange
    ********************************************************************************
    *
    * Summary:
    *  This API sets the IDAC range to the 4x (1.2uA/bit) or 8x (2.4uA/bit) mode.
    *  The IDAC range is common for all the sensors and common for the modulation and
    *  compensation IDACs.
    *
    * Parameters:
    *  iDacRange:  represents value for IDAC range
    *  0 -  IDAC range set to 4x (1.2uA/bit)
    *  1 or >1 - IDAC range set to 8x (2.4uA/bit)
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  None
    *
    * Side Effects:
    *  None
    *
    *******************************************************************************/
    void CapSenseSlider_SetIDACRange(uint32 iDacRange)
    {
        if(iDacRange != 0u)
        {
            /*  IDAC range = 8x (2.4uA/bit) */
            CapSenseSlider_CSD_IDAC_REG |= (CapSenseSlider_CSD_IDAC1_RANGE_8X |\
                                              CapSenseSlider_CSD_IDAC2_RANGE_8X);
        }
        else
        {
            /*  IDAC range = 4x (1.2uA/bit) */
            /*  IDAC range = 8x (2.4uA/bit) */
            CapSenseSlider_CSD_IDAC_REG &= ~(CapSenseSlider_CSD_IDAC1_RANGE_8X |\
                                               CapSenseSlider_CSD_IDAC2_RANGE_8X);
        }
    }
#endif /* (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_NONE) */


#if((0u != CapSenseSlider_AUTOCALIBRATION_ENABLE) || (CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO))
    /*******************************************************************************
    * Function Name: CapSenseSlider_GetSensorRaw
    ********************************************************************************
    *
    * Summary:
    *  The API updates and gets uprated raw data from the sensor.
    *
    * Parameters:
    *  sensor - Sensor number.
    *
    * Return:
    *  Returns the current raw data value for a defined sensor number.
    *
    * Global Variables:
    *  None
    *
    * Side Effects:
    *  None
    *
    *******************************************************************************/
    uint16  CapSenseSlider_GetSensorRaw(uint32 sensor)
    {
        uint32 curSample;
        uint32 avgVal = 0u;

        for(curSample = 0u; curSample < CapSenseSlider_AVG_SAMPLES_NUM; curSample++)
        {

            CapSenseSlider_ScanSensor((uint32)sensor);
            while(CapSenseSlider_IsBusy() == 1u)
            {
                /* Wait while sensor is busy */
            }
            avgVal += CapSenseSlider_ReadSensorRaw((uint32)sensor);
        }

        return((uint16)(avgVal / CapSenseSlider_AVG_SAMPLES_NUM));
    }
#endif /* ((0u != CapSenseSlider_AUTOCALIBRATION_ENABLE) && (CapSenseSlider_TUNING_METHOD == CapSenseSlider__TUNING_AUTO)) */


#if((0u != CapSenseSlider_AUTOCALIBRATION_ENABLE) && (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_AUTO))
    /*******************************************************************************
    * Function Name: CapSenseSlider_CalibrateSensor
    ********************************************************************************
    *
    * Summary:
    *  Computes the one sensor IDAC value, which provides the raw signal on
    *  a specified level, with a specified prescaler, speed, and resolution.
    *
    * Parameters:
    *  sensor - Sensor Number.
    *
    *  rawLevel -  Raw data level which should be reached during the calibration
    *              procedure.
    *
    *  idacLevelsTbl - Pointer to the modulatorIdac data register configuration table.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void CapSenseSlider_CalibrateSensor(uint32 sensor, uint32 rawLevel, uint8 idacLevelsTbl[])
    {
        uint8 mask;
        uint16 rawData;

        rawData = 0u;

        mask = 0x80u;
        /* Init IDAC for null Channel */
        idacLevelsTbl[sensor] = 0x00u;

        do
        {
            /* Set bit for null Channel */
            idacLevelsTbl[sensor] |= mask;

            /* Scan null Channel and get Rawdata */
            rawData = CapSenseSlider_GetSensorRaw(sensor);

            /* Decrease IDAC until Rawdata reaches rawLevel */
            if(rawData < rawLevel)
            {
                /* Reset bit for null Channel  */
                idacLevelsTbl[sensor] &= (uint8)~mask;
            }

            mask >>= 1u;
        }
        while(mask > 0u);

    }
#endif /* ((0u != CapSenseSlider_AUTOCALIBRATION_ENABLE) && (CapSenseSlider_TUNING_METHOD != CapSenseSlider__TUNING_AUTO)) */


/*******************************************************************************
* Function Name: CapSenseSlider_SetUnscannedSensorState
********************************************************************************
*
* Summary:
*  This API sets a state for un-scanned sensors.
*  It is possible to set the state to Ground, High-Z, or the shield electrode.
*  The un-scanned sensor can be connected to a shield electrode only if the shield is
*  enabled. If the shield is disabled and this API is called with the parameter which
*  indicates the shield state, the un-scanned sensor will be connected to Ground.
*
* Parameters:
*  sensor - Sensor Number.
*  sensorState: This parameter indicates un-scanned sensor state:
*
*     CapSenseSlider__GROUND 0
*     CapSenseSlider__HIZ_ANALOG 1
*     CapSenseSlider__SHIELD 2
*
* Return:
*  None.
*
* Global Variables:
*  CapSenseSlider_unscannedSnsDriveMode[] - used to store the state for
*  un-scanned sensors.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_SetUnscannedSensorState(uint32 sensor, uint32 sensorState)
{
    #if(CapSenseSlider_IS_COMPLEX_SCANSLOTS)
        uint8 snsType;
        uint8 curSensor;
        uint16 snsNumber;

        /* Read sensor type: single or complex */
        snsType = CapSenseSlider_portTable[sensor];

        /* Check if sensor is complex */
        if(0u != (snsType & CapSenseSlider_COMPLEX_SS_FLAG))
        {
            snsType &= (uint8)~CapSenseSlider_COMPLEX_SS_FLAG;
            snsNumber = (uint16)CapSenseSlider_maskTable[sensor];

            for (curSensor=0u; curSensor < snsNumber; curSensor++)
            {
                sensor = CapSenseSlider_indexTable[snsType + curSensor];
                CapSenseSlider_unscannedSnsDriveMode[sensor] = (uint8)sensorState;
            }
        }
        else
        {
            CapSenseSlider_unscannedSnsDriveMode[sensor] = (uint8)sensorState;
        }
    #else
        CapSenseSlider_unscannedSnsDriveMode[sensor] = (uint8)sensorState;
    #endif /* (CapSenseSlider_IS_COMPLEX_SCANSLOTS) */
}

#if(0u != CapSenseSlider_TOTAL_CENTROIDS_COUNT)
/*******************************************************************************
* Function Name: CapSenseSlider_NormalizeWidgets
********************************************************************************
*
* Summary:
*  This API aligns all the parameters of the widget to the maximum parameter.
*
* Parameters:
*  uint32 widgetsNum: Number of widgets.
*  uint8 *dataPrt: pointer to array with widget parameters.
*
* Return:
*  None
*
* Global Variables:
*  CapSenseSlider_numberOfSensors[] - Number of sensors in the widget.
*  CapSenseSlider_rawDataIndex[currentWidget] - Contains the  1st sensor
*  position in the widget.
*
* Side Effects:
*  None
*
*******************************************************************************/
void CapSenseSlider_NormalizeWidgets(uint32 widgetsNum, uint8 dataPtr[])
{
    uint32 currentWidget;
    uint32 currentSensor;
    uint32 lastSensor;
    uint32 sensorsPerWidget;
    uint32 maxPerWidget;

    for(currentWidget = 0u; currentWidget < widgetsNum; currentWidget++)
    {
        maxPerWidget = 0u;

        sensorsPerWidget = CapSenseSlider_numberOfSensors[currentWidget];
        currentSensor = CapSenseSlider_rawDataIndex[currentWidget];
        lastSensor = currentSensor + sensorsPerWidget;

        while(currentSensor < lastSensor)
        {
            if(maxPerWidget < dataPtr[currentSensor])
            {
                maxPerWidget = dataPtr[currentSensor];
            }
            currentSensor++;
        }

        currentSensor = CapSenseSlider_rawDataIndex[currentWidget];

        while(currentSensor < lastSensor)
        {
            dataPtr[currentSensor] = (uint8)maxPerWidget;
            currentSensor++;
        }
    }
}
#endif /* (0u != CapSenseSlider_TOTAL_CENTROIDS_COUNT) */

/* [] END OF FILE */
