/* ========================================
 *
 * MCP23017 header file
 * 04.2016 by Piotr Zapart 
 * www.hexeguitar.com
 *
 * ========================================
*/
#ifndef _MCP23017_H_
#define _MCP23017_H_
    
    #include<cytypes.h>
    // I2C result status
    #define TRANSFER_CMPLT    (0x00u)
    #define TRANSFER_ERROR    (0xFFu)
    
    #define MCP23017_SLAVE_ADDR 0x40
    #define MCP23017_I2C_WRITE  0x00
    #define MCP23017_I2C_READ   0x01
    
    // ### Registers, IOCON.BANK = 0 ###
    #define MCP23017_IODIRA     0x00    //IO Direction register, 
    #define MCP23017_IODIRB     0x01    //1=input, 0=output
    
    #define MCP23017_IPOLA      0x02    //Inpit polarity register,
    #define MCP23017_IPOLB      0x03    //GPIO register values: 1=inverted, 0=normal  
    
    #define MCP23017_GPINTENA   0x04    //Interrrupt on change control register, 
    #define MCP23017_GPINTENB   0x05    //1=enable, 0= disable int on change event
    
    #define MCP23017_DEFVALA    0x06    //Default compare reg for int on change. 
    #define MCP23017_DEFVALB    0x07    //Opposite pin level generates int
    
    #define MCP23017_INTCONA    0x08    //Interrupt control register
    #define MCP23017_INTCONB    0x09    //1 = Controls how the associated pin value is compared for interrupt-on-change.
                                        //0 = Pin value is compared against the previous pin value.
    
    #define MCP23017_IOCON      0x0A
    //#define MCP23017_IOCONB     0x0B    //shared with IOCON, not used
    
    // ### IOCON Register bits ###
                                            //bit 0 unimplemented
    #define MCP23017_IOCON_INTPOL   0x01    //sets the polarity of the INT output pin.1 = Active-high.0 =  Active-low.
    #define MCP23017_IOCON_ODR      0x02    //configures the INT pin as an open-drain output.
                                            //1 = Open-drain output (overrides the INTPOL bit).
                                            //0 =  Active driver output (INTPOL bit sets the polarity).
    #define MCP23017_IOCON_HAEN     0x03    //Hardware Address Enable bit (MCP23S17 only).
                                            //Address pins are always enabled on MCP23017.
                                            //1 = Enables the MCP23S17 address pins.
    #define MCP23017_IOCON_DISSLW   0x04    // Slew Rate control bit for SDA output.
                                            //1 = Slew rate disabled.
                                            //0 =  Slew rate enabled.
    #define MCP23017_IOCON_SEQOP    0x05    //Sequential Operation mode bit.
                                            //1 = Sequential operation disabled, address pointer does not increment.
                                            //0 =  Sequential operation enabled, address pointer increments.
    #define MCP23017_IOCON_MIRROR   0x06    // INT Pins Mirror bit
                                            //1 = The INT pins are internally connected
                                            //0 = The INT pins are not connected. INTA is associated with PortA and INTB is associated with PortB
    #define MCP23017_IOCON_BANK     0x07    //Controls how the registers are addressed
                                            //1 = The registers associated with each port are separated into different banks
                                            //0 = The registers are in the same bank (addresses are sequential)
    
    #define MCP23017_GPPUA      0x0C        //Pull up resistor config
    #define MCP23017_GPPUB      0x0D        //1 = Pull-up enabled, 0 = Pull-up disabled.
    
    #define MCP23017_INTFA      0x0E        //Interrrupt flag register
    #define MCP23017_INTFB      0x0F        //1 = Pin caused interrupt, 0 = Interrupt not pending.
    
    #define MCP23017_INTCAPA    0x10        //Interrupt capture register
    #define MCP23017_INTCAPB    0x11        //
    
    #define MCP23017_GPIOA      0x12        //Port register
    #define MCP23017_GPIOB      0x13
    
    #define MCP23017_OLATA      0x14        //Output latch register
    #define MCP23017_OLATB      0x15
    
    uint8_t MCP23017_Write(uint8_t* data_ptr, uint8_t length);
    uint8_t MCP23017_Read(uint8_t addr);
    
    void MCP23017_Config(void);
    void MCP23017_Reset(uint8_t state);
    
    void MCP23017_WritePorts(uint16_t value);
    
    
#endif
/* [] END OF FILE */
