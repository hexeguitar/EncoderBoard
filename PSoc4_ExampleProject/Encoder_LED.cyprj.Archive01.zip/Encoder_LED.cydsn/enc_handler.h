/* ========================================
 *
 * MCP23017 header file
 * 04.2016 by Piotr Zapart 
 * www.hexeguitar.com
 *
 * ========================================
*/
#ifndef _ENC_HANDLER_H_
#define _ENC_HANDLER_H_
    
    #include<cytypes.h>

    typedef uint32 (*ReadFn_ptr)(void);           //pointer to function returning 16bit counter value
    typedef void (*WriteFn_ptr)(uint32 value);    //pointer to function writing to the counter register
    
    typedef struct 
    {
        ReadFn_ptr CounterRead;                 //function pointer to read the hardware counter value
        WriteFn_ptr CounterWrite;               //function pointer to write to the hardware counter 
        int16_t value;                          //scaled encoder output value
        int16_t min;                            //minimum value/limit
        int16_t max;                            //maximum value/limit      
    }encoder_t;
    
    
    // ### Function declarations ###
    void InitEncoder(encoder_t *Enc_ptr, ReadFn_ptr ReadFn, WriteFn_ptr WriteFn, int16_t min, int16_t max, int16_t start_value);
    void UpdateEncoder(encoder_t *Enc_ptr);
#endif
/* [] END OF FILE */
