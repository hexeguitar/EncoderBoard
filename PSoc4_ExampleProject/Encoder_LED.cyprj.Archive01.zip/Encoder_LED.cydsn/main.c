/* ===========================================================================
 *
 *                 Rotary Encoder + LED circular bargraph
 *                              example project
 *               for CY8CKIT-042 Cypress PSoC4200 Pioneer Kit
 * 
 *                (c) 2016 Piotr Zapart, www.hexeguitar.com
 * 
 * see TopDesign.cysh for schematic and pin connections
 *
 * LED ring operation modes:
 * 1. Single - single led, position controlled with the rotary encoder
 * 2. Bargraph - circular bargraph controlled with the rotary encoder
 * 3. Rot_CW - CW rotation, speed controlled with the rotary encoder
 * 4. Rot_CCW - CCW rotation, speed controlled with the rotary encoder
 * 5. Capsense_Slider: bargraph mode controlled with the Capsense slider
 *
 * ===========================================================================
*/
#include <project.h>
#include "MCP23017.h"
#include <limits.h>
#include <stdlib.h>
#include "enc_handler.h"

#define SYSTICK_TICKS 4000


// ### Function declarations ###
uint32_t rotl32 (uint32_t value, unsigned int count);
uint32_t rotr32 (uint32_t value, unsigned int count); 

// ### LED display modes ###
typedef enum
{
    SINGLE,
    BARGRAPH,
    ROT_CW,
    ROT_CCW,
    CAPSENSE_SLIDER
}led_mode_t;

led_mode_t mode;

// ### ISR declarations ###
CY_ISR_PROTO(ButtonPress_ISR);
CY_ISR_PROTO(ButtonRelease_ISR);
CY_ISR_PROTO(SYSTICK_ISR);

const uint16_t LedBar[16] = {0x01,0x03,0x07,0x0F,0x1F,0x3F,0x7F,0xFF,0x01FF,0x03FF,0x07FF,0x0FFF,0x1FFF,0x3FFF,0x7FFF,0xFFFF};

volatile uint32_t SystickDelay;

uint16_t LEDs = 0x0F;
uint32_t LED_Capsense;

// ###############################################################
//                          FUNCTIONS
// ###############################################################

// Circular bit shift

uint32_t rotl32 (uint32_t value, unsigned int count) 
{
    return ((value<<count) | (value >> (16 - count))) & 0x0000FFFF;
}

uint32_t rotr32 (uint32_t value, unsigned int count) 
{
    return ((value>>count) | (value<<(16-count))) & 0x0000FFFF ;
}
// ###############################################################


// ###############################################################
//                          INTERRUPTS
// ###############################################################
//                       BUTTON PRESS ISR 
CY_ISR(ButtonPress_ISR)
{
    mode = (mode+1);
    if (mode > CAPSENSE_SLIDER) mode = SINGLE;
    
    UART_UartPutString("Mode = ");     
    switch(mode)
    {
        case SINGLE:
                    UART_UartPutString("Single"); 
                    break;
        case BARGRAPH:
                    UART_UartPutString("Bargraph"); 
                    break;
        case ROT_CW:
                    LEDs = 0x0f; //reset LEDs
                    UART_UartPutString("Rot CW"); 
                    break;
        case ROT_CCW:
                    LEDs = 0x0f; //reset LEDs
                    UART_UartPutString("Rot CCW");                       
                    break;
        case CAPSENSE_SLIDER:
                    UART_UartPutString("Capsense slider");
                    break;
    }
    UART_UartPutCRLF(0x20);
}
// ###############################################################
//                       BUTTON RELEASE ISR 
CY_ISR(ButtonRelease_ISR)
{
    //not used at the moment
}
// ###############################################################
// ############### Systick ISR used for delay ####################
CY_ISR(SYSTICK_ISR)
{
    if (SystickDelay) SystickDelay--;   
}

// ###############################################################
//                        MAIN LOOP
// ###############################################################

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    
    /* Map systick ISR to the user defined ISR. SysTick_IRQn is already defined in core_cm0.h file */
	CyIntSetSysVector((SysTick_IRQn + 16), SYSTICK_ISR);
	
    /* Enable Systick timer with desired period/number of ticks */
	SysTick_Config(SYSTICK_TICKS);
    
    ISR_BtnPress_StartEx(ButtonPress_ISR);
    //ISR_BtnRelease_StartEx(ButtonRelease_ISR);    //for future uses
    
    I2C_Start();
    Encoder_Start();
    CapSenseSlider_Start();
    UART_Start();
    
     /* Initialize baselines */
    CapSenseSlider_InitializeAllBaselines();
    
    //### init encoder 1
    encoder_t Encoder1;
    InitEncoder(&Encoder1,Encoder_ReadCounter,Encoder_WriteCounter,0,15,0);
    
    char UART_data[16];     //char buffer used to send data via UART
    
    MCP23017_Config();      //set the ports to outputs
    
    int16_t old = 0;        //used to detect the change
   
    mode = BARGRAPH;
    
    for(;;)
    {
        UpdateEncoder(&Encoder1);

        if (Encoder1.value != old)
        {   
            UART_UartPutString("Encoder value = ");        
            UART_UartPutString(itoa(Encoder1.value,UART_data,10));
            UART_UartPutCRLF(0x20);
            old = Encoder1.value;
        }
        
        // check Capsense slider
        /* Check whether the scanning of all enabled widgets is completed. */
        if(CapSenseSlider_IsBusy() == 0u)
        {
            /* Update all baselines */
            CapSenseSlider_UpdateEnabledBaselines();

            /* Start scanning all enabled sensors */
            CapSenseSlider_ScanEnabledWidgets();
        }
        
        // ### Update the LED ring according to the mode setting ###
        
        switch(mode)
        {
            case SINGLE:
                        MCP23017_WritePorts(1<<Encoder1.value);
                        break;
            case BARGRAPH:
                        MCP23017_WritePorts(LedBar[Encoder1.value]);
                        break;
            case ROT_CW:
                        if (SystickDelay == 0)
                        {
                            LEDs = rotl32(LEDs,1);
                            MCP23017_WritePorts(LEDs);
                            SystickDelay = (15<<7) - (Encoder1.value<<7) + 100;
                        }
                        break;
            case ROT_CCW:
                        if (SystickDelay == 0)
                        {
                            LEDs = rotr32(LEDs,1);
                            MCP23017_WritePorts(LEDs);
                            SystickDelay = (15<<7) - (Encoder1.value<<7) + 100;
                        }                    
                        break;
            case CAPSENSE_SLIDER:
                        LEDs = CapSenseSlider_GetCentroidPos(CapSenseSlider_SENSOR_LINEARSLIDER_E0__LS);
                        if (LEDs == 0xFFFFu) LEDs = 0x00;       // reset
                        LED_Capsense = (LEDs*10) >>6;           //just some experimental range adjustment
                        if (LED_Capsense>15) LED_Capsense = 15;
                        MCP23017_WritePorts(LedBar[LED_Capsense]);
                        break;
        }
 
    }
}

/* [] END OF FILE */
