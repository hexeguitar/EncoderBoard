/* ========================================
 *
 * MCP23017 driver
 * 04.2016 by Piotr Zapart 
 * www.hexeguitar.com
 *
 * ========================================
*/
#include <project.h>
#include "MCP23017.h"

    // ### Write a sequence of bytes into the MCP23018 via I2C ###

    uint8_t MCP23017_Write(uint8_t* data_ptr, uint8_t length)
    {
        uint8_t status = TRANSFER_ERROR;

        I2C_I2CMasterWriteBuf(MCP23017_SLAVE_ADDR>>1, data_ptr, length, I2C_I2C_MODE_COMPLETE_XFER);
        while( 0u == (I2C_I2CMasterStatus() & I2C_I2C_MSTAT_WR_CMPLT) );

        if( 0u == (I2C_I2C_MSTAT_ERR_XFER & I2C_I2CMasterStatus()) ){
            // Check if all bytes was written 
            if( I2C_I2CMasterGetWriteBufSize() == length )
            {
                status = TRANSFER_CMPLT;
            }
        }
        I2C_I2CMasterClearStatus();

        return status;
    }
    
    
    // ### Read register ### 
    uint8_t MCP23017_Read(uint8_t addr)
    {
        return addr;
    }
    
    
    // ### MCP23017 configuration
    void MCP23017_Config(void)
    {
        uint8_t data_buf [] =
        {
            MCP23017_IODIRA,        //start at PORTA direction register
            0x00,                   //set all to outputs, seq write, BANK=0, next address: IODIRB
            0x00                    //set PORTB to outputs
        };
        
        MCP23017_Write(data_buf, sizeof(data_buf));
    }
    
    void MCP23017_WritePorts(uint16_t value)
    {
                uint8_t data_buf [] =
        {
            MCP23017_GPIOA,        //start at PORTA direction register
            (value&0xFF),           
            (value>>8)                    
        };
        
        MCP23017_Write(data_buf, sizeof(data_buf));
        
    }
    

/* [] END OF FILE */
