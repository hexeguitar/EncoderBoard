/* ========================================
 *
 * Quadrature encoder handler
 * 04.2016 by Piotr Zapart 
 * www.hexeguitar.com
 *
 * ========================================
*/
#include <project.h>
#include "enc_handler.h"

/* ###################### Initilize Encoder ########################
 * Params in:
 * *Enc_ptr: pointer to an ecnoder structure
 * ReadFn_ptr: function pointer to read the counter value
 * WriteFn_ptr: function pointer to write a value into the counter
 * min: min value, top limit
 * max: max value, bottom limit
 * start_value: starting point, keep it between the min and max
*/
void InitEncoder(encoder_t *Enc_ptr, ReadFn_ptr ReadFn, WriteFn_ptr WriteFn, int16_t min, int16_t max, int16_t start_value)
{
    Enc_ptr->CounterRead = ReadFn;                              //attach the read/write functions
    Enc_ptr->CounterWrite = WriteFn;
    
    if (start_value < Enc_ptr->min) start_value = Enc_ptr->min; //keep the start_val within the limits
    if (start_value > Enc_ptr->max) start_value = Enc_ptr->max;
    
    Enc_ptr->min = min;                                         //set the min/max values
    Enc_ptr->max = max;
    
    Enc_ptr->CounterWrite(start_value+0x8000);                  //the actual hadrware counter starts at 0x8000
    Enc_ptr->value = start_value;                               //offset it by the start_value
    
}

/* ###################### Update Encoder ########################
 * reads iut the hardware counter, scales it to desired range
 * Param in:
 * *Enc_ptr: pointer to an encoder structure
*/
void UpdateEncoder(encoder_t *Enc_ptr)
{
    int16_t temp;
    
    temp = Enc_ptr->CounterRead() - 0x8000;
    
    if (temp > Enc_ptr->max) 
    {
        Enc_ptr->CounterWrite(Enc_ptr->max+0x8000);   //upper limit
        Enc_ptr->value = Enc_ptr->max;
    }
    else if (temp < Enc_ptr->min) 
    {
        Enc_ptr->CounterWrite(Enc_ptr->min+0x8000);   //bottom limit
        Enc_ptr->value = Enc_ptr->min;
    }
    else
    {
        Enc_ptr->value = temp;
    }   
}

/* [] END OF FILE */
